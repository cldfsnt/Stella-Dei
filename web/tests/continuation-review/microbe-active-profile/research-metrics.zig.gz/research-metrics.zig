const std=@import("std");
pub var enabled:bool=false;pub var candidate:bool=false;pub var sums:[3]u64=.{0}**3;pub var ticks:u64=0;
pub const mark=@import("active_cell_index.zig").mark;
pub const next=@import("active_cell_index.zig").next;
test "ordered iterator sees future same-word writes but never revisits lower cells"{var bits=[_]u64{0,0};mark(&bits,2);mark(&bits,90);var c:usize=0;try std.testing.expectEqual(@as(?usize,2),next(&bits,&c,100));mark(&bits,3);mark(&bits,1);try std.testing.expectEqual(@as(?usize,3),next(&bits,&c,100));try std.testing.expectEqual(@as(?usize,90),next(&bits,&c,100));mark(&bits,99);mark(&bits,100);try std.testing.expectEqual(@as(?usize,99),next(&bits,&c,100));try std.testing.expectEqual(@as(?usize,null),next(&bits,&c,100));}
