pub var qa_wind_profile:[5]f64=.{0,0,0,0,0};
extern fn emscripten_get_now()f64;
pub var qa_stages:[4]f64=.{0,0,0,0};
pub var qa_substages:[5]f64=.{0,0,0,0,0};
const AtmosphereWater = @import("atmosphere_water.zig");
const Microbes = @import("microbes.zig");
const ActiveCells = @import("../active_cell_index.zig");
const SurfacePhysics = @import("surface_physics.zig");
const builtin = @import("builtin");
const std = @import("std");
const gl = @import("gl");
const za = @import("zalgebra");
const zigimg = @import("zigimg");
const tracy = @import("../vendor/tracy.zig");
const cl = @cImport({
    @cDefine("CL_TARGET_OPENCL_VERSION", "110");
    @cInclude("CL/cl.h");
});

pub const USE_OPENCL = false;

const perlin = @import("../perlin.zig");
const EventLoop = @import("../loop.zig").EventLoop;
const Job = @import("../loop.zig").Job;
const IcosphereMesh = @import("../utils.zig").IcosphereMesh;

const Lifeform = @import("life.zig").Lifeform;
const Ecology = @import("ecology.zig");

const Vec2 = za.Vec2;
const Vec3 = za.Vec3;
const Allocator = std.mem.Allocator;

const VECTOR_SIZE = std.simd.suggestVectorLength(f32) orelse 4;
const VECTOR_ALIGN = @alignOf(SimdVector);
const SimdVector = @Vector(VECTOR_SIZE, f32);
const SimdVector64 = @Vector(VECTOR_SIZE, f64);
const IndexVector = @Vector(VECTOR_SIZE, usize);
const VECTOR_ZERO: SimdVector = @splat(0.0);
const VECTOR_ONE: SimdVector = @splat(1.0);

pub const CLContext = if (!USE_OPENCL) struct {} else struct {
    device: cl.cl_device_id,
    queue: cl.cl_command_queue,
    simulationKernel: cl.cl_kernel,

    // Memory buffers
    temperatureBuffer: cl.cl_mem,
    newTemperatureBuffer: cl.cl_mem,
    verticesBuffer: cl.cl_mem,
    heatCapacityBuffer: cl.cl_mem,
    verticesNeighbourBuffer: cl.cl_mem,

    pub fn init(allocator: Allocator, self: *const Planet) !CLContext {
        var platform: cl.cl_platform_id = undefined;
        if (cl.clGetPlatformIDs(1, &platform, null) != cl.CL_SUCCESS) {
            return error.OpenCLError;
        }

        var device: cl.cl_device_id = undefined;
        if (cl.clGetDeviceIDs(platform, cl.CL_DEVICE_TYPE_GPU, 1, &device, null) != cl.CL_SUCCESS) {
            return error.OpenCLError;
        }

        const context = cl.clCreateContext(null, 1, &device, null, null, null);
        const queue = cl.clCreateCommandQueue(context, device, 0, null);

        var sources = [_][*c]const u8{@embedFile("../simulation/simulation.cl")};
        const program = cl.clCreateProgramWithSource(context, 1, @as([*c][*c]const u8, @ptrCast(&sources)), null, null).?;

        // TODO: use SPIR-V for the kernel?
        const buildError = cl.clBuildProgram(program, 1, &device, "-cl-strict-aliasing -cl-fast-relaxed-math", null, null);
        if (buildError != cl.CL_SUCCESS) {
            std.log.err("error building opencl program: {d}", .{buildError});

            const log = try allocator.alloc(u8, 16384);
            defer allocator.free(log);
            var size: usize = undefined;
            _ = cl.clGetProgramBuildInfo(program, device, cl.CL_PROGRAM_BUILD_LOG, log.len, log.ptr, &size);
            std.log.err("{s}", .{log[0..size]});
            return error.OpenCLError;
        }
        const temperatureKernel = cl.clCreateKernel(program, "simulateTemperature", null) orelse return error.OpenCLError;

        const temperatureBuffer = cl.clCreateBuffer(context, cl.CL_MEM_READ_WRITE | cl.CL_MEM_USE_HOST_PTR, self.temperature.len * @sizeOf(f32), self.temperature.ptr, null);
        const newTemperatureBuffer = cl.clCreateBuffer(context, cl.CL_MEM_READ_WRITE | cl.CL_MEM_USE_HOST_PTR, self.newTemperature.len * @sizeOf(f32), self.newTemperature.ptr, null);
        const verticesBuffer = cl.clCreateBuffer(context, cl.CL_MEM_READ_ONLY | cl.CL_MEM_USE_HOST_PTR, self.vertices.len * @sizeOf(Vec3), self.vertices.ptr, null);
        const heatCapacityBuffer = cl.clCreateBuffer(context, cl.CL_MEM_READ_ONLY | cl.CL_MEM_USE_HOST_PTR, self.heatCapacityCache.len * @sizeOf(f32), self.heatCapacityCache.ptr, null);
        const verticesNeighbourBuffer = cl.clCreateBuffer(context, cl.CL_MEM_READ_ONLY | cl.CL_MEM_USE_HOST_PTR, self.verticesNeighbours.len * @sizeOf([6]u32), self.verticesNeighbours.ptr, null);

        return CLContext{
            .device = device,
            .queue = queue,
            .simulationKernel = temperatureKernel,

            .temperatureBuffer = temperatureBuffer,
            .newTemperatureBuffer = newTemperatureBuffer,
            .verticesBuffer = verticesBuffer,
            .heatCapacityBuffer = heatCapacityBuffer,
            .verticesNeighbourBuffer = verticesNeighbourBuffer,
        };
    }
};

pub const Planet = struct {
    sandboxDefense:Ecology.DefenseConfig=. {},
    mesh: IcosphereMesh,
    atmosphereMesh: IcosphereMesh,

    numTriangles: gl.GLint,
    numSubdivisions: usize,
    seed: u64,
    radius: f32,
    /// Arena allocator for simulation data
    simulationArena: std.heap.ArenaAllocator,
    allocator: std.mem.Allocator,
    /// The *unmodified* vertices of the icosphere
    vertices: []Vec3,
    /// Slice changed during each upload() call, it contains the data
    /// that will be stored in the VBO.
    bufData: []f32,
    /// Normals are computed every 10 frames to avoid overloading CPU for
    /// not much
    normals: []Vec3,
    /// self.vertices transformed by upload(), for easy use by functions like
    /// getNearestPointTo()
    transformedPoints: []Vec3,
    normalComputeJob: ?*Job(void) = null,
    /// The number of time upload() has been called, this is used to keep track
    /// of when to update the normals
    uploadNo: u32 = 0,

    /// The water mass
    /// Unit: 10⁹ kg
    waterMass: []f32,
    /// The mass of water vapor in the troposphere
    /// Unit: 10⁹ kg
    waterVaporMass: []f32,
    /// The average N2 mass per point of the planet
    /// Unit: 10⁹ kg
    averageNitrogenMass: f64 = 0,
    /// The average O2 mass per point of the planet
    /// Unit: 10⁹ kg
    averageOxygenMass: f64 = 0,
    /// The average CO2 mass per point of the planet
    /// Unit: 10⁹ kg
    averageCarbonDioxideMass: f64 = 0,
    /// Historic rainfall
    /// Unit: arbitrary
    rainfall: []f32,
    /// The air velocity is a 2D velocity on the plane
    /// of the point that's tangent to the sphere
    /// Unit: km/s
    airVelocity: []Vec2,
    /// The accumulated error in position of the air when it has been moved.
    /// Unit: km
    airPositionError: []Vec2,
    /// The elevation of each point.
    /// Unit: Kilometer
    elevation: []f32,
    /// Temperature measured
    /// Unit: Kelvin
    temperature: []f32,
    /// Original pointer to self.temperature,
    /// this is used for sync up with OpenCL kernels
    temperaturePtrOrg: [*]f32,
    /// Cache of the heat capacity for each point, this just used for
    /// speeding up computations at the expense of some RAM
    /// Unit: J.K-1
    heatCapacityCache: []f32,
    /// Transient per-step wind vectors. Owned by allocator, not saved physics.
    /// Lazy allocation failure retains the exact uncached calculation path.
    atmosphericWindScratch: [][3]f32 = &.{},
    /// Owned per-tick directed rates; refreshed from current geometry and wind.
    /// Preserve f64 rates and original sum order. Not part of saved physics.
    atmosphericEdgeScratch: [][6]f64 = &.{},
    vegetation: []f32,
    plantTraits: []Ecology.Plant,
    vegetationSnapshot: []f32,
    worldMode: Microbes.Mode = .sandbox,
    microbeCells: []Microbes.Cell = &.{},
    microbeStats: Microbes.Stats = .{},
    propaguleFeedback: @import("../propagule_feedback.zig").Tracker = .{},
    propaguleAttempts: u64 = 0,
    propaguleArrivals: u64 = 0,
    propaguleTrackedLosses: u64 = 0,
    plantGenerations: u32 = 0,
    plantBirths: u64 = 0,
    rabbitBirths: u64 = 0,
    rabbitMeals: u64 = 0,
    rabbitDeaths: u64 = 0,
    /// The wavelength of plant's color, in nanometers
    plantColorWavelength: f32 = 530,
    /// Buffer array that is used to store the temperatures to be used after next update
    newTemperature: []f32,
    newWaterMass: []f32,
    newWaterVaporMass: []f32,
    lifeforms: std.ArrayListUnmanaged(Lifeform),
    /// Lock used to avoid concurrent reads and writes to lifeforms arraylist
    lifeformsLock: std.Thread.Mutex = .{},
    nextMeteorite: f64 = 0,

    // 0xFFFFFFFF in the first entry considered null and not filled
    /// List of neighbours for a vertex. A vertex has 6 neighbours that arrange in hexagons
    /// Neighbours are stored as u32 as icospheres with more than 4 billions vertices aren't worth
    /// supporting.
    verticesNeighbours: [][6]u32,

    /// Is null if OpenCL could not be used.
    clContext: ?CLContext = null,

    pub const DisplayMode = enum(c_int) {
        Normal = 0,
        Temperature = 1,
        WaterVapor = 2,
        WindMagnitude = 3,
        Rainfall = 4,
    };

    fn appendNeighbor(planet: *Planet, idx: u32, neighbor: u32) void {
        // Find the next free slot in the list:
        var i: usize = 0;
        while (i < 6) : (i += 1) {
            if (planet.verticesNeighbours[idx][i] == idx) {
                planet.verticesNeighbours[idx][i] = neighbor;
                return;
            } else if (planet.verticesNeighbours[idx][i] == neighbor) {
                return; // The neighbor was already added.
            }
        }
        unreachable;
    }

    fn computeNeighbours(planet: *Planet) void {
        const zone = tracy.ZoneN(@src(), "Compute points neighbours");
        defer zone.End();

        const indices = planet.mesh.indices;
        const vertNeighbours = planet.verticesNeighbours;
        var i: u32 = 0;
        // Clear the vertex list:
        while (i < vertNeighbours.len) : (i += 1) {
            var j: u32 = 0;
            while (j < 6) : (j += 1) {
                vertNeighbours[i][j] = i;
            }
        }

        // Loop through all triangles
        i = 0;
        while (i < indices.len) : (i += 3) {
            const aIdx = indices[i + 0];
            const bIdx = indices[i + 1];
            const cIdx = indices[i + 2];
            appendNeighbor(planet, aIdx, bIdx);
            appendNeighbor(planet, aIdx, cIdx);
            appendNeighbor(planet, bIdx, aIdx);
            appendNeighbor(planet, bIdx, cIdx);
            appendNeighbor(planet, cIdx, aIdx);
            appendNeighbor(planet, cIdx, bIdx);
        }
    }

    const GenerationOptions = struct {
        generate_terrain: bool = true,
        water_preset: @import("../world_setup.zig").Preset = .random,
    };

    pub fn generate(allocator: std.mem.Allocator, numSubdivisions: usize, radius: f32, seed: u64, options: GenerationOptions) !Planet {
        if(!options.generate_terrain and options.water_preset!=.random)return error.PresetRequiresNewTerrain;
        const zone = tracy.ZoneN(@src(), "Generate planet");
        defer zone.End();

        const atmosphereMesh = try IcosphereMesh.generate(allocator, numSubdivisions, false);
        gl.bindVertexArray(atmosphereMesh.vao[0]);
        gl.bindBuffer(gl.ARRAY_BUFFER, atmosphereMesh.vbo);
        gl.vertexAttribPointer(0, 3, gl.FLOAT, gl.FALSE, 4 * @sizeOf(f32), @as(?*anyopaque, @ptrFromInt(0 * @sizeOf(f32)))); // position
        gl.vertexAttribPointer(1, 1, gl.FLOAT, gl.FALSE, 4 * @sizeOf(f32), @as(?*anyopaque, @ptrFromInt(3 * @sizeOf(f32)))); // temperature (used for a bunch of things)
        gl.enableVertexAttribArray(0);
        gl.enableVertexAttribArray(1);

        const mesh = try IcosphereMesh.generate(allocator, numSubdivisions, true);

        // ArenaAllocator for all the simulation data points
        var simulationArena = std.heap.ArenaAllocator.init(allocator);
        const simAlloc = simulationArena.allocator();

        const zone3 = tracy.ZoneN(@src(), "Initialise with data");
        const numPoints = mesh.num_points;
        const vertices = try simAlloc.alloc(Vec3, numPoints);
        const vertNeighbours = try simAlloc.alloc([6]u32, numPoints);
        const elevation = try simAlloc.alignedAlloc(f32, VECTOR_ALIGN, numPoints);
        const waterElev = try simAlloc.alignedAlloc(f32, VECTOR_ALIGN, numPoints);
        const airVelocity = try simAlloc.alloc(Vec2, numPoints);
        const airPositionError = try simAlloc.alloc(Vec2, numPoints);
        const waterVaporMass = try simAlloc.alignedAlloc(f32, VECTOR_ALIGN, numPoints);
        const rainfall = try simAlloc.alloc(f32, numPoints);
        const temperature = try simAlloc.alignedAlloc(f32, VECTOR_ALIGN, numPoints);
        const vegetation = try simAlloc.alignedAlloc(f32, VECTOR_ALIGN, numPoints);
        const newTemp = try simAlloc.alignedAlloc(f32, VECTOR_ALIGN, numPoints);
        const newWaterElev = try simAlloc.alignedAlloc(f32, VECTOR_ALIGN, numPoints);
        const newVaporMass = try simAlloc.alignedAlloc(f32, VECTOR_ALIGN, numPoints);
        const heatCapacCache = try simAlloc.alloc(f32, numPoints);

        const lifeforms = try std.ArrayListUnmanaged(Lifeform).initCapacity(simAlloc, 0);
        const bufData = try simAlloc.alloc(f32, vertices.len * 9 + 1);
        const normals = try simAlloc.alloc(Vec3, vertices.len);
        const transformedPoints = try simAlloc.alloc(Vec3, vertices.len);
        const plantTraits = try simAlloc.alloc(Ecology.Plant, numPoints);
        const vegetationSnapshot = try simAlloc.alloc(f32, numPoints);

        var planet = Planet{
            .mesh = mesh,
            .atmosphereMesh = atmosphereMesh,
            .numTriangles = @as(gl.GLint, @intCast(mesh.indices.len)),
            .numSubdivisions = numSubdivisions,
            .seed = seed,
            .radius = radius,
            .simulationArena = simulationArena,
            .allocator = allocator,
            .vertices = vertices,
            .verticesNeighbours = vertNeighbours,
            .elevation = elevation,
            .waterMass = waterElev,
            .waterVaporMass = waterVaporMass,
            .rainfall = rainfall,
            .airVelocity = airVelocity,
            .airPositionError = airPositionError,
            .newWaterMass = newWaterElev,
            .newWaterVaporMass = newVaporMass,
            .temperature = temperature,
            .temperaturePtrOrg = temperature.ptr,
            .vegetation = vegetation,
            .plantTraits = plantTraits,
            .vegetationSnapshot = vegetationSnapshot,
            .newTemperature = newTemp,
            .heatCapacityCache = heatCapacCache,
            .lifeforms = lifeforms,
            .bufData = bufData,
            .normals = normals,
            .transformedPoints = transformedPoints,
        };

        // OpenCL doesn't really work well on Windows (atleast when testing
        // using Wine, it might be a missing DLL problem)
        if (builtin.target.os.tag != .windows and USE_OPENCL) {
            planet.clContext = CLContext.init(allocator, &planet) catch blk: {
                std.log.warn("Your system doesn't support OpenCL.", .{});
                break :blk null;
            };
        } else {
            planet.clContext = null;
        }

        // Zero-out data
        {
            @memset(waterVaporMass, 0);
            @memset(rainfall, 0);
            @memset(airVelocity, Vec2.zero());
            @memset(airPositionError, Vec2.zero());
            @memset(elevation, radius);
            @memset(waterElev, 0);
            @memset(vegetation, 0);
            @memset(planet.plantTraits, .{});
            @memset(planet.vegetationSnapshot, 0);
            @memset(temperature, 273.15 + 22.0);

            const NITROGEN_PERCENT = 78.084 / 100.0;
            const OXYGEN_PERCENT = 20.946 / 100.0;
            const CARBON_DIOXIDE_PERCENT = 0.6 / 100.0; // estimated value from Earth prebiotic era
            const ATMOSPHERE_MASS = 5.15 * std.math.pow(f64, 10, 18 - 9);
            planet.averageNitrogenMass = @as(f32, @floatCast(NITROGEN_PERCENT * ATMOSPHERE_MASS / @as(f64, @floatFromInt(numPoints))));
            planet.averageOxygenMass = @as(f32, @floatCast(OXYGEN_PERCENT * ATMOSPHERE_MASS / @as(f64, @floatFromInt(numPoints))));
            planet.averageCarbonDioxideMass = @as(f32, @floatCast(CARBON_DIOXIDE_PERCENT * ATMOSPHERE_MASS / @as(f64, @floatFromInt(numPoints))));
        }

        if (options.generate_terrain) {
            var prng = std.rand.DefaultPrng.init(seed);
            const random = prng.random();

            const vert = mesh.vertices;
            const kmPerWaterMass = planet.getKmPerWaterMass();
            const seaLevel = radius + (random.float(f32) - 0.5) * 10; // between +5km and -5/km
            //const seaLevel: f32 = -10.0;

            std.log.info("{d} km / water ton", .{kmPerWaterMass});
            std.log.info("seed 0x{x}", .{seed});
            std.log.info("Sea Level: {d} km", .{seaLevel - radius});
            perlin.setSeed(random.int(u64));
            var i: usize = 0;
            while (i < vert.len) : (i += 3) {
                const point = Vec3.fromSlice(vert[i..]).norm();
                const value = radius + perlin.noise(point.x() * 3 + 5, point.y() * 3 + 5, point.z() * 3 + 5) * @min(radius / 2, 15);

                elevation[i / 3] = value;
                waterElev[i / 3] = @max(0, seaLevel - value) / kmPerWaterMass;
                vertices[i / 3] = point;
                //vegetation[i / 3] = perlin.fbm(point.x() + 5, point.y() + 5, point.z() + 5, 4) / 2 + 0.5;
                vegetation[i / 3] = 0;

                temperature[i / 3] = (1 - @abs(point.z())) * 55 + 273.15 - 25.0;

                // Match upload geometry; waterElev is mass, never a radius.
                const totalElevation = radius + (elevation[i / 3] - radius) * HEIGHT_EXAGGERATION_FACTOR;
                const transformedPoint = point.scale(totalElevation);
                planet.transformedPoints[i / 3] = transformedPoint;
            }
            if(options.water_preset==.continents){
                const inventory=try @import("world_water_inventory.zig").plan(allocator,elevation,kmPerWaterMass,0.7);
                for(elevation,0..)|height,index|waterElev[index]=inventory.massAt(height,kmPerWaterMass);
                std.log.info("NEW_WORLD_WATER preset=continents requested_ocean=0.7 actual_ocean={d} sea_level_km={d} initial_mass={d} vapor=0 existing_save_untouched=true",.{inventory.oceanFraction(),inventory.sea_level-radius,inventory.initial_mass});
            }
        } else {
            var i: usize = 0;
            const vert = mesh.vertices;
            while (i < vert.len) : (i += 3) {
                const point = Vec3.fromSlice(vert[i..]).norm();
                vertices[i / 3] = point;
            }
        }
        zone3.End();

        // Pre-compute the neighbours of every point of the ico-sphere.
        computeNeighbours(&planet);

        for (mesh.vao) |vao| {
            gl.bindVertexArray(vao);
            // position and normal are interleaved
            gl.vertexAttribPointer(0, 3, gl.FLOAT, gl.FALSE, 6 * @sizeOf(f32), @as(?*anyopaque, @ptrFromInt(0 * @sizeOf(f32)))); // position
            gl.vertexAttribPointer(1, 3, gl.FLOAT, gl.FALSE, 6 * @sizeOf(f32), @as(?*anyopaque, @ptrFromInt(3 * @sizeOf(f32)))); // normal
            // temperature, water level and vegetation are sequential so we can glBufferSubData
            gl.vertexAttribPointer(2, 1, gl.FLOAT, gl.FALSE, 1 * @sizeOf(f32), @as(?*anyopaque, @ptrFromInt(6 * @sizeOf(f32) * vertices.len))); // temperature (used for a bunch of things)
            gl.vertexAttribPointer(3, 1, gl.FLOAT, gl.FALSE, 1 * @sizeOf(f32), @as(?*anyopaque, @ptrFromInt(7 * @sizeOf(f32) * vertices.len))); // water level (used in Normal display mode)
            gl.vertexAttribPointer(4, 1, gl.FLOAT, gl.FALSE, 1 * @sizeOf(f32), @as(?*anyopaque, @ptrFromInt(8 * @sizeOf(f32) * vertices.len))); // vegetation level (temporary until replaced by actual living vegetation)
            gl.enableVertexAttribArray(0);
            gl.enableVertexAttribArray(1);
            gl.enableVertexAttribArray(2);
            gl.enableVertexAttribArray(3);
            gl.enableVertexAttribArray(4);
        }
        gl.bindBuffer(gl.ARRAY_BUFFER, mesh.vbo);
        gl.bufferData(gl.ARRAY_BUFFER, @as(isize, @intCast(bufData.len * @sizeOf(f32))), bufData.ptr, gl.STREAM_DRAW);

        const meanPointArea = (4 * std.math.pi * radius * radius) / @as(f32, @floatFromInt(numPoints));
        std.log.info("There are {d} points in the ico-sphere.\n", .{numPoints});
        std.log.info("The mean area per point of the ico-sphere is {d} km²\n", .{meanPointArea});
        std.log.info("SIMD Vectors: {} x f32", .{VECTOR_SIZE});

        return planet;
    }

    pub fn loadFromImage(self: Planet, allocator: std.mem.Allocator, file: *std.fs.File) !void {
        var image = try zigimg.Image.fromFile(allocator, file);
        defer image.deinit();

        if (image.pixelFormat() != .rgba32) {
            std.log.err("Can only load images with rgba32 format!", .{});
            return error.InvalidPixelFormat;
        }

        // The process:
        // - take every point of the icosphere
        // - convert it latitude and longitude coordinates
        // - do equirectangular projection in order to convert to image coordinates
        // - use resulting value as height (TODO: do average of neighbour cells too?)

        const standardParallel: f32 = std.math.degreesToRadians(0);
        const kmPerWaterMass = self.getKmPerWaterMass();

        for (self.vertices, 0..) |*vert, idx| {
            const longitude = std.math.atan2(vert.y(), vert.x());
            const latitude = std.math.acos(vert.z()) * 2;
            const imageX = @as(usize, @intFromFloat(@as(f32, @floatFromInt(image.width)) / (std.math.pi * 2.0) * (longitude + std.math.pi) * std.math.cos(standardParallel)));
            const imageY = @min(@as(usize, @intFromFloat(@as(f32, @floatFromInt(image.height)) / (std.math.pi * 2.0) * (latitude))), image.height - 1);

            const pixel = image.pixels.rgba32[imageY * image.width + imageX];
            self.elevation[idx] = self.radius + @as(f32, @floatFromInt(pixel.r)) * 0.1 - 14.5;
            self.waterMass[idx] = @max(0, self.radius - self.elevation[idx]) / kmPerWaterMass;
            self.vegetation[idx] = if (self.waterMass[idx] == 0.0 and self.elevation[idx] - self.radius < 5.0) 1.0 else 0.0;
        }
    }

    const HEIGHT_EXAGGERATION_FACTOR = 10;

    fn computeNormal(self: Planet, a: usize, aVec: Vec3) Vec3 {
        @setFloatMode(.optimized);
        var sum = Vec3.zero();
        const adjacentVertices = self.getNeighbours(a);
        {
            var i: usize = 1;
            while (i < adjacentVertices.len) : (i += 1) {
                const b = adjacentVertices[i - 1];
                const bVec = self.transformedPoints[b];
                const c = adjacentVertices[i];
                const cVec = self.transformedPoints[c];
                var normal = bVec.sub(aVec).cross(cVec.sub(aVec)); // (b-a) x (c-a)
                // if the normal is pointing inside
                const aVecTranslate = aVec.add(normal.norm());
                if (aVecTranslate.dot(aVecTranslate) < aVec.dot(aVec)) {
                    normal = normal.negate(); // invert the normal
                }
                sum = sum.add(normal);
            }
        }
        return sum.norm();
    }

    pub fn computeAllNormals(self: *Planet, loop: *EventLoop) void {
        _ = loop;
        const zone = tracy.ZoneN(@src(), "Compute normals");
        defer zone.End();

        // there could potentially be a data race between this function and upload
        // but it's not a problem as even if only a part of a normal's components are
        // updated, the glitch is barely noticeable
        for (self.transformedPoints, 0..) |point, i| {
            self.normals[i] = self.computeNormal(i, point);
        }
    }

    pub fn getKmPerWaterMass(self: Planet) f32 {
        const waterDensity = 1000.0; // kg / m³
        const meanPointArea: f64 = self.getMeanPointArea(); // m²
        const kmPerWaterMass =
            1.0 / waterDensity // m³ / kg
        / meanPointArea // m / kg
        / 1000.0 // km / kg
        * 1_000_000_000 // km / 10⁹ kg
        ;
        return @as(f32, @floatCast(kmPerWaterMass));
    }

    /// Returns the mean point area in m²
    pub inline fn getMeanPointArea(self: Planet) f32 {
        // The surface of the planet (approx.) divided by the numbers of points
        // Computation is in f64 for greater accuracy
        const radius: f64 = self.radius;
        const meanPointArea = (4 * std.math.pi * (radius * 1000) * (radius * 1000)) / @as(f64, @floatFromInt(self.vertices.len)); // m²
        return @as(f32, @floatCast(meanPointArea));
    }

    pub fn mulByVec3(self: za.Mat4, v: Vec3) Vec3 {
        @setFloatMode(.optimized);
        @setRuntimeSafety(false);

        const x = (self.data[0][0] * v.x()) + (self.data[1][0] * v.y()) + (self.data[2][0] * v.z());
        const y = (self.data[0][1] * v.x()) + (self.data[1][1] * v.y()) + (self.data[2][1] * v.z());
        const z = (self.data[0][2] * v.x()) + (self.data[1][2] * v.y()) + (self.data[2][2] * v.z());
        return Vec3.new(x, y, z);
    }

    /// Deterministic terrain geometry shared by rendering and save restoration.
    /// No GL calls, jobs, allocation, saved resource mutation or frame advancement.
    inline fn terrainPoint(self: *const Planet, point: Vec3, index: usize, rotationMatrix: za.Mat4) Vec3 {
        @setFloatMode(.optimized);
        const totalElevation = self.elevation[index];
        const exaggeratedElev = (totalElevation - self.radius) * HEIGHT_EXAGGERATION_FACTOR + self.radius;
        const scaledPoint = point.scale(exaggeratedElev);
        return mulByVec3(rotationMatrix, scaledPoint);
    }

    pub fn refreshTransformedPoints(self: *Planet, axialTilt: f32) void {
        @setFloatMode(.optimized);
        const rotationMatrix = za.Mat4.fromRotation(axialTilt, Vec3.right());
        for (self.vertices, 0..) |point, i| self.transformedPoints[i] = self.terrainPoint(point, i, rotationMatrix);
    }

    /// Upload all changes to the GPU
    pub fn upload(self: *Planet, loop: *EventLoop, displayMode: DisplayMode, axialTilt: f32) void {
        const stage_timer=@import("../performance_details.zig").beginStage();
        defer @import("../performance_details.zig").endStage(stage_timer,.terrain_upload);
        @setFloatMode(.optimized);
        @setRuntimeSafety(false);

        const zone = tracy.ZoneN(@src(), "Planet GPU Upload");
        defer zone.End();

        const bufData = self.bufData;
        defer self.uploadNo += 1;
        if (self.normalComputeJob) |job| {
            if (job.isCompleted()) {
                job.deinit();
                self.normalComputeJob = null;
            }
        }
        if (self.uploadNo % 10 == 0 and self.normalComputeJob == null) {
            const job = Job(void).create(loop) catch unreachable;
            self.normalComputeJob = job;
            job.call(computeAllNormals, .{ self, loop }) catch unreachable;
        }

        {
            const rotationMatrix = za.Mat4.fromRotation(axialTilt, Vec3.right());
            const kmPerWaterMass = self.getKmPerWaterMass();
            _ = kmPerWaterMass;

            // This could be sped up by using LOD? (allowing to transfer less data)
            // NOTE: this has really bad cache locality
            // TODO: only update for parts of the world that changed
            const STRIDE = 6;
            for (self.vertices, 0..) |point, i| {
                // const waterElevation = self.waterMass[i] * kmPerWaterMass;
                // const totalElevation = self.elevation[i] + waterElevation;
                const transformedPoint = self.terrainPoint(point, i, rotationMatrix);
                const normal = self.normals[i];
                self.transformedPoints[i] = transformedPoint;

                const bytePos = i * STRIDE;
                const bufSlice = bufData[bytePos + 0 .. bytePos + 6];
                bufSlice[0..3].* = transformedPoint.data;
                bufSlice[3..6].* = normal.data;
            }

            gl.bindBuffer(gl.ARRAY_BUFFER, self.mesh.vbo);
            gl.bufferSubData(gl.ARRAY_BUFFER, 0, @as(isize, @intCast(6 * @sizeOf(f32) * self.vertices.len)), bufData.ptr);

            // This one is special and needs processing
            if (displayMode == .WindMagnitude) {
                for (self.airVelocity, 0..) |velocity, i| {
                    bufData[i] = velocity.x();
                }
                gl.bufferSubData(gl.ARRAY_BUFFER, 6 * @sizeOf(f32) * self.vertices.len, @as(isize, @intCast(self.vertices.len * @sizeOf(f32))), bufData.ptr);
                for (self.airVelocity, 0..) |velocity, i| {
                    bufData[i] = velocity.y();
                }
                gl.bufferSubData(gl.ARRAY_BUFFER, 7 * @sizeOf(f32) * self.vertices.len, @as(isize, @intCast(self.vertices.len * @sizeOf(f32))), bufData.ptr);
            } else {
                const displayedSlice = switch (displayMode) {
                    .WaterVapor => self.waterVaporMass,
                    .Rainfall => self.rainfall,
                    .Normal, .Temperature => self.temperature,
                    else => unreachable,
                };
                gl.bufferSubData(gl.ARRAY_BUFFER, 6 * @sizeOf(f32) * self.vertices.len, @as(isize, @intCast(displayedSlice.len * @sizeOf(f32))), displayedSlice.ptr);
                gl.bufferSubData(gl.ARRAY_BUFFER, 7 * @sizeOf(f32) * self.vertices.len, @as(isize, @intCast(self.waterMass.len * @sizeOf(f32))), self.waterMass.ptr);
            }
            gl.bufferSubData(gl.ARRAY_BUFFER, 8 * @sizeOf(f32) * self.vertices.len, @as(isize, @intCast(self.vegetation.len * @sizeOf(f32))), self.vegetation.ptr);
        }

        // Browser rendering never draws atmosphereMesh (renderWater is native-only).
        // Keep its native upload, but avoid rebuilding/streaming unused browser data.
        if (@import("builtin").target.cpu.arch != .wasm32) {
            const kmPerWaterMass = self.getKmPerWaterMass();
            const STRIDE = 4;
            for (self.vertices, 0..) |point, i| {
                const waterElevation = self.waterMass[i] * kmPerWaterMass;

                const zFightingOffset = 0.1; // TODO: scale depending on distance from camera
                var totalElevation = (self.elevation[i] + waterElevation - zFightingOffset - self.radius) * @min(waterElevation, 1);
                if (self.elevation[i] < self.radius) {
                    totalElevation = self.elevation[i] + waterElevation - zFightingOffset - self.radius;
                }
                const transformedPoint = point.scale(self.radius + (totalElevation) * HEIGHT_EXAGGERATION_FACTOR);

                const bytePos = i * STRIDE;
                const bufSlice = bufData[bytePos + 0 .. bytePos + 4];
                bufSlice[0..3].* = transformedPoint.data;
                bufSlice[3] = waterElevation;
            }

            gl.bindBuffer(gl.ARRAY_BUFFER, self.atmosphereMesh.vbo);
            gl.bufferData(gl.ARRAY_BUFFER, @as(isize, @intCast(STRIDE * self.atmosphereMesh.num_points * @sizeOf(f32))), bufData.ptr, gl.STREAM_DRAW);
        }
    }

    pub fn render(self: *Planet, loop: *EventLoop, displayMode: DisplayMode, axialTilt: f32) void {
        self.upload(loop, displayMode, axialTilt);
        self.renderNoUpload();
    }

    pub fn renderNoUpload(self: *Planet) void {
        for (self.mesh.vao, 0..) |vao, vaoIdx| {
            gl.bindVertexArray(vao);
            gl.drawElements(gl.TRIANGLES, self.mesh.num_elements[vaoIdx], gl.UNSIGNED_INT, null);
        }
    }

    // TODO: just do it in shaders postprocess.fs
    pub fn renderWater(self: *Planet) void {
        gl.bindVertexArray(self.atmosphereMesh.vao[0]);
        gl.drawElements(gl.TRIANGLES, @as(c_int, @intCast(self.atmosphereMesh.indices.len)), gl.UNSIGNED_INT, null);
    }

    pub const Direction = enum {
        ForwardLeft,
        BackwardLeft,
        Left,
        ForwardRight,
        BackwardRight,
        Right,
    };

    fn contains(list: anytype, element: usize) bool {
        for (list.constSlice()) |item| {
            if (item == element) return true;
        }
        return false;
    }

    pub inline fn getNeighbour(self: Planet, idx: usize, direction: Direction) usize {
        const directionInt = @intFromEnum(direction);
        return self.verticesNeighbours[idx][directionInt];
    }

    pub inline fn getNeighbourSimd(self: Planet, indexes: IndexVector, direction: Direction) IndexVector {
        const directionInt = @intFromEnum(direction);
        var neighbours: IndexVector = undefined;
        // XXX: do something more parallel?
        {
            comptime var i: usize = 0;
            inline while (i < VECTOR_SIZE) : (i += 1) {
                neighbours[i] = self.verticesNeighbours[indexes[i]][directionInt];
            }
        }
        return neighbours;
    }

    pub inline fn getNeighbours(self: Planet, idx: usize) [6]usize {
        return [6]usize{
            self.getNeighbour(idx, .ForwardLeft),
            self.getNeighbour(idx, .BackwardLeft),
            self.getNeighbour(idx, .Left),
            self.getNeighbour(idx, .ForwardRight),
            self.getNeighbour(idx, .BackwardRight),
            self.getNeighbour(idx, .Right),
        };
    }

    pub fn getNearestPointTo(self: Planet, position: Vec3) usize {
        return @import("../nearest_point.zig").nearest(self.transformedPoints, position);
    }

    pub const SimulationOptions = extern struct {
        /// The real time elapsed between two updates
        dt: f32,
        solarConstant: f32,
        planetRotationTime: f32,
        gameTime: f64,
        /// Currently, time scale greater than 40000 may result in lots of bugs
        timeScale: f32 = 1,
        solarVector: Vec3,
    };

    /// Much cheaper function than std.math.exp
    /// It deviates a lot when x > 25
    fn approxExp(x: f32) f32 {
        std.debug.assert(x <= 0);
        return 1 / (-x + 1);
    }
    // const exp = std.math.exp;
    const exp = approxExp;

    /// Given the index of a point on the planet, compute the specific heat capacity
    pub fn currentHeatCapacity(self:*Planet,index:usize) f64 {
        if(index>=self.temperature.len or index>=self.waterMass.len)return std.math.nan(f64);
        return self.computeHeatCapacity(index,self.getMeanPointArea());
    }

    inline fn computeHeatCapacity(self: *Planet, pointIndex: usize, pointArea: f32) f32 {
        if (self.worldMode == .origin) return SurfacePhysics.originHeatCapacity(pointArea, self.waterMass[pointIndex], self.temperature[pointIndex]);
        // specific heat capacities of given materials
        const groundCp: f32 = 700;
        // TODO: more precise water specific heat capacity, depending on temperature
        const waterCp: f32 = if (self.temperature[pointIndex] > 273.15) 4184 else 2093;

        const waterLevel = self.waterMass[pointIndex];
        const specificHeatCapacity = exp(-waterLevel / 2_000_000) * (groundCp - waterCp) + waterCp; // J/K/kg
        // Earth is about 5513 kg/m³ (https://nssdc.gsfc.nasa.gov/planetary/factsheet/earthfact.html) and assume each point is 0.72m thick??
        const pointMass = pointArea * 0.1 * 5513; // kg
        const heatCapacity = specificHeatCapacity * pointMass; // J.K-1
        return heatCapacity;
    }

    fn simulateTemperature(self: *Planet, loop: *EventLoop, options: SimulationOptions, start: usize, end: usize) void {
        @setFloatMode(.optimized);
        @setRuntimeSafety(false);
        _ = loop;

        //tracy.FiberEnter("Simulate temperature");
        //defer tracy.FiberLeave();
        const zone = tracy.ZoneN(@src(), "Temperature Simulation");
        defer zone.End();
        const newTemp = self.newTemperature;
        const heatCapacityCache = self.heatCapacityCache;
        const solarVector = options.solarVector;

        // Number of seconds that passes in 1 simulation step
        const dt = options.dt * options.timeScale;

        // The surface of the planet (approx.) divided by the numbers of points
        const meanPointArea = self.getMeanPointArea(); // m²
        // The mean distance between points (note: a little lower than the actual mean
        // due to the fact the point's area aren't squares)
        const meanDistance = std.math.sqrt(meanPointArea); // m

        // The mean surface of a point multiplied by dt
        // This is used as an optimization, to compute this value only once
        const meanPointAreaTime = meanPointArea * dt; // m².s

        {
            var i: usize = start;
            // Pre-compute the heat capacity of each point
            while (i < end) : (i += 1) {
                heatCapacityCache[i] = self.computeHeatCapacity(i, meanPointArea);
            }
        }

        // If dt is too high, default temperature simulation will become highly inaccurate so
        // we switch to an average simulation.
        const simulatePrecisely = dt < options.planetRotationTime / 4;

        // In W.m-1.K-1, this is 1 assuming 100% of planet is SiO2 :/
        const thermalConductivityMultiplier = 10.0; // real world thermal conductivity is too low for a game
        const groundThermalConductivity: f32 = 1 * thermalConductivityMultiplier;
        const waterThermalConductivity: f32 = 0.6089 * thermalConductivityMultiplier;

        if (simulatePrecisely) {
            var i: usize = start;
            // NEW(TM) heat simulation
            while (i < end) : (i += 1) {
                const normVert = self.transformedPoints[i].norm();
                // Temperature in the current cell
                const temp = self.temperature[i];

                const waterLevel = self.waterMass[i];
                const thermalConductivity = exp(-waterLevel / 2) * (groundThermalConductivity - waterThermalConductivity) + waterThermalConductivity; // W.m-1.K-1
                const heatCapacity = heatCapacityCache[i];

                var totalTemperatureGain: f32 = 0;

                for (self.getNeighbours(i)) |neighbourIndex| {
                    // We compute the 1-dimensional gradient of T (temperature)
                    // aka T1 - T2
                    const dT = self.temperature[neighbourIndex] - temp;
                    if (dT < 0) {
                        // Heat transfer only happens from the hot point to the cold one

                        // Rate of heat flow density
                        const qx = -thermalConductivity * dT / meanDistance; // W.m-2
                        //const watt = qx * meanPointArea; // W = J.s-1
                        // So, we get heat transfer in J
                        //const heatTransfer = watt * dt;
                        const heatTransfer = qx * meanPointAreaTime;

                        const neighbourHeatCapacity = heatCapacityCache[neighbourIndex];
                        // it is assumed neighbours are made of the exact same materials
                        // as this point
                        const temperatureGain = heatTransfer / neighbourHeatCapacity; // K
                        newTemp[neighbourIndex] += temperatureGain;
                        totalTemperatureGain -= temperatureGain;
                    }
                }

                // Solar irradiance
                {
                    const solarCoeff = @max(0, normVert.dot(solarVector) / normVert.length());
                    // TODO: Direct Normal Irradiance? when we have atmosphere
                    //const solarIrradiance = options.solarConstant * solarCoeff * meanPointArea; // W = J.s-1
                    // So, we get heat transfer in J
                    //const heatTransfer = solarIrradiance * dt;
                    const heatTransfer = options.solarConstant * solarCoeff * meanPointAreaTime;
                    const temperatureGain = heatTransfer / heatCapacity; // K
                    // TODO: albedo, ice has a higher albedo than liquid water

                    totalTemperatureGain += temperatureGain;
                }

                // Thermal radiation with Stefan-Boltzmann law
                {
                    const stefanBoltzmannConstant = 0.00000005670374; // W.m-2.K-4
                    // water emissivity: 0.96
                    // limestone emissivity: 0.92
                    const emissivity = 0.93; // took a value between the two
                    const radiantEmittance = stefanBoltzmannConstant * temp * temp * temp * temp * emissivity; // W.m-2
                    const h2o = self.waterVaporMass[i] / meanPointArea;
                    const co2 = self.averageCarbonDioxideMass / meanPointArea;
                    // IRL, H2O and CO2 are the two major greenhouse gases
                    // This is a very crude approximation of the greenhouse effect
                    const greenhouseEffect = @min(radiantEmittance * 0.9, @as(f32, @floatCast((h2o * 4 + co2 * 40) * @log(radiantEmittance) * 64000)));
                    const heatTransfer = (radiantEmittance - greenhouseEffect) * meanPointAreaTime; // J
                    const temperatureLoss = heatTransfer / heatCapacity; // K
                    totalTemperatureGain -= temperatureLoss;
                }
                newTemp[i] += totalTemperatureGain;
            }
        } else {
            var i: usize = start;
            // NEW(TM) heat simulation
            while (i < end) : (i += 1) {
                const normVert = self.transformedPoints[i].norm();
                // Temperature in the current cell
                const temp = self.temperature[i];
                const heatCapacity = heatCapacityCache[i];

                var totalTemperatureGain: f32 = 0;

                // TODO: solve the temperature by calculating with differential
                // for 4 times planetRotationTime / 4 steps
                // (thus with the solarVector at predefined cardinal positions)
                // that would be more accurate and have less bugs than current approach

                // Solar irradiance
                {
                    // Divide by 2 because it should only be lit 1/2th of the time
                    // technically we should divide more to take into account morning and evening not having max solarCoeff
                    // but whatever
                    const solarCoeff = (1 - @abs(normVert.z()));
                    // TODO: Direct Normal Irradiance? when we have atmosphere
                    //const solarIrradiance = options.solarConstant * solarCoeff * meanPointArea; // W = J.s-1
                    // So, we get heat transfer in J
                    //const heatTransfer = solarIrradiance * dt;
                    const heatTransfer = options.solarConstant * solarCoeff * meanPointAreaTime;
                    const temperatureGain = heatTransfer / heatCapacity; // K
                    // TODO: albedo, ice has a higher albedo than liquid water

                    totalTemperatureGain += temperatureGain;
                }

                // Thermal radiation with Stefan-Boltzmann law
                {
                    const stefanBoltzmannConstant = 0.00000005670374; // W.m-2.K-4
                    // water emissivity: 0.96
                    // limestone emissivity: 0.92
                    const emissivity = 0.93; // took a value between the two
                    const radiantEmittance = stefanBoltzmannConstant * temp * temp * temp * temp * emissivity; // W.m-2
                    const h2o = self.waterVaporMass[i] / meanPointArea;
                    const co2 = self.averageCarbonDioxideMass / meanPointArea;
                    // IRL, H2O and CO2 are the two major greenhouse gases
                    // This is a very crude approximation of the greenhouse effect
                    const greenhouseEffect = @min(radiantEmittance * 0.9, @as(f32, @floatCast((h2o * 4 + co2 * 40) * @log(radiantEmittance) * 64000)));
                    const heatTransfer = (radiantEmittance - greenhouseEffect) * meanPointAreaTime; // J
                    const temperatureLoss = heatTransfer / (heatCapacity / 1.75); // K
                    totalTemperatureGain -= temperatureLoss;
                }
                newTemp[i] += totalTemperatureGain;
            }
        }
    }

    fn simulateTemperature_OpenCL(self: *Planet, ctx: CLContext, options: SimulationOptions, start: usize, end: usize) void {
        if (!USE_OPENCL) @compileError("Not using OpenCL");
        if (start != 0 or end != self.temperature.len) {
            //std.debug.todo("Allow simulateTemperature_OpenCL to have a custom range");
            std.debug.panic("TODO", .{});
        }

        const zone = tracy.ZoneN(@src(), "Simulate temperature (OpenCL)");
        defer zone.End();

        // Number of seconds that passes in 1 simulation step
        const dt = options.dt * options.timeScale;

        // The surface of the planet (approx.) divided by the numbers of points
        const meanPointArea = self.getMeanPointArea(); // m²
        // The mean distance between points (note: a little lower than the actual mean
        // due to the fact the point's area aren't squares)
        const meanDistance = std.math.sqrt(meanPointArea); // m

        // The mean surface of a point multiplied by dt
        // This is used as an optimization, to compute this value only once
        const meanPointAreaTime = meanPointArea * dt; // m².s

        {
            const zone2 = tracy.ZoneN(@src(), "Compute heat capacity");
            defer zone2.End();
            var i: usize = 0;
            // Pre-compute the heat capacity of each point
            while (i < self.temperature.len) : (i += 1) {
                self.heatCapacityCache[i] = self.computeHeatCapacity(i, meanPointArea);
            }
        }

        if (self.temperature.ptr == self.temperaturePtrOrg) {
            _ = cl.clSetKernelArg(ctx.simulationKernel, 0, @sizeOf(cl.cl_mem), &ctx.temperatureBuffer);
            _ = cl.clSetKernelArg(ctx.simulationKernel, 1, @sizeOf(cl.cl_mem), &ctx.newTemperatureBuffer);
        } else {
            _ = cl.clSetKernelArg(ctx.simulationKernel, 1, @sizeOf(cl.cl_mem), &ctx.temperatureBuffer);
            _ = cl.clSetKernelArg(ctx.simulationKernel, 0, @sizeOf(cl.cl_mem), &ctx.newTemperatureBuffer);
        }

        _ = cl.clSetKernelArg(ctx.simulationKernel, 2, @sizeOf(cl.cl_mem), &ctx.verticesBuffer);
        _ = cl.clSetKernelArg(ctx.simulationKernel, 3, @sizeOf(cl.cl_mem), &ctx.heatCapacityBuffer);
        _ = cl.clSetKernelArg(ctx.simulationKernel, 4, @sizeOf(cl.cl_mem), &ctx.verticesNeighbourBuffer);
        _ = cl.clSetKernelArg(ctx.simulationKernel, 5, @sizeOf(f32), &meanPointAreaTime);
        _ = cl.clSetKernelArg(ctx.simulationKernel, 6, @sizeOf(f32), &meanDistance);
        _ = cl.clSetKernelArg(ctx.simulationKernel, 7, @sizeOf(SimulationOptions), &options);

        // TODO: combine with CPU for even faster results!
        const zone2 = tracy.ZoneN(@src(), "Run kernel");
        defer zone2.End();

        const global_work_size = (end - start + 511) / 512;
        const kernelError = cl.clEnqueueNDRangeKernel(ctx.queue, ctx.simulationKernel, 1, null, &global_work_size, null, 0, null, null);
        if (kernelError != cl.CL_SUCCESS) {
            std.log.err("Error running kernel: {d}", .{kernelError});
            std.os.exit(1);
        }
        _ = cl.clFinish(ctx.queue);
    }

    inline fn loadSimdVector(slice: []const f32, i: usize) *const SimdVector {
        return @as(*const SimdVector, @ptrCast(@alignCast(&slice[i])));
    }

    inline fn saveSimdVector(slice: []f32, i: usize, vector: SimdVector) void {
        @as(*SimdVector, @ptrCast(@alignCast(&slice[i]))).* = vector;
    }

    fn simulateWater(self: *Planet, loop: *EventLoop, options: SimulationOptions, numIterations: usize, start: usize, end: usize) void {
        _ = loop;
        const zone = tracy.ZoneN(@src(), "Water Simulation");
        defer zone.End();

        const dt = options.dt * options.timeScale;

        const meanPointArea = self.getMeanPointArea();
        const kmPerWaterMass = self.getKmPerWaterMass(); // km / 10⁹ kg

        const shareFactor = @min(0.00002 * dt / (6 * @as(f32, @floatFromInt(numIterations))), 1.0 / 7.0);


        // Do some liquid simulation
        const counting_vector = std.simd.iota(usize, VECTOR_SIZE);
        var i: usize = start;
        if (dt < 86400 / 4) {
            while (i < end - VECTOR_SIZE + 1) : (i += VECTOR_SIZE) {
                // only fluid if it's not ice
                const indices = @as(IndexVector, @splat(i)) + counting_vector; // i + 0, i + 1, i + 2, ...
                const elevation = loadSimdVector(self.elevation, i).*;
                const mass = loadSimdVector(self.newWaterMass, i).*;

                // Atmospheric phase exchange occurs after all liquid jobs join.

                const totalHeight = elevation + mass * @as(SimdVector, @splat(kmPerWaterMass));
                const shared = mass * @as(SimdVector, @splat(shareFactor));

                var massToRemove = @as(SimdVector, @splat(@as(f32, 0.0)));
                massToRemove += self.sendWater(self.getNeighbourSimd(indices, .ForwardLeft), indices, shared, totalHeight, kmPerWaterMass, shareFactor);
                massToRemove += self.sendWater(self.getNeighbourSimd(indices, .ForwardRight), indices, shared, totalHeight, kmPerWaterMass, shareFactor);
                massToRemove += self.sendWater(self.getNeighbourSimd(indices, .BackwardLeft), indices, shared, totalHeight, kmPerWaterMass, shareFactor);
                massToRemove += self.sendWater(self.getNeighbourSimd(indices, .BackwardRight), indices, shared, totalHeight, kmPerWaterMass, shareFactor);
                massToRemove += self.sendWater(self.getNeighbourSimd(indices, .Left), indices, shared, totalHeight, kmPerWaterMass, shareFactor);
                massToRemove += self.sendWater(self.getNeighbourSimd(indices, .Right), indices, shared, totalHeight, kmPerWaterMass, shareFactor);

                std.debug.assert(@reduce(.And, (mass - massToRemove) >= VECTOR_ZERO));
                saveSimdVector(self.newWaterMass, i, mass - massToRemove);
            }
        }

        // Do some wind simulation
        i = start;
        if (true) {

            // For simplicity, take the viscosity of air at 20°C
            // (see https://en.wikipedia.org/wiki/Viscosity#Air)
            const airViscosity = 2.791 * std.math.pow(f32, 10, -7) * std.math.pow(f32, 273.15 + 20.0, 0.7355); // Pa.s
            const airSpeedMult = 1 - airViscosity;
            const spinRate = 1.0 / options.planetRotationTime * 2 * std.math.pi * self.radius / 500000;
            while (i < end) : (i += 1) {
                const vert = self.vertices[i];
                var velocity = self.airVelocity[i];

                // Coriolis force
                if (true) {
                    // TODO: implement branchless?
                    var latitude = std.math.acos(vert.z());
                    if (latitude > std.math.pi / 2.0) {
                        latitude = -latitude;
                    }
                    // note: velocity is assumed to not be above meanDistanceKm
                    velocity = velocity.add(Vec2.new(spinRate * 2.0 * @sin(latitude) * dt, 0));
                }

                // Apply drag
                {
                    const velocityN = velocity.length() * 10; // * 10 given the square after, so that the result is in km/s while still being the same as if velocity was expressed in m/s in the computation
                    const dragCoeff = 1.55;
                    const area = meanPointArea / 1000 * (@max(0.1, (self.elevation[i] - self.radius) / 10)); // TODO: depend on steepness!!

                    // It's supposed to be * kg/m³ but as we divide by kg later, it's faster to directly divide by m³
                    const dragForce = 1.0 / 2.0 * velocityN * velocityN * dragCoeff * area / meanPointArea; // * massDensity // TODO: depend on Mach number?
                    velocity = velocity.sub(velocity.norm().scale(std.math.clamp(dragForce * dt, 0, velocityN / 20)));
                }

                // Actual moisture advection is a globally staged gather pass.

                velocity = velocity.scale(airSpeedMult);

                self.airVelocity[i] = velocity;
            }
        }
    }

    fn atmosphericWind(self:*const Planet,index:usize) [3]f64 {
        const normal=self.transformedPoints[index].norm();
        var right=normal.cross(Vec3.back());
        if(right.length()<0.000001)right=normal.cross(Vec3.new(0,1,0));
        right=right.norm();const up=normal.cross(right).norm();
        const velocity=self.airVelocity[index];
        const wind=right.scale(velocity.x()).add(up.scale(velocity.y()));
        return .{wind.x(),wind.y(),wind.z()};
    }
    fn ensureAtmosphericWindScratch(self:*Planet) bool {
        const count=self.transformedPoints.len;
        if(self.atmosphericWindScratch.len==count)return true;
        const replacement=self.allocator.alloc([3]f32,count) catch return false;
        self.allocator.free(self.atmosphericWindScratch);
        self.atmosphericWindScratch=replacement;
        return true;
    }
    fn ensureAtmosphericEdgeScratch(self:*Planet) bool {
        const count=self.transformedPoints.len;
        if(self.atmosphericEdgeScratch.len==count)return true;
        const replacement=self.allocator.alloc([6]f64,count) catch return false;
        self.allocator.free(self.atmosphericEdgeScratch);self.atmosphericEdgeScratch=replacement;return true;
    }
    fn cachedAtmosphericEdgeRate(self:*const Planet,from:usize,to:usize) f64 {
        if(self.atmosphericEdgeScratch.len==self.transformedPoints.len){
            for(self.getNeighbours(from),0..)|n,j|if(n==to)return self.atmosphericEdgeScratch[from][j];
        }
        return self.atmosphericEdgeRate(from,to);
    }
    fn atmosphericEdgeRate(self:*const Planet,from:usize,to:usize) f64 {
        const a=self.transformedPoints[from];const b=self.transformedPoints[to];
        const wind:[3]f64=if(self.atmosphericWindScratch.len==self.transformedPoints.len) blk:{
            const w=self.atmosphericWindScratch[from];break :blk .{w[0],w[1],w[2]};
        } else self.atmosphericWind(from);
        return AtmosphereWater.edgeRate(.{a.x(),a.y(),a.z()},.{b.x(),b.y(),b.z()},wind);
    }
    fn fillAtmosphericEdgeScratch(self: *Planet, comptime targets_finite: bool) void {
        for (self.atmosphericEdgeScratch, 0..) |*rates, i| {
            const point = self.transformedPoints[i];
            const wind: [3]f64 = if (self.atmosphericWindScratch.len == self.transformedPoints.len) blk: {
                const w = self.atmosphericWindScratch[i];
                break :blk .{ w[0], w[1], w[2] };
            } else self.atmosphericWind(i);
            const source = AtmosphereWater.EdgeSource.init(.{ point.x(), point.y(), point.z() }, wind);
            for (self.getNeighbours(i), 0..) |n, j| {
                const target = self.transformedPoints[n];
                const coordinates = [3]f64{ target.x(), target.y(), target.z() };
                rates[j] = if (targets_finite) source.rateFiniteTarget(coordinates) else source.rate(coordinates);
            }
        }
    }

    /// Called after wind jobs join. Validate current geometry once, not once per
    /// directed edge. Finite f32 coordinates remain finite when widened to f64.
    /// The uncommon invalid batch keeps the original checked behavior wholesale.
    fn rebuildAtmosphericEdgeScratch(self: *Planet) void {
        if (!self.ensureAtmosphericEdgeScratch()) return;
        var targets_finite = true;
        for (self.transformedPoints) |point| {
            if (!std.math.isFinite(point.x()) or !std.math.isFinite(point.y()) or !std.math.isFinite(point.z())) {
                targets_finite = false;
                break;
            }
        }
        if (targets_finite) self.fillAtmosphericEdgeScratch(true) else self.fillAtmosphericEdgeScratch(false);
    }

    /// Runs only after every liquid/velocity job has joined. No neighbor writes.
    /// Phase relaxation is phenomenological: no latent-heat or real-weather claim.
    fn simulateAtmosphereWater(self:*Planet,dt:f32) void {
        if(!std.math.isFinite(dt) or dt<=0)return;
        // Velocity jobs have joined. Cache each immutable tangent basis once,
        // preserving the original f32 components and f64 edge/summation order.
        if(self.ensureAtmosphericWindScratch())for(self.atmosphericWindScratch,0..)|*cached,i|{
            const wind=self.atmosphericWind(i);cached.*=.{@floatCast(wind[0]),@floatCast(wind[1]),@floatCast(wind[2])};
        };
        // Geometry and wind can change between ticks; no validity flag persists.
        self.rebuildAtmosphericEdgeScratch();
        const divider=self.getSubstanceDivider();const k:f64=1.380649e-23;
        const phase_step=AtmosphereWater.PhaseStep.init(dt);
        for(self.waterMass,self.waterVaporMass,0..)|liquid,vapor,i|{
            const temperature=self.temperature[i];
            const saturation=@as(f64,getEquilibriumVaporPressure(temperature))*divider/(@as(f64,temperature)*k);
            const result=phase_step.phase(liquid,vapor,saturation,temperature,self.rainfall[i]) orelse continue;
            self.waterMass[i]=@floatCast(result.liquid);self.waterVaporMass[i]=@floatCast(result.vapor);self.rainfall[i]=@floatCast(result.rain_rate);
        }
        // After the preceding swap, newWaterMass holds stale OLD liquid data.
        // It is scratch until the NEXT water step overwrites it from waterMass.
        // Saves and rendering consume current waterMass, never this scratch.
        // Immutable post-phase vapor + fixed velocities drive both passes.
        for(self.waterVaporMass,0..)|vapor,i|{
            var total_rate:f64=0;for(self.getNeighbours(i),0..)|n,j|total_rate+=if(self.atmosphericEdgeScratch.len==self.transformedPoints.len)self.atmosphericEdgeScratch[i][j] else self.atmosphericEdgeRate(i,n);
            const coefficient=AtmosphereWater.coefficient32(vapor,total_rate,dt);
            self.newWaterMass[i]=coefficient;

        }
        for(self.waterVaporMass,0..)|vapor,i|{
            var total_rate:f64=0;for(self.getNeighbours(i),0..)|n,j|total_rate+=if(self.atmosphericEdgeScratch.len==self.transformedPoints.len)self.atmosphericEdgeScratch[i][j] else self.atmosphericEdgeRate(i,n);
            var gathered:f64=@max(0,@as(f64,vapor)-@as(f64,self.newWaterMass[i])*total_rate);
            for(self.getNeighbours(i))|n|gathered+=@as(f64,self.newWaterMass[n])*self.cachedAtmosphericEdgeRate(n,i);
            self.newWaterVaporMass[i]=@floatCast(gathered);
        }
        std.mem.swap([]f32,&self.waterVaporMass,&self.newWaterVaporMass);
    }

    /// Compute partial pressure using ideal gas law, it is done in f64 as
    /// the amount of substance can get very high.
    /// Note: instead of using the gas constant, the Boltzmann constant is directly used
    /// as substanceDivider also accounts for the Avogadro constant (NA)
    pub inline fn getPartialPressure(substanceDivider: f64, temperature: f32, mass: f64) f64 {
        const k = 1.380649 * comptime std.math.pow(f64, 10, -23); // Boltzmann constant
        const waterPartialPressure = (mass * k * temperature) / substanceDivider; // Pa
        return waterPartialPressure;
    }

    pub inline fn getPartialPressures(substanceDivider: f64, temperatures: SimdVector, masses: SimdVector) SimdVector64 {
        // Intermediary computations are done if f64
        const k: SimdVector64 = @splat(1.380649 * comptime std.math.pow(f64, 10, -23)); // Boltzmann constant

        // Workaround as you can't do @floatCast with a vector
        // TODO: send issue to ziglang/zig
        // TODO: benchmark whether manually @floatCast'ing makes it slower than a naive non-SIMD approach
        const masses_f64 = blk: {
            var vector: @Vector(VECTOR_SIZE, f64) = undefined;
            comptime var i: usize = 0;
            inline while (i < VECTOR_SIZE) : (i += 1) {
                vector[i] = @as(f64, @floatCast(masses[i]));
            }
            break :blk vector;
        };

        const temperatures_f64 = blk: {
            var vector: @Vector(VECTOR_SIZE, f64) = undefined;
            comptime var i: usize = 0;
            inline while (i < VECTOR_SIZE) : (i += 1) {
                vector[i] = @as(f64, @floatCast(temperatures[i]));
            }
            break :blk vector;
        };

        const waterPartialPressures = (masses_f64 * k * temperatures_f64) / @as(SimdVector64, @splat(substanceDivider)); // Pa
        return waterPartialPressures;
    }

    /// Returns the mass of all the air above the given point's area, in 10⁹ kg
    pub inline fn getAirMass(self: Planet, idx: usize) f32 {
        // + 1 is because there will never be 0 kg of air (and if it's the case it breaks a bunch of computations)
        return self.waterVaporMass[idx] + self.averageNitrogenMass + self.averageOxygenMass + self.averageCarbonDioxideMass + 1;
    }

    pub inline fn getAirPressure(self: Planet, substanceDivider: f64, temperature: f32, vaporMass: f64) f32 {
        return @as(f32, @floatCast(getPartialPressure(substanceDivider, temperature, vaporMass + self.averageNitrogenMass + self.averageOxygenMass + self.averageCarbonDioxideMass + 1)));
    }

    /// Returns the pressure that air excerts on a given point, in Pascal.
    pub fn getAirPressureOfPoint(self: Planet, idx: usize) f32 {
        return self.getAirPressure(self.getSubstanceDivider(), self.temperature[idx], self.waterVaporMass[idx]);
    }

    /// Uses Tetens equation
    /// The fact that it is off for below 0°C isn't important as we're doing
    /// quite big approximations anyways
    fn getEquilibriumVaporPressure_Unoptimized(temperature: f32) f32 {
        return 0.61078 * @exp(17.27 * (temperature - 273.15) / (temperature + 237.3 - 273.15)) * 1000;
    }

    /// We precompute the values from getEquilibriumVaporPressure so that calling the function
    /// is faster.
    const equilibriumVaporPressures = blk: {
        const from = 0.0;
        const to = 1000.0;
        const step = 1.0;
        const arrayLength = @as(usize, @intFromFloat((to - from) / step));
        var values: [arrayLength]f32 = undefined;

        @setEvalBranchQuota(arrayLength * 10);
        var x: f32 = from;
        while (x < to) : (x += step) {
            const idx = @as(usize, @intFromFloat(x / step));
            values[idx] = getEquilibriumVaporPressure_Unoptimized(x);
            if (std.math.isInf(values[idx])) { // precision error
                values[idx] = 0;
            }
        }
        break :blk values;
    };

    inline fn lerp(a: f32, b: f32, t: f32) f32 {
        @setFloatMode(.optimized);
        return a * (1 - t) + b * t;
    }

    pub inline fn getEquilibriumVaporPressure(temperature: f32) f32 {
        @setFloatMode(.optimized);
        if (temperature >= 999 or temperature <= 0 or std.math.isNan(temperature)) {
            // This shouldn't be possible with default ranges, so no need to optimize
            return getEquilibriumVaporPressure_Unoptimized(temperature);
        } else {
            const idx = @as(u32, @intFromFloat(temperature));
            return lerp(equilibriumVaporPressures[idx], equilibriumVaporPressures[idx + 1], @rem(temperature, 1));
        }
    }

    // This function is implemented quite naively as indexing isn't easily parallelizable
    pub inline fn getEquilibriumVaporPressures(temperature: SimdVector) @Vector(VECTOR_SIZE, f64) {
        var vector: @Vector(VECTOR_SIZE, f64) = undefined;
        comptime var i: usize = 0;
        inline while (i < VECTOR_SIZE) : (i += 1) {
            vector[i] = getEquilibriumVaporPressure(temperature[i]);
        }
        return vector;
    }

    pub inline fn getEquilibriumVaporMasses(substanceDivider: f64, temperature: SimdVector) SimdVector {
        const k = 1.380649 * comptime std.math.pow(f64, 10, -23); // Boltzmann constant
        var vector: SimdVector = undefined;
        comptime var i: usize = 0;
        inline while (i < VECTOR_SIZE) : (i += 1) {
            const pressure = getEquilibriumVaporPressure(temperature[i]);
            const mass = (pressure * substanceDivider) / (temperature[i] * k);
            vector[i] = @as(f32, @floatCast(mass));
        }
        return vector;
    }

    pub inline fn getRelativeHumidity(substanceDivider: f64, temperature: f32, mass: f64) f32 {
        return @as(f32, @floatCast(getPartialPressure(substanceDivider, temperature, mass) / getEquilibriumVaporPressure(temperature)));
    }

    pub inline fn getRelativeHumidities(substanceDivider: f64, temperatures: SimdVector, masses: SimdVector) SimdVector {
        const results = getPartialPressures(substanceDivider, temperatures, masses) / getEquilibriumVaporPressures(temperatures);
        const results_f32 = blk: {
            var vector: @Vector(VECTOR_SIZE, f32) = undefined;
            comptime var i: usize = 0;
            inline while (i < VECTOR_SIZE) : (i += 1) {
                vector[i] = @as(f32, @floatCast(results[i]));
            }
            break :blk vector;
        };
        return results_f32;
    }

    /// Returns the constant used for computations with the perfect gas law
    pub fn getSubstanceDivider(self: Planet) f64 {
        // The mean atmosphere volume per point is approximately equal
        // to mean point area multiplied by the height of the troposphere (~12km)
        const meanAtmVolume: f64 = self.getMeanPointArea() * 12_000; // m³

        const NA = 6.02214076 * std.math.pow(f64, 10, 23); // NA = 6.02214076 × 10²³
        // Atmospheric volume accounted for amount of substance and 10¹² g units
        const substanceDivider: f64 = meanAtmVolume * 18.015 // there are 18.015g in a mole of water
        / std.math.pow(f64, 10, 12) // water mass is in 10⁹ kg (= 10¹² g)
        / NA; // account for Avogadro constant
        return substanceDivider;
    }

    inline fn sendWater(self: Planet, target: IndexVector, origin: IndexVector, shared: SimdVector, totalHeight: SimdVector, kmPerWaterMass: f32, shareFactor: f32) SimdVector {
        const elevation = blk: {
            var vector: SimdVector = undefined;
            comptime var i: usize = 0;
            inline while (i < VECTOR_SIZE) : (i += 1) {
                vector[i] = self.elevation[target[i]];
            }
            break :blk vector;
        };
        const waterMass = blk: {
            var vector: SimdVector = undefined;
            comptime var i: usize = 0;
            inline while (i < VECTOR_SIZE) : (i += 1) {
                vector[i] = self.waterMass[target[i]];
            }
            break :blk vector;
        };
        const targetTotalHeight = elevation + waterMass * @as(SimdVector, @splat(kmPerWaterMass));

        const doTransmit = totalHeight > targetTotalHeight;
        const originalTransmitted = if (self.worldMode == .origin)
            @min(shared, SurfacePhysics.heightLimitedMass(SimdVector, totalHeight - targetTotalHeight, @as(SimdVector, @splat(kmPerWaterMass)), @as(SimdVector, @splat(shareFactor))))
        else
            @min(shared, shared * (totalHeight - targetTotalHeight) / @as(SimdVector, @splat(kmPerWaterMass)) / @as(SimdVector, @splat(@as(f32, 2.0))));

        const zero = @as(SimdVector, @splat(@as(f32, 0.0)));
        var transmitted = @select(f32, doTransmit, originalTransmitted, zero);

        // Do not transfer to a point that is loaded in the current vector
        // This causes water to disappear
        for (@as([VECTOR_SIZE]usize, target), 0..) |target_elem, idx| {
            if (@reduce(.Or, origin == @as(IndexVector, @splat(target_elem)))) {
                transmitted[idx] = 0;
            }
        }

        {
            comptime var i: usize = 0;
            inline while (i < VECTOR_SIZE) : (i += 1) {
                self.newWaterMass[target[i]] += transmitted[i];
            }
        }
        return transmitted;
    }

    // fn sendWater(self: Planet, target: usize, shared: f32, totalHeight: f32, kmPerWaterMass: f32) f32 {
    // 	const targetTotalHeight = self.elevation[target] + self.waterMass[target] * kmPerWaterMass;
    // 	if (totalHeight > targetTotalHeight) {
    // 		var transmitted = @min(shared, shared * (totalHeight - targetTotalHeight) / 2 / kmPerWaterMass);
    // 		std.debug.assert(transmitted >= 0);
    // 		self.newWaterMass[target] += transmitted;
    // 		return transmitted;
    // 	} else {
    // 		return 0;
    // 	}
    // }

    fn sendWaterVapor(self: Planet, target: usize, shared: f32, selfMass: f32) f32 {
        const targetMass = self.waterVaporMass[target];
        if (selfMass > targetMass) {
            const transmitted = @min(shared, shared * (selfMass - targetMass));
            self.newWaterVaporMass[target] += transmitted;
            return transmitted;
        } else {
            return 0;
        }
    }

    /// Snapshot reads and sequential writes make colonization deterministic and race-free.
    /// Newly colonized populations inherit a mutated thermal optimum. Selection
    /// replaces a sparse population only with a better-adapted neighboring lineage.
    /// Optional Origin storage; use the live arena, never a copied allocator state.
    pub fn ensureMicrobeStorage(self: *Planet) !void {
        if (self.microbeCells.len == self.vertices.len) return;
        const cells = try self.simulationArena.allocator().alloc(Microbes.Cell, self.vertices.len);
        for (cells, 0..) |*cell, i| cell.* = Microbes.initialized(self.seed ^ (@as(u64, @intCast(i)) *% 0x9e3779b97f4a7c15));
        self.microbeCells = cells;
    }

    /// New-world choice only. Never silently erase a living sandbox.
    pub fn beginOrigin(self: *Planet) !void {
        if (self.worldMode == .origin) return;
        if (self.lifeforms.items.len != 0) return error.SandboxHasLife;
        for (self.vegetation) |cover| if (cover > 0) return error.SandboxHasLife;
        try self.ensureMicrobeStorage();
        self.worldMode = .origin;
        self.sandboxDefense=.{};
    }

    /// Explicit selected-patch target, never a persistent irrigation policy.
    /// The signed return is actual externally added/removed depth in metres.
    pub fn setWaterDepthMeters(self:*Planet,index:usize,target_m:f32) f32 {
        if(self.worldMode!=.origin or index>=self.waterMass.len or !std.math.isFinite(target_m) or target_m<0 or target_m>5)return std.math.nan(f32);
        const conversion=self.getKmPerWaterMass();
        if(!std.math.isFinite(conversion) or conversion<=0 or !std.math.isFinite(self.waterMass[index]))return std.math.nan(f32);
        const old=self.waterMass[index];
        self.waterMass[index]=(target_m/1000)/conversion;
        return (self.waterMass[index]-old)*conversion*1000;
    }

    /// Explicit fine-water player intervention; returns actual metres changed.
    /// Adds/removes water intentionally, not part of closed-world physics.
    pub fn adjustWaterDepth(self:*Planet,index:usize,delta_km:f32) f32 {
        if(self.worldMode!=.origin or index>=self.waterMass.len or !std.math.isFinite(delta_km) or @abs(delta_km)>0.00010001)return 0;
        const conversion=self.getKmPerWaterMass();
        const old=self.waterMass[index];
        self.waterMass[index]=@max(0,old+delta_km/conversion);
        return (self.waterMass[index]-old)*conversion*1000;
    }

    fn microbeEnvironment(self: *Planet, index: usize, light: f32) Microbes.Environment {
        const area = self.getMeanPointArea();
        return .{
            .temperature = self.temperature[index],
            .depth_km = self.waterMass[index] * self.getKmPerWaterMass(),
            .light = light,
            .carbon_available = @floatCast(@max(0, self.averageCarbonDioxideMass) * 1e9 / area * (12.0 / 44.0)),
            .oxygen_carbon_capacity = @floatCast(@max(0, self.averageOxygenMass) * 1e9 / area * (12.0 / 32.0)),
        };
    }

    fn applyMicrobeFlux(self: *Planet, flux: Microbes.Flux) void {
        // Atmospheric fields are average 10^9 kg gas per mesh point.
        // Colony fields are kg carbon/m². CO2:C:O2 mass ratios = 44:12:32.
        const area: f64 = self.getMeanPointArea();
        const scale = area / 1e9 / @as(f64, @floatFromInt(self.vertices.len));
        const net: f64 = @as(f64, flux.fixed) - flux.recycled;
        self.averageCarbonDioxideMass = @max(0, self.averageCarbonDioxideMass - net * scale * (44.0 / 12.0));
        self.averageOxygenMass = @max(0, self.averageOxygenMass + net * scale * (32.0 / 12.0));
        self.microbeStats.fixed_carbon += @as(f64, flux.fixed) * area;
        self.microbeStats.recycled_carbon += @as(f64, flux.recycled) * area;
    }

    pub fn seedEligibility(self:*Planet,index:usize) @import("../seed_eligibility.zig").Reason {
        if(self.worldMode!=.origin or index>=self.microbeCells.len or index>=self.waterMass.len or index>=self.temperature.len)return .invalid;
        const env=self.microbeEnvironment(index,1);
        return @import("../seed_eligibility.zig").evaluate(self.microbeCells[index],env.depth_km,env.temperature,env.carbon_available);
    }

    pub fn seedMicrobes(self: *Planet, index: usize) bool {
        if (self.seedEligibility(index)!=.eligible) return false;
        const env = self.microbeEnvironment(index, 1);
        if (!Microbes.habitable(env.depth_km, env.temperature)) return false;
        const fixed = Microbes.seed(&self.microbeCells[index], &self.microbeStats, env.carbon_available);
        if (fixed <= 0) return false;
        self.applyMicrobeFlux(.{ .fixed = fixed });
        return true;
    }

    /// Explicit player-supplied nutrient input, not an endogenous source.
    pub fn addMicrobeNutrients(self: *Planet, index: usize) bool {
        if (self.worldMode != .origin or index >= self.microbeCells.len) return false;
        if (self.microbeCells[index].nutrient >= 0.2) return false;
        const added = @min(0.01, 0.2 - self.microbeCells[index].nutrient);
        self.microbeCells[index].nutrient += added;
        self.microbeStats.nutrient_added += @as(f64, added) * self.getMeanPointArea();
        return true;
    }

    /// On-demand UI explanation, using the exact model predicate and actual
    /// adjacent cells. This does not advance simulation, resources or randomness.
    pub fn microbeRelocationOpportunity(self: *Planet, index: usize, cohort_slot: usize, game_time: f64) Microbes.RelocationOpportunity {
        if (self.worldMode != .origin or index >= self.microbeCells.len or self.microbeCells.len != self.vertices.len) return .{ .reason = .invalid };
        const adjacent = self.getNeighbours(index);
        var records: [6]Microbes.Neighbor = undefined;
        for (adjacent, 0..) |n, slot| records[slot] = .{ .index = n, .environment = self.microbeEnvironment(n, 1) };
        return Microbes.evaluateRelocation(self.microbeCells, index, cohort_slot, self.microbeEnvironment(index, 1), &records, game_time);
    }

    pub fn simulateMicrobes(self: *Planet, options: SimulationOptions) void {
        if (self.microbeCells.len != self.vertices.len) return;
        const dt = @max(0, options.dt * options.timeScale);
        if (dt <= 0) return;
        // Rebuild every tick; all player edits/load/reproduction are reflected.
        // OOM preserves the original full scans. No persistent or saved cache.
        const active:?[]u64=ActiveCells.init(self.allocator,self.microbeCells.len) catch null;
        defer if(active)|bits|self.allocator.free(bits);
        const WorldEcology=@import("../world_ecology.zig");const world=@import("../performance_details.zig").world_serial;
        WorldEcology.record(self,world,options.gameTime,0,0);const birth_start=self.microbeStats.births;var physiology_deaths:u64=0;
        const watch=&@import("../patch_watch.zig").current;
        const observing=if(watch.active and watch.owner==@intFromPtr(self))watch.beginTick(@intFromPtr(self),options.gameTime,@import("../patch_watch.zig").nowMs()) else false;
        for (self.microbeCells, 0..) |*cell, i| {
            if (Microbes.biomass(cell.*) <= 0 and cell.detritus <= 0) continue;
            if(active)|bits|ActiveCells.mark(bits,i);
            const light = @max(0, self.transformedPoints[i].norm().dot(options.solarVector)) * std.math.clamp(options.solarConstant / 1361, 0, 2);
            const before_cohorts=cell.cohorts;
            const flux = Microbes.step(cell, self.microbeEnvironment(i, light), dt);
            physiology_deaths +|= WorldEcology.physiologyDeaths(before_cohorts,cell.cohorts);
            if(observing)watch.recordFlux(i,flux.fixed,flux.recycled,flux.grazed);
            for(before_cohorts,0..)|old,slot|{
                if(old.biomass>0 and cell.cohorts[slot].biomass==0 and self.propaguleFeedback.failed(i,old.lineage,options.gameTime))self.propaguleTrackedLosses+|=1;
            }
            self.applyMicrobeFlux(flux);
            self.microbeStats.failed_patches +|= flux.failed_patches;
            self.microbeStats.grazed_carbon += @as(f64,flux.grazed)*self.getMeanPointArea();
            self.microbeStats.grazing_respired_carbon += @as(f64,flux.grazing_respired)*self.getMeanPointArea();
        }
        // A resident cohort may make at most one adjacent relocation per step.
        // Six neighbor records stay on the stack. The activity bitset uses one bit
        // per cell, and is rebuilt/freed within this tick.
        var move_cursor:usize=0;
        while(ActiveCells.nextOrLinear(active,&move_cursor,self.microbeCells.len))|i|{
            for (0..self.microbeCells[i].cohorts.len) |which| {
                const co = self.microbeCells[i].cohorts[which];
                if (co.biomass <= 0 or co.feeding <= 0 or co.mobility <= 0) continue;
                if (co.relocations > 0 and co.last_move_time == options.gameTime) continue;
                const adjacent = self.getNeighbours(i);
                var records: [6]Microbes.Neighbor = undefined;
                for (adjacent, 0..) |n, slot| records[slot] = .{ .index = n, .environment = self.microbeEnvironment(n, 1) };
                const moved = Microbes.relocate(self.microbeCells, i, which, self.microbeEnvironment(i, 1), &records, dt, options.gameTime);
                if (moved.moved) {
                    if(active)|bits|ActiveCells.mark(bits,moved.to);
                    self.propaguleFeedback.forget(co.lineage);
                    self.applyMicrobeFlux(.{ .recycled = moved.respired });
                    self.microbeStats.relocations +|= 1;
                    self.microbeStats.movement_respired_carbon += @as(f64, moved.respired) * self.getMeanPointArea();
                }
            }
        }
        // All growth precedes dispersal. Newborn credits start at zero, so no
        // propagule can grow/reproduce again merely due to grid iteration order.
        var birth_cursor:usize=0;
        while(ActiveCells.nextOrLinear(active,&birth_cursor,self.microbeCells.len))|i|{
            const cell=&self.microbeCells[i];
            if (Microbes.biomass(cell.*) <= 0) continue;
            const donor_start:usize = @intCast(Microbes.random(&cell.rng) % cell.cohorts.len);
            for (0..cell.cohorts.len) |donor_offset| {
                const cohort = (donor_start + donor_offset) % cell.cohorts.len;
                if(cell.cohorts[cohort].reproduction_credit>=0.01 and cell.cohorts[cohort].biomass>=0.02){
                    const adjacent=self.getNeighbours(i);
                    const n=adjacent[@intCast(Microbes.random(&cell.rng)%adjacent.len)];
                    // Pentagon adjacency pads with self: not a dispersal attempt.
                    if(n==i)continue;
                    const env=self.microbeEnvironment(n,1);
                    self.propaguleAttempts+|=1;
                    // Exploration includes harsh real habitats; no favorable-condition gate.
                    if(std.math.isFinite(env.depth_km) and std.math.isFinite(env.temperature)){
                        const lineage=self.microbeStats.next_lineage;
                        if(Microbes.propagate(cell,cohort,&self.microbeCells[n],&self.microbeStats)){
                            if(active)|bits|ActiveCells.mark(bits,n);
                            self.propaguleArrivals+|=1;self.propaguleFeedback.arrived(i,n,lineage,options.gameTime);
                            continue;
                        }
                    }
                }
                if (cell.cohorts[cohort].reproduction_credit < 0.04) continue;
                if (Microbes.reproduce(cell, cohort, cell, &self.microbeStats, true)) continue;
                const neighbors = self.getNeighbours(i);
                const start: usize = @intCast(Microbes.random(&cell.rng) % neighbors.len);
                for (0..neighbors.len) |offset| {
                    const n = neighbors[(start + offset) % neighbors.len];
                    const env = self.microbeEnvironment(n, 1);
                    if (!Microbes.habitable(env.depth_km, env.temperature)) continue;
                    if (Microbes.reproduce(cell, cohort, &self.microbeCells[n], &self.microbeStats, true)){if(active)|bits|ActiveCells.mark(bits,n);break;}
                }
            }
        }
        WorldEcology.record(self,world,options.gameTime+dt,self.microbeStats.births-|birth_start,physiology_deaths);
        if(self.microbeStats.births==std.math.maxInt(u64))WorldEcology.markSaturated(self,world);
        if(observing)watch.finishPopulationTick(options.gameTime,dt,@import("../patch_watch.zig").Watch.population(self.microbeCells[watch.cell].cohorts));
    }

    pub fn simulateVegetation(self: *Planet, options: SimulationOptions, start: usize, end: usize) void {
        const dt = @max(0, options.dt * options.timeScale);
        @memcpy(self.vegetationSnapshot, self.vegetation);
        self.plantColorWavelength = 530;
        for (start..end) |i| {
            const light = @max(0, self.transformedPoints[i].norm().dot(options.solarVector));
            var cover = Ecology.growTough(self.vegetationSnapshot[i], self.temperature[i], self.plantTraits[i].optimum, self.waterMass[i] * self.getKmPerWaterMass(), light, self.averageCarbonDioxideMass > 0, dt,self.plantTraits[i].toughness);
            if (self.waterMass[i] * self.getKmPerWaterMass() <= 0.0005 and self.temperature[i] > 250 and self.temperature[i] < 350) {
                for (self.getNeighbours(i)) |n| {
                    if (self.vegetationSnapshot[n] < 0.25 or self.plantTraits[n].toughness>=1) continue;
                    if (cover < 0.0001 or (cover < 0.35 and Ecology.fitness(self.temperature[i], self.plantTraits[n].optimum) > Ecology.fitness(self.temperature[i], self.plantTraits[i].optimum) + 0.1)) {
                        if(self.sandboxDefense.enabled or self.plantTraits[n].toughness!=0){
                            const gift=@min(@as(f32,0.08),dt/86400*self.vegetationSnapshot[n])*(1-self.plantTraits[n].toughness);
                            if(!std.math.isFinite(gift) or gift<=0 or !(cover+gift>cover))continue;
                        }
                        const epoch: u64 = @intFromFloat(@max(0, options.gameTime / 3600));
                        const child = Ecology.offspringWithDefense(self.plantTraits[n], self.seed ^ (@as(u64, @intCast(i)) *% 0x9e3779b97f4a7c15) ^ epoch,self.sandboxDefense);
                        if (Ecology.fitness(self.temperature[i], child.optimum) < 0.15) continue;
                        self.plantTraits[i] = child;
                        self.plantGenerations = @max(self.plantGenerations, child.generation);
                        self.plantBirths += 1;
                        cover += if(self.plantTraits[n].toughness==0) @min(0.08, dt / 86400 * self.vegetationSnapshot[n]) else @min(0.08, dt / 86400 * self.vegetationSnapshot[n])*(1-self.plantTraits[n].toughness);
                        break;
                    }
                }
            }
            self.vegetation[i] = std.math.clamp(cover, 0, 1);
            const gas = @min(self.averageCarbonDioxideMass, @as(f64, cover * light * dt * 0.1 / self.getMeanPointArea()));
            self.averageCarbonDioxideMass -= gas;
            self.averageOxygenMass += gas;
        }
    }

    pub fn simulate(self: *Planet, loop: *EventLoop, options: SimulationOptions) void {
        var qa_clock=emscripten_get_now();
        @import("../plant_receipt.zig").begin(self,@import("../performance_details.zig").world_serial,options.gameTime,@max(0,options.dt*options.timeScale));
        const ecology_births=self.rabbitBirths;const ecology_deaths=self.rabbitDeaths;
        if(self.worldMode==.sandbox)@import("../world_ecology.zig").record(self,@import("../performance_details.zig").world_serial,options.gameTime,0,0);

        //const zone = tracy.ZoneN(@src(), "Simulate planet");
        //defer zone.End();

        const newTemp = self.newTemperature;
        // Fill newTemp with the current temperatures
        // NOTE: we can copy using memcpy if another way to avoid negative values is found
        for (self.vertices, 0..) |_, i| {
            newTemp[i] = @max(0, self.temperature[i]); // temperature may never go below 0°K
        }

        // TODO: mix both
        if (USE_OPENCL and self.clContext != null) {
            const clContext = self.clContext.?;
            self.simulateTemperature_OpenCL(clContext, options, 0, self.temperature.len);
            std.log.info("new temp at 0: {d}", .{self.newTemperature[0]});
        } else {
            // TODO: allocate jobs using FixedBufferAllocator for performance
            var jobs: [32]*Job(void) = undefined;
            const parallelness = @min(loop.getParallelCount(), jobs.len);
            const pointCount = self.vertices.len;
            var i: usize = 0;
            while (i < parallelness) : (i += 1) {
                const start = pointCount / parallelness * i;
                const end = if (i == parallelness - 1) pointCount else pointCount / parallelness * (i + 1);
                const job = Job(void).create(loop) catch unreachable;
                job.call(simulateTemperature, .{ self, loop, options, start, end }) catch unreachable;
                jobs[i] = job;
            }

            i = 0;
            while (i < parallelness) : (i += 1) {
                jobs[i].wait();
            }
        }

        // Finish by swapping the new temperature
        std.mem.swap([]f32, &self.temperature, &self.newTemperature);

        qa_wind_profile[0]+=emscripten_get_now()-qa_clock;qa_clock=emscripten_get_now();
        const dt = options.dt * options.timeScale;
        // Disable water simulation when timescale is above 100 000
        if (dt < 15000) {
            var iteration: usize = 0;
            const numIterations: usize = 1;
            while (iteration < numIterations) : (iteration += 1) {
                @memcpy(self.newWaterMass, self.waterMass);
                @memcpy(self.newWaterVaporMass, self.waterVaporMass);

                {
                    var jobs: [32]*Job(void) = undefined;
                    const parallelness = @min(loop.getParallelCount(), jobs.len);
                    const pointCount = self.vertices.len;
                    var i: usize = 0;
                    while (i < parallelness) : (i += 1) {
                        const start = pointCount / parallelness * i;
                        const end = if (i == parallelness - 1) pointCount else pointCount / parallelness * (i + 1);
                        const job = Job(void).create(loop) catch unreachable;
                        job.call(simulateWater, .{ self, loop, options, numIterations, start, end }) catch unreachable;
                        jobs[i] = job;
                    }

                    i = 0;
                    while (i < parallelness) : (i += 1) {
                        jobs[i].wait();
                    }
                }

                std.mem.swap([]f32, &self.waterMass, &self.newWaterMass);
                std.mem.swap([]f32, &self.waterVaporMass, &self.newWaterVaporMass);
                qa_wind_profile[1]+=emscripten_get_now()-qa_clock;qa_clock=emscripten_get_now();
                self.simulateAtmosphereWater(dt);
                qa_wind_profile[2]+=emscripten_get_now()-qa_clock;qa_clock=emscripten_get_now();
            }
        } else {
            // TODO: use a global water level
            // this can work as high timescales like that should only be possible
            // in the geologic timescale (when plate tectonics still happens)
        }

        // Geologic simulation only happens when the time scale is more than 1 year per second
        if (dt > 365 * std.time.ns_per_day) {}

        if (options.gameTime > self.nextMeteorite and false) {
            var prng = std.rand.DefaultPrng.init(@as(u64, @intFromFloat(options.gameTime)));
            const random = prng.random();
            const impactCenter = random.intRangeLessThanBiased(usize, 0, self.vertices.len);
            std.log.info("METEORITE AT {d}", .{impactCenter});

            // TODO: use the random composition of meteorite
            const waterComposition = 1; // 100%
            const meteoriteMass = 0; // TODO
            _ = waterComposition;
            _ = meteoriteMass;

            // TODO: increase average gas
            // TODO: the meteorite has a chance of not reaching ground if atmosphere is thick enough
            // TODO: technically this just depends on the time era, meteorites hit Earth when it was early in its formation only

            // Spread the impact on multiple points near the impact center
            var hitPoints = std.BoundedArray(usize, 7).init(0) catch unreachable;
            hitPoints.append(impactCenter) catch unreachable;
            for (hitPoints.constSlice()) |point| {
                for (self.getNeighbours(point)) |neighbour| {
                    hitPoints.append(neighbour) catch unreachable;
                }
            }

            // Make the impact on the selected points
            for (hitPoints.constSlice()) |point| {
                self.waterMass[point] += 5 / self.getKmPerWaterMass();
                self.temperature[point] = 473.15;
            }
            self.nextMeteorite = options.gameTime + 1 * 8640 + 5 * random.float(f64) * 8640;
        }

        if (options.timeScale < 100000) {
            const zone = tracy.ZoneN(@src(), "Life Simulation");
            defer zone.End();

            self.lifeformsLock.lock();
            defer self.lifeformsLock.unlock();
            // Each original organism can produce at most one child per tick.
            // Reserve before taking pointers, and walk backwards: removing the
            // current organism cannot skip an earlier one. Newborns wait until
            // the next tick, and appends cannot invalidate active pointers.
            const initial_count = self.lifeforms.items.len;
            self.lifeforms.ensureTotalCapacity(self.simulationArena.allocator(), initial_count * 2) catch {
                std.log.err("Not enough memory for life simulation", .{});
                return;
            };
            var remaining = initial_count;
            while (remaining > 0) {
                remaining -= 1;
                self.lifeforms.items[remaining].aiStep(self, options);
            }
        } else {
            // TODO: switch down to much simplified and "globalized" life simulation
        }

        qa_wind_profile[3]+=emscripten_get_now()-qa_clock;qa_clock=emscripten_get_now();
        if (self.worldMode == .origin) self.simulateMicrobes(options) else self.simulateVegetation(options, 0, self.vegetation.len);
        @import("../plant_receipt.zig").finish(self,@import("../performance_details.zig").world_serial);
        if(self.worldMode==.sandbox)@import("../world_ecology.zig").record(self,@import("../performance_details.zig").world_serial,options.gameTime+@max(0,options.dt*options.timeScale),self.rabbitBirths-|ecology_births,self.rabbitDeaths-|ecology_deaths);
        if(self.worldMode==.sandbox and (self.rabbitBirths==std.math.maxInt(u64) or self.rabbitDeaths==std.math.maxInt(u64)))@import("../world_ecology.zig").markSaturated(self,@import("../performance_details.zig").world_serial);

        qa_wind_profile[4]+=emscripten_get_now()-qa_clock;

    }

    /// Simulation already owns lifeformsLock and reserved capacity for births.
    pub fn addLifeformDuringStep(self: *Planet, lifeform: Lifeform) void {
        std.debug.assert(self.lifeforms.items.len < self.lifeforms.capacity);
        self.lifeforms.appendAssumeCapacity(lifeform);
    }

    pub fn addLifeform(self: *Planet, lifeform: Lifeform) !void {
        if (self.worldMode == .origin) return error.ConsumersNotModeled;
        self.lifeformsLock.lock();
        defer self.lifeformsLock.unlock();

        try self.lifeforms.append(self.simulationArena.allocator(), lifeform);
    }

    pub fn deinit(self: Planet) void {
        // wait for pending jobs
        if (self.normalComputeJob) |job| {
            while (!job.isCompleted()) {
                std.atomic.spinLoopHint();
            }
            job.deinit();
        }

        // de-allocate
        self.allocator.free(self.atmosphericEdgeScratch);
        self.allocator.free(self.atmosphericWindScratch);
        self.simulationArena.deinit();

        // Mesh lifetime is managed manually by planet, for efficiency
        self.mesh.deinit(self.allocator);
        self.atmosphereMesh.deinit(self.allocator);
    }
};

// This regression calls the actual per-tick cache branch, not a surrogate batch.
test "atmospheric target validation refreshes geometry and preserves invalid fallback" {
    var points = [_]Vec3{ Vec3.new(1, 2, 3), Vec3.new(-2, 3, 4), Vec3.new(0, 0, -0.0) };
    var neighbors = [_][6]u32{ .{ 0, 1, 2, 1, 2, 0 }, .{ 0, 1, 2, 0, 2, 1 }, .{ 0, 1, 2, 0, 1, 2 } };
    var winds = [_][3]f32{ .{ 0.1, -0.2, 0.3 }, .{ -0.4, 0.5, 0.6 }, .{ 0, 1, 0 } };
    var rates: [3][6]f64 = undefined;
    var p: Planet = undefined;
    p.transformedPoints = &points;
    p.verticesNeighbours = &neighbors;
    p.atmosphericWindScratch = &winds;
    p.atmosphericEdgeScratch = &rates;
    for (0..4) |pass| {
        points[1] = Vec3.new(if (pass == 1) std.math.nan(f32) else -2, 3, 4);
        winds[0][0] = if (pass == 2) std.math.inf(f32) else 0.1;
        if (pass == 3) neighbors[0] = .{ 2, 1, 0, 2, 0, 1 };
        p.rebuildAtmosphericEdgeScratch();
        for (0..3) |i| for (p.getNeighbours(i), 0..) |j, slot| {
            const a = points[i]; const b = points[j]; const w = winds[i];
            const expected = AtmosphereWater.edgeRate(.{ a.x(), a.y(), a.z() }, .{ b.x(), b.y(), b.z() }, .{ w[0], w[1], w[2] });
            try std.testing.expectEqual(@as(u64, @bitCast(expected)), @as(u64, @bitCast(rates[i][slot])));
        };
    }
    // Allocation failure keeps the existing generic uncached lookup available.
    var failing = std.testing.FailingAllocator.init(std.testing.allocator, .{ .fail_index = 0 });
    p.allocator = failing.allocator();
    p.atmosphericEdgeScratch = &.{};
    p.rebuildAtmosphericEdgeScratch();
    try std.testing.expectEqual(@as(usize, 0), p.atmosphericEdgeScratch.len);
    try std.testing.expectEqual(@as(u64, @bitCast(p.atmosphericEdgeRate(0, 1))), @as(u64, @bitCast(p.cachedAtmosphericEdgeRate(0, 1))));
}
