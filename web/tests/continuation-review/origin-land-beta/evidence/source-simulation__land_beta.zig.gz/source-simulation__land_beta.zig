const R=@import("microbes.zig").RootMutation;
pub const Config=struct{enabled:bool=false,law:u8=0,root_mutation:R.Config=.{},pub fn valid(c:@This())bool{return if(!c.enabled)c.law==0 and c.root_mutation.law==0 and !c.root_mutation.enabled and c.root_mutation.stream_seed==0 else c.law==1 and c.root_mutation.law==1 and c.root_mutation.enabled;}};
