; ModuleID = 'BitcodeBuffer'
source_filename = "probe"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite) uwtable
define dso_local void @baseline(ptr nocapture nonnull readonly align 4 %0, ptr nocapture nonnull readonly align 4 %1, ptr nocapture nonnull readonly align 4 %2, ptr nocapture nonnull writeonly align 8 %3, i64 %4) local_unnamed_addr #0 !dbg !1911 {
Entry:
  %5 = alloca [24 x i8], align 4
  call void @llvm.dbg.value(metadata ptr %0, metadata !1926, metadata !DIExpression()), !dbg !1927
  call void @llvm.dbg.value(metadata ptr %1, metadata !1928, metadata !DIExpression()), !dbg !1927
  call void @llvm.dbg.value(metadata ptr %2, metadata !1929, metadata !DIExpression()), !dbg !1927
  call void @llvm.dbg.value(metadata ptr %3, metadata !1930, metadata !DIExpression()), !dbg !1927
  call void @llvm.dbg.value(metadata i64 %4, metadata !1931, metadata !DIExpression()), !dbg !1927
  %.not = icmp eq i64 %4, 0, !dbg !1932
  br i1 %.not, label %Else, label %Then, !dbg !1932

Then:                                             ; preds = %Entry, %Else1
  %.sroa.0.017 = phi i64 [ %204, %Else1 ], [ 0, %Entry ]
  call void @llvm.dbg.value(metadata i64 %.sroa.0.017, metadata !1937, metadata !DIExpression()), !dbg !1939
  %6 = getelementptr inbounds [6 x i32], ptr %2, i64 %.sroa.0.017, !dbg !1940
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(24) %5, ptr noundef nonnull align 4 dereferenceable(24) %6, i64 24, i1 false), !dbg !1940
  %7 = getelementptr inbounds [3 x float], ptr %0, i64 %.sroa.0.017
  %.sroa.2.0..sroa_idx = getelementptr inbounds i8, ptr %7, i64 4
  %.sroa.3.0..sroa_idx = getelementptr inbounds i8, ptr %7, i64 8
  %8 = getelementptr inbounds [3 x float], ptr %1, i64 %.sroa.0.017
  %.sroa.27.0..sroa_idx = getelementptr inbounds i8, ptr %8, i64 4
  %.sroa.38.0..sroa_idx = getelementptr inbounds i8, ptr %8, i64 8
  br label %Then1, !dbg !1942

Else:                                             ; preds = %Else1, %Entry
  ret void, !dbg !1947

Then1:                                            ; preds = %atmosphere_water.edgeRate.exit.2, %Then
  %.sroa.01.016 = phi i64 [ 0, %Then ], [ %203, %atmosphere_water.edgeRate.exit.2 ]
  %9 = getelementptr inbounds [6 x i32], ptr %5, i64 0, i64 %.sroa.01.016, !dbg !1949
  %10 = load i32, ptr %9, align 4, !dbg !1949
  call void @llvm.dbg.value(metadata i32 %10, metadata !1952, metadata !DIExpression()), !dbg !1953
  call void @llvm.dbg.value(metadata i64 %.sroa.01.016, metadata !1954, metadata !DIExpression()), !dbg !1953
  %.sroa.02.0.copyload = load float, ptr %7, align 4, !dbg !1955
  tail call void @llvm.dbg.value(metadata float %.sroa.02.0.copyload, metadata !1956, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !1957
  %.sroa.2.0.copyload = load float, ptr %.sroa.2.0..sroa_idx, align 4, !dbg !1955
  tail call void @llvm.dbg.value(metadata float %.sroa.2.0.copyload, metadata !1956, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !1957
  %.sroa.3.0.copyload = load float, ptr %.sroa.3.0..sroa_idx, align 4, !dbg !1955
  tail call void @llvm.dbg.value(metadata float %.sroa.3.0.copyload, metadata !1956, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !1957
  %11 = zext i32 %10 to i64, !dbg !1958
  %12 = getelementptr inbounds [3 x float], ptr %0, i64 %11, !dbg !1958
  %.sroa.03.0.copyload = load float, ptr %12, align 4, !dbg !1958
  tail call void @llvm.dbg.value(metadata float %.sroa.03.0.copyload, metadata !1959, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !1957
  %.sroa.24.0..sroa_idx = getelementptr inbounds i8, ptr %12, i64 4, !dbg !1958
  %.sroa.24.0.copyload = load float, ptr %.sroa.24.0..sroa_idx, align 4, !dbg !1958
  tail call void @llvm.dbg.value(metadata float %.sroa.24.0.copyload, metadata !1959, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !1957
  %.sroa.35.0..sroa_idx = getelementptr inbounds i8, ptr %12, i64 8, !dbg !1958
  %.sroa.35.0.copyload = load float, ptr %.sroa.35.0..sroa_idx, align 4, !dbg !1958
  tail call void @llvm.dbg.value(metadata float %.sroa.35.0.copyload, metadata !1959, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !1957
  %.sroa.06.0.copyload = load float, ptr %8, align 4, !dbg !1960
  tail call void @llvm.dbg.value(metadata float %.sroa.06.0.copyload, metadata !1961, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !1957
  %.sroa.27.0.copyload = load float, ptr %.sroa.27.0..sroa_idx, align 4, !dbg !1960
  tail call void @llvm.dbg.value(metadata float %.sroa.27.0.copyload, metadata !1961, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !1957
  %.sroa.38.0.copyload = load float, ptr %.sroa.38.0..sroa_idx, align 4, !dbg !1960
  tail call void @llvm.dbg.value(metadata float %.sroa.38.0.copyload, metadata !1961, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !1957
  %13 = getelementptr inbounds [6 x double], ptr %3, i64 %.sroa.0.017, i64 %.sroa.01.016, !dbg !1962
  %14 = fpext float %.sroa.02.0.copyload to double, !dbg !1964
  %15 = fpext float %.sroa.2.0.copyload to double, !dbg !1964
  %16 = fpext float %.sroa.3.0.copyload to double, !dbg !1964
  tail call void @llvm.dbg.value(metadata double %14, metadata !1965, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %15, metadata !1965, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %16, metadata !1965, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !1972
  %17 = fpext float %.sroa.03.0.copyload to double, !dbg !1974
  %18 = fpext float %.sroa.24.0.copyload to double, !dbg !1974
  %19 = fpext float %.sroa.35.0.copyload to double, !dbg !1974
  tail call void @llvm.dbg.value(metadata double %17, metadata !1975, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %18, metadata !1975, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %19, metadata !1975, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !1972
  %20 = fpext float %.sroa.06.0.copyload to double, !dbg !1976
  %21 = fpext float %.sroa.27.0.copyload to double, !dbg !1976
  %22 = fpext float %.sroa.38.0.copyload to double, !dbg !1976
  tail call void @llvm.dbg.value(metadata double %20, metadata !1977, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %21, metadata !1977, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %22, metadata !1977, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !1972
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !1978, metadata !DIExpression()), !dbg !1972
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !1979, metadata !DIExpression()), !dbg !1972
  call void @llvm.dbg.value(metadata i64 0, metadata !1980, metadata !DIExpression()), !dbg !1985
  call void @llvm.dbg.value(metadata double %14, metadata !1986, metadata !DIExpression()), !dbg !1991
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !1996
  %23 = tail call double @llvm.fabs.f64(double %14), !dbg !1997
  %24 = bitcast double %23 to i64, !dbg !1997
  %25 = icmp ult i64 %24, 9218868437227405312, !dbg !1998
  br i1 %25, label %Then3.i, label %atmosphere_water.edgeRate.exit, !dbg !2000

Then3.i:                                          ; preds = %Then1
  call void @llvm.dbg.value(metadata double %17, metadata !1986, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2007
  %26 = tail call double @llvm.fabs.f64(double %17), !dbg !2008
  %27 = bitcast double %26 to i64, !dbg !2008
  %28 = icmp ult i64 %27, 9218868437227405312, !dbg !2009
  br i1 %28, label %Then5.i, label %atmosphere_water.edgeRate.exit, !dbg !2010

Then5.i:                                          ; preds = %Then3.i
  call void @llvm.dbg.value(metadata double %20, metadata !1986, metadata !DIExpression()), !dbg !2013
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2017
  %29 = tail call double @llvm.fabs.f64(double %20), !dbg !2018
  %30 = bitcast double %29 to i64, !dbg !2018
  %31 = icmp ult i64 %30, 9218868437227405312, !dbg !2019
  br i1 %31, label %Then7.i, label %atmosphere_water.edgeRate.exit, !dbg !2020

Then7.i:                                          ; preds = %Then5.i
  %32 = fsub double %17, %14, !dbg !2022
  call void @llvm.dbg.value(metadata double undef, metadata !2024, metadata !DIExpression()), !dbg !1972
  %33 = fmul double %32, %32, !dbg !2025
  call void @llvm.dbg.value(metadata double %33, metadata !1978, metadata !DIExpression()), !dbg !1972
  %34 = fmul double %32, %20, !dbg !2027
  %35 = fadd double %34, 0.000000e+00, !dbg !2029
  call void @llvm.dbg.value(metadata double %35, metadata !1979, metadata !DIExpression()), !dbg !1972
  call void @llvm.dbg.value(metadata i64 1, metadata !1980, metadata !DIExpression()), !dbg !1985
  call void @llvm.dbg.value(metadata double %15, metadata !1986, metadata !DIExpression()), !dbg !1991
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !1996
  %36 = tail call double @llvm.fabs.f64(double %15), !dbg !1997
  %37 = bitcast double %36 to i64, !dbg !1997
  %38 = icmp ult i64 %37, 9218868437227405312, !dbg !1998
  br i1 %38, label %Then3.1.i, label %atmosphere_water.edgeRate.exit, !dbg !2000

Then3.1.i:                                        ; preds = %Then7.i
  call void @llvm.dbg.value(metadata double %18, metadata !1986, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2007
  %39 = tail call double @llvm.fabs.f64(double %18), !dbg !2008
  %40 = bitcast double %39 to i64, !dbg !2008
  %41 = icmp ult i64 %40, 9218868437227405312, !dbg !2009
  br i1 %41, label %Then5.1.i, label %atmosphere_water.edgeRate.exit, !dbg !2010

Then5.1.i:                                        ; preds = %Then3.1.i
  call void @llvm.dbg.value(metadata double %21, metadata !1986, metadata !DIExpression()), !dbg !2013
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2017
  %42 = tail call double @llvm.fabs.f64(double %21), !dbg !2018
  %43 = bitcast double %42 to i64, !dbg !2018
  %44 = icmp ult i64 %43, 9218868437227405312, !dbg !2019
  br i1 %44, label %Then7.1.i, label %atmosphere_water.edgeRate.exit, !dbg !2020

Then7.1.i:                                        ; preds = %Then5.1.i
  %45 = fsub double %18, %15, !dbg !2022
  call void @llvm.dbg.value(metadata double undef, metadata !2024, metadata !DIExpression()), !dbg !1972
  %46 = fmul double %45, %45, !dbg !2025
  %47 = fadd double %33, %46, !dbg !2030
  call void @llvm.dbg.value(metadata double %47, metadata !1978, metadata !DIExpression()), !dbg !1972
  %48 = fmul double %45, %21, !dbg !2027
  %49 = fadd double %35, %48, !dbg !2029
  call void @llvm.dbg.value(metadata double %49, metadata !1979, metadata !DIExpression()), !dbg !1972
  call void @llvm.dbg.value(metadata i64 2, metadata !1980, metadata !DIExpression()), !dbg !1985
  call void @llvm.dbg.value(metadata double %16, metadata !1986, metadata !DIExpression()), !dbg !1991
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !1996
  %50 = tail call double @llvm.fabs.f64(double %16), !dbg !1997
  %51 = bitcast double %50 to i64, !dbg !1997
  %52 = icmp ult i64 %51, 9218868437227405312, !dbg !1998
  br i1 %52, label %Then3.2.i, label %atmosphere_water.edgeRate.exit, !dbg !2000

Then3.2.i:                                        ; preds = %Then7.1.i
  call void @llvm.dbg.value(metadata double %19, metadata !1986, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2007
  %53 = tail call double @llvm.fabs.f64(double %19), !dbg !2008
  %54 = bitcast double %53 to i64, !dbg !2008
  %55 = icmp ult i64 %54, 9218868437227405312, !dbg !2009
  br i1 %55, label %Then5.2.i, label %atmosphere_water.edgeRate.exit, !dbg !2010

Then5.2.i:                                        ; preds = %Then3.2.i
  call void @llvm.dbg.value(metadata double %22, metadata !1986, metadata !DIExpression()), !dbg !2013
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2017
  %56 = tail call double @llvm.fabs.f64(double %22), !dbg !2018
  %57 = bitcast double %56 to i64, !dbg !2018
  %58 = icmp ult i64 %57, 9218868437227405312, !dbg !2019
  br i1 %58, label %Then7.2.i, label %atmosphere_water.edgeRate.exit, !dbg !2020

Then7.2.i:                                        ; preds = %Then5.2.i
  %59 = fsub double %19, %16, !dbg !2022
  call void @llvm.dbg.value(metadata double undef, metadata !2024, metadata !DIExpression()), !dbg !1972
  %60 = fmul double %59, %59, !dbg !2025
  %61 = fadd double %47, %60, !dbg !2030
  call void @llvm.dbg.value(metadata double %61, metadata !1978, metadata !DIExpression()), !dbg !1972
  %62 = fmul double %59, %22, !dbg !2027
  %63 = fadd double %49, %62, !dbg !2029
  call void @llvm.dbg.value(metadata double %63, metadata !1979, metadata !DIExpression()), !dbg !1972
  %64 = fcmp ugt double %61, 0.000000e+00, !dbg !2031
  br i1 %64, label %Else14.i, label %atmosphere_water.edgeRate.exit, !dbg !2033

Else14.i:                                         ; preds = %Then7.2.i
  call void @llvm.dbg.value(metadata double %61, metadata !1986, metadata !DIExpression()), !dbg !2035
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2039
  %65 = tail call double @llvm.fabs.f64(double %61), !dbg !2040
  %66 = bitcast double %65 to i64, !dbg !2040
  %67 = icmp ult i64 %66, 9218868437227405312, !dbg !2041
  br i1 %67, label %Else15.i, label %atmosphere_water.edgeRate.exit, !dbg !2042

Else15.i:                                         ; preds = %Else14.i
  call void @llvm.dbg.value(metadata double %63, metadata !1986, metadata !DIExpression()), !dbg !2045
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2049
  %68 = tail call double @llvm.fabs.f64(double %63), !dbg !2050
  %69 = bitcast double %68 to i64, !dbg !2050
  %70 = icmp ult i64 %69, 9218868437227405312, !dbg !2051
  br i1 %70, label %Else16.i, label %atmosphere_water.edgeRate.exit, !dbg !2052

Else16.i:                                         ; preds = %Else15.i
  %71 = fdiv double %63, %61, !dbg !2054
  %72 = tail call double @llvm.maxnum.f64(double %71, double 0.000000e+00), !dbg !2054
  br label %atmosphere_water.edgeRate.exit

atmosphere_water.edgeRate.exit:                   ; preds = %Then1, %Then3.i, %Then5.i, %Then7.i, %Then3.1.i, %Then5.1.i, %Then7.1.i, %Then3.2.i, %Then5.2.i, %Then7.2.i, %Else14.i, %Else15.i, %Else16.i
  %common.ret.op.i = phi double [ %72, %Else16.i ], [ 0.000000e+00, %Else14.i ], [ 0.000000e+00, %Then7.2.i ], [ 0.000000e+00, %Else15.i ], [ 0.000000e+00, %Then5.2.i ], [ 0.000000e+00, %Then3.2.i ], [ 0.000000e+00, %Then7.1.i ], [ 0.000000e+00, %Then5.1.i ], [ 0.000000e+00, %Then3.1.i ], [ 0.000000e+00, %Then7.i ], [ 0.000000e+00, %Then3.i ], [ 0.000000e+00, %Then1 ], [ 0.000000e+00, %Then5.i ]
  store double %common.ret.op.i, ptr %13, align 8, !dbg !2055
  %73 = add nuw nsw i64 %.sroa.01.016, 1, !dbg !2056
  %74 = getelementptr inbounds [6 x i32], ptr %5, i64 0, i64 %73, !dbg !1949
  %75 = load i32, ptr %74, align 4, !dbg !1949
  call void @llvm.dbg.value(metadata i32 %75, metadata !1952, metadata !DIExpression()), !dbg !1953
  call void @llvm.dbg.value(metadata i64 %73, metadata !1954, metadata !DIExpression()), !dbg !1953
  %.sroa.02.0.copyload.1 = load float, ptr %7, align 4, !dbg !1955
  tail call void @llvm.dbg.value(metadata float %.sroa.02.0.copyload.1, metadata !1956, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !1957
  %.sroa.2.0.copyload.1 = load float, ptr %.sroa.2.0..sroa_idx, align 4, !dbg !1955
  tail call void @llvm.dbg.value(metadata float %.sroa.2.0.copyload.1, metadata !1956, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !1957
  %.sroa.3.0.copyload.1 = load float, ptr %.sroa.3.0..sroa_idx, align 4, !dbg !1955
  tail call void @llvm.dbg.value(metadata float %.sroa.3.0.copyload.1, metadata !1956, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !1957
  %76 = zext i32 %75 to i64, !dbg !1958
  %77 = getelementptr inbounds [3 x float], ptr %0, i64 %76, !dbg !1958
  %.sroa.03.0.copyload.1 = load float, ptr %77, align 4, !dbg !1958
  tail call void @llvm.dbg.value(metadata float %.sroa.03.0.copyload.1, metadata !1959, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !1957
  %.sroa.24.0..sroa_idx.1 = getelementptr inbounds i8, ptr %77, i64 4, !dbg !1958
  %.sroa.24.0.copyload.1 = load float, ptr %.sroa.24.0..sroa_idx.1, align 4, !dbg !1958
  tail call void @llvm.dbg.value(metadata float %.sroa.24.0.copyload.1, metadata !1959, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !1957
  %.sroa.35.0..sroa_idx.1 = getelementptr inbounds i8, ptr %77, i64 8, !dbg !1958
  %.sroa.35.0.copyload.1 = load float, ptr %.sroa.35.0..sroa_idx.1, align 4, !dbg !1958
  tail call void @llvm.dbg.value(metadata float %.sroa.35.0.copyload.1, metadata !1959, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !1957
  %.sroa.06.0.copyload.1 = load float, ptr %8, align 4, !dbg !1960
  tail call void @llvm.dbg.value(metadata float %.sroa.06.0.copyload.1, metadata !1961, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !1957
  %.sroa.27.0.copyload.1 = load float, ptr %.sroa.27.0..sroa_idx, align 4, !dbg !1960
  tail call void @llvm.dbg.value(metadata float %.sroa.27.0.copyload.1, metadata !1961, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !1957
  %.sroa.38.0.copyload.1 = load float, ptr %.sroa.38.0..sroa_idx, align 4, !dbg !1960
  tail call void @llvm.dbg.value(metadata float %.sroa.38.0.copyload.1, metadata !1961, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !1957
  %78 = getelementptr inbounds [6 x double], ptr %3, i64 %.sroa.0.017, i64 %73, !dbg !1962
  %79 = fpext float %.sroa.02.0.copyload.1 to double, !dbg !1964
  %80 = fpext float %.sroa.2.0.copyload.1 to double, !dbg !1964
  %81 = fpext float %.sroa.3.0.copyload.1 to double, !dbg !1964
  tail call void @llvm.dbg.value(metadata double %79, metadata !1965, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %80, metadata !1965, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %81, metadata !1965, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !1972
  %82 = fpext float %.sroa.03.0.copyload.1 to double, !dbg !1974
  %83 = fpext float %.sroa.24.0.copyload.1 to double, !dbg !1974
  %84 = fpext float %.sroa.35.0.copyload.1 to double, !dbg !1974
  tail call void @llvm.dbg.value(metadata double %82, metadata !1975, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %83, metadata !1975, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %84, metadata !1975, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !1972
  %85 = fpext float %.sroa.06.0.copyload.1 to double, !dbg !1976
  %86 = fpext float %.sroa.27.0.copyload.1 to double, !dbg !1976
  %87 = fpext float %.sroa.38.0.copyload.1 to double, !dbg !1976
  tail call void @llvm.dbg.value(metadata double %85, metadata !1977, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %86, metadata !1977, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %87, metadata !1977, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !1972
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !1978, metadata !DIExpression()), !dbg !1972
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !1979, metadata !DIExpression()), !dbg !1972
  call void @llvm.dbg.value(metadata i64 0, metadata !1980, metadata !DIExpression()), !dbg !1985
  call void @llvm.dbg.value(metadata double %79, metadata !1986, metadata !DIExpression()), !dbg !1991
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !1996
  %88 = tail call double @llvm.fabs.f64(double %79), !dbg !1997
  %89 = bitcast double %88 to i64, !dbg !1997
  %90 = icmp ult i64 %89, 9218868437227405312, !dbg !1998
  br i1 %90, label %Then3.i.1, label %atmosphere_water.edgeRate.exit.1, !dbg !2000

Then3.i.1:                                        ; preds = %atmosphere_water.edgeRate.exit
  call void @llvm.dbg.value(metadata double %82, metadata !1986, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2007
  %91 = tail call double @llvm.fabs.f64(double %82), !dbg !2008
  %92 = bitcast double %91 to i64, !dbg !2008
  %93 = icmp ult i64 %92, 9218868437227405312, !dbg !2009
  br i1 %93, label %Then5.i.1, label %atmosphere_water.edgeRate.exit.1, !dbg !2010

Then5.i.1:                                        ; preds = %Then3.i.1
  call void @llvm.dbg.value(metadata double %85, metadata !1986, metadata !DIExpression()), !dbg !2013
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2017
  %94 = tail call double @llvm.fabs.f64(double %85), !dbg !2018
  %95 = bitcast double %94 to i64, !dbg !2018
  %96 = icmp ult i64 %95, 9218868437227405312, !dbg !2019
  br i1 %96, label %Then7.i.1, label %atmosphere_water.edgeRate.exit.1, !dbg !2020

Then7.i.1:                                        ; preds = %Then5.i.1
  %97 = fsub double %82, %79, !dbg !2022
  call void @llvm.dbg.value(metadata double undef, metadata !2024, metadata !DIExpression()), !dbg !1972
  %98 = fmul double %97, %97, !dbg !2025
  call void @llvm.dbg.value(metadata double %98, metadata !1978, metadata !DIExpression()), !dbg !1972
  %99 = fmul double %97, %85, !dbg !2027
  %100 = fadd double %99, 0.000000e+00, !dbg !2029
  call void @llvm.dbg.value(metadata double %100, metadata !1979, metadata !DIExpression()), !dbg !1972
  call void @llvm.dbg.value(metadata i64 1, metadata !1980, metadata !DIExpression()), !dbg !1985
  call void @llvm.dbg.value(metadata double %80, metadata !1986, metadata !DIExpression()), !dbg !1991
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !1996
  %101 = tail call double @llvm.fabs.f64(double %80), !dbg !1997
  %102 = bitcast double %101 to i64, !dbg !1997
  %103 = icmp ult i64 %102, 9218868437227405312, !dbg !1998
  br i1 %103, label %Then3.1.i.1, label %atmosphere_water.edgeRate.exit.1, !dbg !2000

Then3.1.i.1:                                      ; preds = %Then7.i.1
  call void @llvm.dbg.value(metadata double %83, metadata !1986, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2007
  %104 = tail call double @llvm.fabs.f64(double %83), !dbg !2008
  %105 = bitcast double %104 to i64, !dbg !2008
  %106 = icmp ult i64 %105, 9218868437227405312, !dbg !2009
  br i1 %106, label %Then5.1.i.1, label %atmosphere_water.edgeRate.exit.1, !dbg !2010

Then5.1.i.1:                                      ; preds = %Then3.1.i.1
  call void @llvm.dbg.value(metadata double %86, metadata !1986, metadata !DIExpression()), !dbg !2013
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2017
  %107 = tail call double @llvm.fabs.f64(double %86), !dbg !2018
  %108 = bitcast double %107 to i64, !dbg !2018
  %109 = icmp ult i64 %108, 9218868437227405312, !dbg !2019
  br i1 %109, label %Then7.1.i.1, label %atmosphere_water.edgeRate.exit.1, !dbg !2020

Then7.1.i.1:                                      ; preds = %Then5.1.i.1
  %110 = fsub double %83, %80, !dbg !2022
  call void @llvm.dbg.value(metadata double undef, metadata !2024, metadata !DIExpression()), !dbg !1972
  %111 = fmul double %110, %110, !dbg !2025
  %112 = fadd double %98, %111, !dbg !2030
  call void @llvm.dbg.value(metadata double %112, metadata !1978, metadata !DIExpression()), !dbg !1972
  %113 = fmul double %110, %86, !dbg !2027
  %114 = fadd double %100, %113, !dbg !2029
  call void @llvm.dbg.value(metadata double %114, metadata !1979, metadata !DIExpression()), !dbg !1972
  call void @llvm.dbg.value(metadata i64 2, metadata !1980, metadata !DIExpression()), !dbg !1985
  call void @llvm.dbg.value(metadata double %81, metadata !1986, metadata !DIExpression()), !dbg !1991
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !1996
  %115 = tail call double @llvm.fabs.f64(double %81), !dbg !1997
  %116 = bitcast double %115 to i64, !dbg !1997
  %117 = icmp ult i64 %116, 9218868437227405312, !dbg !1998
  br i1 %117, label %Then3.2.i.1, label %atmosphere_water.edgeRate.exit.1, !dbg !2000

Then3.2.i.1:                                      ; preds = %Then7.1.i.1
  call void @llvm.dbg.value(metadata double %84, metadata !1986, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2007
  %118 = tail call double @llvm.fabs.f64(double %84), !dbg !2008
  %119 = bitcast double %118 to i64, !dbg !2008
  %120 = icmp ult i64 %119, 9218868437227405312, !dbg !2009
  br i1 %120, label %Then5.2.i.1, label %atmosphere_water.edgeRate.exit.1, !dbg !2010

Then5.2.i.1:                                      ; preds = %Then3.2.i.1
  call void @llvm.dbg.value(metadata double %87, metadata !1986, metadata !DIExpression()), !dbg !2013
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2017
  %121 = tail call double @llvm.fabs.f64(double %87), !dbg !2018
  %122 = bitcast double %121 to i64, !dbg !2018
  %123 = icmp ult i64 %122, 9218868437227405312, !dbg !2019
  br i1 %123, label %Then7.2.i.1, label %atmosphere_water.edgeRate.exit.1, !dbg !2020

Then7.2.i.1:                                      ; preds = %Then5.2.i.1
  %124 = fsub double %84, %81, !dbg !2022
  call void @llvm.dbg.value(metadata double undef, metadata !2024, metadata !DIExpression()), !dbg !1972
  %125 = fmul double %124, %124, !dbg !2025
  %126 = fadd double %112, %125, !dbg !2030
  call void @llvm.dbg.value(metadata double %126, metadata !1978, metadata !DIExpression()), !dbg !1972
  %127 = fmul double %124, %87, !dbg !2027
  %128 = fadd double %114, %127, !dbg !2029
  call void @llvm.dbg.value(metadata double %128, metadata !1979, metadata !DIExpression()), !dbg !1972
  %129 = fcmp ugt double %126, 0.000000e+00, !dbg !2031
  br i1 %129, label %Else14.i.1, label %atmosphere_water.edgeRate.exit.1, !dbg !2033

Else14.i.1:                                       ; preds = %Then7.2.i.1
  call void @llvm.dbg.value(metadata double %126, metadata !1986, metadata !DIExpression()), !dbg !2035
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2039
  %130 = tail call double @llvm.fabs.f64(double %126), !dbg !2040
  %131 = bitcast double %130 to i64, !dbg !2040
  %132 = icmp ult i64 %131, 9218868437227405312, !dbg !2041
  br i1 %132, label %Else15.i.1, label %atmosphere_water.edgeRate.exit.1, !dbg !2042

Else15.i.1:                                       ; preds = %Else14.i.1
  call void @llvm.dbg.value(metadata double %128, metadata !1986, metadata !DIExpression()), !dbg !2045
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2049
  %133 = tail call double @llvm.fabs.f64(double %128), !dbg !2050
  %134 = bitcast double %133 to i64, !dbg !2050
  %135 = icmp ult i64 %134, 9218868437227405312, !dbg !2051
  br i1 %135, label %Else16.i.1, label %atmosphere_water.edgeRate.exit.1, !dbg !2052

Else16.i.1:                                       ; preds = %Else15.i.1
  %136 = fdiv double %128, %126, !dbg !2054
  %137 = tail call double @llvm.maxnum.f64(double %136, double 0.000000e+00), !dbg !2054
  br label %atmosphere_water.edgeRate.exit.1

atmosphere_water.edgeRate.exit.1:                 ; preds = %Else16.i.1, %Else15.i.1, %Else14.i.1, %Then7.2.i.1, %Then5.2.i.1, %Then3.2.i.1, %Then7.1.i.1, %Then5.1.i.1, %Then3.1.i.1, %Then7.i.1, %Then5.i.1, %Then3.i.1, %atmosphere_water.edgeRate.exit
  %common.ret.op.i.1 = phi double [ %137, %Else16.i.1 ], [ 0.000000e+00, %Else14.i.1 ], [ 0.000000e+00, %Then7.2.i.1 ], [ 0.000000e+00, %Else15.i.1 ], [ 0.000000e+00, %Then5.2.i.1 ], [ 0.000000e+00, %Then3.2.i.1 ], [ 0.000000e+00, %Then7.1.i.1 ], [ 0.000000e+00, %Then5.1.i.1 ], [ 0.000000e+00, %Then3.1.i.1 ], [ 0.000000e+00, %Then7.i.1 ], [ 0.000000e+00, %Then3.i.1 ], [ 0.000000e+00, %atmosphere_water.edgeRate.exit ], [ 0.000000e+00, %Then5.i.1 ]
  store double %common.ret.op.i.1, ptr %78, align 8, !dbg !2055
  %138 = add nuw nsw i64 %.sroa.01.016, 2, !dbg !2056
  %139 = getelementptr inbounds [6 x i32], ptr %5, i64 0, i64 %138, !dbg !1949
  %140 = load i32, ptr %139, align 4, !dbg !1949
  call void @llvm.dbg.value(metadata i32 %140, metadata !1952, metadata !DIExpression()), !dbg !1953
  call void @llvm.dbg.value(metadata i64 %138, metadata !1954, metadata !DIExpression()), !dbg !1953
  %.sroa.02.0.copyload.2 = load float, ptr %7, align 4, !dbg !1955
  tail call void @llvm.dbg.value(metadata float %.sroa.02.0.copyload.2, metadata !1956, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !1957
  %.sroa.2.0.copyload.2 = load float, ptr %.sroa.2.0..sroa_idx, align 4, !dbg !1955
  tail call void @llvm.dbg.value(metadata float %.sroa.2.0.copyload.2, metadata !1956, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !1957
  %.sroa.3.0.copyload.2 = load float, ptr %.sroa.3.0..sroa_idx, align 4, !dbg !1955
  tail call void @llvm.dbg.value(metadata float %.sroa.3.0.copyload.2, metadata !1956, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !1957
  %141 = zext i32 %140 to i64, !dbg !1958
  %142 = getelementptr inbounds [3 x float], ptr %0, i64 %141, !dbg !1958
  %.sroa.03.0.copyload.2 = load float, ptr %142, align 4, !dbg !1958
  tail call void @llvm.dbg.value(metadata float %.sroa.03.0.copyload.2, metadata !1959, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !1957
  %.sroa.24.0..sroa_idx.2 = getelementptr inbounds i8, ptr %142, i64 4, !dbg !1958
  %.sroa.24.0.copyload.2 = load float, ptr %.sroa.24.0..sroa_idx.2, align 4, !dbg !1958
  tail call void @llvm.dbg.value(metadata float %.sroa.24.0.copyload.2, metadata !1959, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !1957
  %.sroa.35.0..sroa_idx.2 = getelementptr inbounds i8, ptr %142, i64 8, !dbg !1958
  %.sroa.35.0.copyload.2 = load float, ptr %.sroa.35.0..sroa_idx.2, align 4, !dbg !1958
  tail call void @llvm.dbg.value(metadata float %.sroa.35.0.copyload.2, metadata !1959, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !1957
  %.sroa.06.0.copyload.2 = load float, ptr %8, align 4, !dbg !1960
  tail call void @llvm.dbg.value(metadata float %.sroa.06.0.copyload.2, metadata !1961, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !1957
  %.sroa.27.0.copyload.2 = load float, ptr %.sroa.27.0..sroa_idx, align 4, !dbg !1960
  tail call void @llvm.dbg.value(metadata float %.sroa.27.0.copyload.2, metadata !1961, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !1957
  %.sroa.38.0.copyload.2 = load float, ptr %.sroa.38.0..sroa_idx, align 4, !dbg !1960
  tail call void @llvm.dbg.value(metadata float %.sroa.38.0.copyload.2, metadata !1961, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !1957
  %143 = getelementptr inbounds [6 x double], ptr %3, i64 %.sroa.0.017, i64 %138, !dbg !1962
  %144 = fpext float %.sroa.02.0.copyload.2 to double, !dbg !1964
  %145 = fpext float %.sroa.2.0.copyload.2 to double, !dbg !1964
  %146 = fpext float %.sroa.3.0.copyload.2 to double, !dbg !1964
  tail call void @llvm.dbg.value(metadata double %144, metadata !1965, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %145, metadata !1965, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %146, metadata !1965, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !1972
  %147 = fpext float %.sroa.03.0.copyload.2 to double, !dbg !1974
  %148 = fpext float %.sroa.24.0.copyload.2 to double, !dbg !1974
  %149 = fpext float %.sroa.35.0.copyload.2 to double, !dbg !1974
  tail call void @llvm.dbg.value(metadata double %147, metadata !1975, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %148, metadata !1975, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %149, metadata !1975, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !1972
  %150 = fpext float %.sroa.06.0.copyload.2 to double, !dbg !1976
  %151 = fpext float %.sroa.27.0.copyload.2 to double, !dbg !1976
  %152 = fpext float %.sroa.38.0.copyload.2 to double, !dbg !1976
  tail call void @llvm.dbg.value(metadata double %150, metadata !1977, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %151, metadata !1977, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !1972
  tail call void @llvm.dbg.value(metadata double %152, metadata !1977, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !1972
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !1978, metadata !DIExpression()), !dbg !1972
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !1979, metadata !DIExpression()), !dbg !1972
  call void @llvm.dbg.value(metadata i64 0, metadata !1980, metadata !DIExpression()), !dbg !1985
  call void @llvm.dbg.value(metadata double %144, metadata !1986, metadata !DIExpression()), !dbg !1991
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !1996
  %153 = tail call double @llvm.fabs.f64(double %144), !dbg !1997
  %154 = bitcast double %153 to i64, !dbg !1997
  %155 = icmp ult i64 %154, 9218868437227405312, !dbg !1998
  br i1 %155, label %Then3.i.2, label %atmosphere_water.edgeRate.exit.2, !dbg !2000

Then3.i.2:                                        ; preds = %atmosphere_water.edgeRate.exit.1
  call void @llvm.dbg.value(metadata double %147, metadata !1986, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2007
  %156 = tail call double @llvm.fabs.f64(double %147), !dbg !2008
  %157 = bitcast double %156 to i64, !dbg !2008
  %158 = icmp ult i64 %157, 9218868437227405312, !dbg !2009
  br i1 %158, label %Then5.i.2, label %atmosphere_water.edgeRate.exit.2, !dbg !2010

Then5.i.2:                                        ; preds = %Then3.i.2
  call void @llvm.dbg.value(metadata double %150, metadata !1986, metadata !DIExpression()), !dbg !2013
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2017
  %159 = tail call double @llvm.fabs.f64(double %150), !dbg !2018
  %160 = bitcast double %159 to i64, !dbg !2018
  %161 = icmp ult i64 %160, 9218868437227405312, !dbg !2019
  br i1 %161, label %Then7.i.2, label %atmosphere_water.edgeRate.exit.2, !dbg !2020

Then7.i.2:                                        ; preds = %Then5.i.2
  %162 = fsub double %147, %144, !dbg !2022
  call void @llvm.dbg.value(metadata double undef, metadata !2024, metadata !DIExpression()), !dbg !1972
  %163 = fmul double %162, %162, !dbg !2025
  call void @llvm.dbg.value(metadata double %163, metadata !1978, metadata !DIExpression()), !dbg !1972
  %164 = fmul double %162, %150, !dbg !2027
  %165 = fadd double %164, 0.000000e+00, !dbg !2029
  call void @llvm.dbg.value(metadata double %165, metadata !1979, metadata !DIExpression()), !dbg !1972
  call void @llvm.dbg.value(metadata i64 1, metadata !1980, metadata !DIExpression()), !dbg !1985
  call void @llvm.dbg.value(metadata double %145, metadata !1986, metadata !DIExpression()), !dbg !1991
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !1996
  %166 = tail call double @llvm.fabs.f64(double %145), !dbg !1997
  %167 = bitcast double %166 to i64, !dbg !1997
  %168 = icmp ult i64 %167, 9218868437227405312, !dbg !1998
  br i1 %168, label %Then3.1.i.2, label %atmosphere_water.edgeRate.exit.2, !dbg !2000

Then3.1.i.2:                                      ; preds = %Then7.i.2
  call void @llvm.dbg.value(metadata double %148, metadata !1986, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2007
  %169 = tail call double @llvm.fabs.f64(double %148), !dbg !2008
  %170 = bitcast double %169 to i64, !dbg !2008
  %171 = icmp ult i64 %170, 9218868437227405312, !dbg !2009
  br i1 %171, label %Then5.1.i.2, label %atmosphere_water.edgeRate.exit.2, !dbg !2010

Then5.1.i.2:                                      ; preds = %Then3.1.i.2
  call void @llvm.dbg.value(metadata double %151, metadata !1986, metadata !DIExpression()), !dbg !2013
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2017
  %172 = tail call double @llvm.fabs.f64(double %151), !dbg !2018
  %173 = bitcast double %172 to i64, !dbg !2018
  %174 = icmp ult i64 %173, 9218868437227405312, !dbg !2019
  br i1 %174, label %Then7.1.i.2, label %atmosphere_water.edgeRate.exit.2, !dbg !2020

Then7.1.i.2:                                      ; preds = %Then5.1.i.2
  %175 = fsub double %148, %145, !dbg !2022
  call void @llvm.dbg.value(metadata double undef, metadata !2024, metadata !DIExpression()), !dbg !1972
  %176 = fmul double %175, %175, !dbg !2025
  %177 = fadd double %163, %176, !dbg !2030
  call void @llvm.dbg.value(metadata double %177, metadata !1978, metadata !DIExpression()), !dbg !1972
  %178 = fmul double %175, %151, !dbg !2027
  %179 = fadd double %165, %178, !dbg !2029
  call void @llvm.dbg.value(metadata double %179, metadata !1979, metadata !DIExpression()), !dbg !1972
  call void @llvm.dbg.value(metadata i64 2, metadata !1980, metadata !DIExpression()), !dbg !1985
  call void @llvm.dbg.value(metadata double %146, metadata !1986, metadata !DIExpression()), !dbg !1991
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !1996
  %180 = tail call double @llvm.fabs.f64(double %146), !dbg !1997
  %181 = bitcast double %180 to i64, !dbg !1997
  %182 = icmp ult i64 %181, 9218868437227405312, !dbg !1998
  br i1 %182, label %Then3.2.i.2, label %atmosphere_water.edgeRate.exit.2, !dbg !2000

Then3.2.i.2:                                      ; preds = %Then7.1.i.2
  call void @llvm.dbg.value(metadata double %149, metadata !1986, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2007
  %183 = tail call double @llvm.fabs.f64(double %149), !dbg !2008
  %184 = bitcast double %183 to i64, !dbg !2008
  %185 = icmp ult i64 %184, 9218868437227405312, !dbg !2009
  br i1 %185, label %Then5.2.i.2, label %atmosphere_water.edgeRate.exit.2, !dbg !2010

Then5.2.i.2:                                      ; preds = %Then3.2.i.2
  call void @llvm.dbg.value(metadata double %152, metadata !1986, metadata !DIExpression()), !dbg !2013
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2017
  %186 = tail call double @llvm.fabs.f64(double %152), !dbg !2018
  %187 = bitcast double %186 to i64, !dbg !2018
  %188 = icmp ult i64 %187, 9218868437227405312, !dbg !2019
  br i1 %188, label %Then7.2.i.2, label %atmosphere_water.edgeRate.exit.2, !dbg !2020

Then7.2.i.2:                                      ; preds = %Then5.2.i.2
  %189 = fsub double %149, %146, !dbg !2022
  call void @llvm.dbg.value(metadata double undef, metadata !2024, metadata !DIExpression()), !dbg !1972
  %190 = fmul double %189, %189, !dbg !2025
  %191 = fadd double %177, %190, !dbg !2030
  call void @llvm.dbg.value(metadata double %191, metadata !1978, metadata !DIExpression()), !dbg !1972
  %192 = fmul double %189, %152, !dbg !2027
  %193 = fadd double %179, %192, !dbg !2029
  call void @llvm.dbg.value(metadata double %193, metadata !1979, metadata !DIExpression()), !dbg !1972
  %194 = fcmp ugt double %191, 0.000000e+00, !dbg !2031
  br i1 %194, label %Else14.i.2, label %atmosphere_water.edgeRate.exit.2, !dbg !2033

Else14.i.2:                                       ; preds = %Then7.2.i.2
  call void @llvm.dbg.value(metadata double %191, metadata !1986, metadata !DIExpression()), !dbg !2035
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2039
  %195 = tail call double @llvm.fabs.f64(double %191), !dbg !2040
  %196 = bitcast double %195 to i64, !dbg !2040
  %197 = icmp ult i64 %196, 9218868437227405312, !dbg !2041
  br i1 %197, label %Else15.i.2, label %atmosphere_water.edgeRate.exit.2, !dbg !2042

Else15.i.2:                                       ; preds = %Else14.i.2
  call void @llvm.dbg.value(metadata double %193, metadata !1986, metadata !DIExpression()), !dbg !2045
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2049
  %198 = tail call double @llvm.fabs.f64(double %193), !dbg !2050
  %199 = bitcast double %198 to i64, !dbg !2050
  %200 = icmp ult i64 %199, 9218868437227405312, !dbg !2051
  br i1 %200, label %Else16.i.2, label %atmosphere_water.edgeRate.exit.2, !dbg !2052

Else16.i.2:                                       ; preds = %Else15.i.2
  %201 = fdiv double %193, %191, !dbg !2054
  %202 = tail call double @llvm.maxnum.f64(double %201, double 0.000000e+00), !dbg !2054
  br label %atmosphere_water.edgeRate.exit.2

atmosphere_water.edgeRate.exit.2:                 ; preds = %Else16.i.2, %Else15.i.2, %Else14.i.2, %Then7.2.i.2, %Then5.2.i.2, %Then3.2.i.2, %Then7.1.i.2, %Then5.1.i.2, %Then3.1.i.2, %Then7.i.2, %Then5.i.2, %Then3.i.2, %atmosphere_water.edgeRate.exit.1
  %common.ret.op.i.2 = phi double [ %202, %Else16.i.2 ], [ 0.000000e+00, %Else14.i.2 ], [ 0.000000e+00, %Then7.2.i.2 ], [ 0.000000e+00, %Else15.i.2 ], [ 0.000000e+00, %Then5.2.i.2 ], [ 0.000000e+00, %Then3.2.i.2 ], [ 0.000000e+00, %Then7.1.i.2 ], [ 0.000000e+00, %Then5.1.i.2 ], [ 0.000000e+00, %Then3.1.i.2 ], [ 0.000000e+00, %Then7.i.2 ], [ 0.000000e+00, %Then3.i.2 ], [ 0.000000e+00, %atmosphere_water.edgeRate.exit.1 ], [ 0.000000e+00, %Then5.i.2 ]
  store double %common.ret.op.i.2, ptr %143, align 8, !dbg !2055
  %203 = add nuw nsw i64 %.sroa.01.016, 3, !dbg !2056
  %exitcond.not.2 = icmp eq i64 %203, 6, !dbg !1942
  br i1 %exitcond.not.2, label %Else1, label %Then1, !dbg !1942

Else1:                                            ; preds = %atmosphere_water.edgeRate.exit.2
  %204 = add nuw i64 %.sroa.0.017, 1, !dbg !2058
  %exitcond18.not = icmp eq i64 %204, %4, !dbg !1932
  br i1 %exitcond18.not, label %Else, label %Then, !dbg !1932
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #2

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite) uwtable
define dso_local void @candidate(ptr nocapture nonnull readonly align 4 %0, ptr nocapture nonnull readonly align 4 %1, ptr nocapture nonnull readonly align 4 %2, ptr nocapture nonnull writeonly align 8 %3, i64 %4) local_unnamed_addr #0 !dbg !2060 {
Entry:
  call void @llvm.dbg.value(metadata ptr %0, metadata !2061, metadata !DIExpression()), !dbg !2062
  call void @llvm.dbg.value(metadata ptr %1, metadata !2063, metadata !DIExpression()), !dbg !2062
  call void @llvm.dbg.value(metadata ptr %2, metadata !2064, metadata !DIExpression()), !dbg !2062
  call void @llvm.dbg.value(metadata ptr %3, metadata !2065, metadata !DIExpression()), !dbg !2062
  call void @llvm.dbg.value(metadata i64 %4, metadata !2066, metadata !DIExpression()), !dbg !2062
  %.not = icmp eq i64 %4, 0, !dbg !2067
  br i1 %.not, label %Else, label %Then, !dbg !2067

Then:                                             ; preds = %Entry, %Else6
  %.sroa.0.034 = phi i64 [ %289, %Else6 ], [ 0, %Entry ]
  call void @llvm.dbg.value(metadata i64 %.sroa.0.034, metadata !2072, metadata !DIExpression()), !dbg !2074
  %5 = mul i64 %.sroa.0.034, 48, !dbg !2075
  %scevgep = getelementptr i8, ptr %3, i64 %5, !dbg !2075
  %6 = getelementptr inbounds [3 x float], ptr %0, i64 %.sroa.0.034, !dbg !2075
  tail call void @llvm.dbg.value(metadata float undef, metadata !2077, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !2078
  %7 = load <2 x float>, ptr %6, align 4, !dbg !2075
  tail call void @llvm.dbg.value(metadata float undef, metadata !2077, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !2078
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %6, i64 8, !dbg !2075
  %.sroa.5.0.copyload = load float, ptr %.sroa.5.0..sroa_idx, align 4, !dbg !2075
  tail call void @llvm.dbg.value(metadata float %.sroa.5.0.copyload, metadata !2077, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !2078
  %8 = getelementptr inbounds [3 x float], ptr %1, i64 %.sroa.0.034, !dbg !2079
  %.sroa.042.0.copyload = load float, ptr %8, align 4, !dbg !2079
  tail call void @llvm.dbg.value(metadata float %.sroa.042.0.copyload, metadata !2080, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !2078
  %.sroa.344.0..sroa_idx = getelementptr inbounds i8, ptr %8, i64 4, !dbg !2079
  %.sroa.344.0.copyload = load float, ptr %.sroa.344.0..sroa_idx, align 4, !dbg !2079
  tail call void @llvm.dbg.value(metadata float %.sroa.344.0.copyload, metadata !2080, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !2078
  %.sroa.546.0..sroa_idx = getelementptr inbounds i8, ptr %8, i64 8, !dbg !2079
  %.sroa.546.0.copyload = load float, ptr %.sroa.546.0..sroa_idx, align 4, !dbg !2079
  tail call void @llvm.dbg.value(metadata float %.sroa.546.0.copyload, metadata !2080, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !2078
  tail call void @llvm.dbg.value(metadata i1 true, metadata !2081, metadata !DIExpression()), !dbg !2078
  call void @llvm.dbg.value(metadata i64 0, metadata !2082, metadata !DIExpression()), !dbg !2087
  call void @llvm.dbg.value(metadata float undef, metadata !2088, metadata !DIExpression()), !dbg !2092
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2097
  %9 = extractelement <2 x float> %7, i64 0, !dbg !2098
  %10 = tail call float @llvm.fabs.f32(float %9), !dbg !2098
  %11 = bitcast float %10 to i32, !dbg !2098
  %12 = icmp ult i32 %11, 2139095040, !dbg !2099
  br i1 %12, label %Then4, label %Then5, !dbg !2101

Else:                                             ; preds = %Else6, %Entry
  ret void, !dbg !2104

Then6.preheader:                                  ; preds = %Then4.2, %Block4.1, %Block4.2
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %scevgep, i8 0, i64 48, i1 false), !dbg !2105
  call void @llvm.dbg.value(metadata i32 poison, metadata !2113, metadata !DIExpression()), !dbg !2114
  call void @llvm.dbg.value(metadata i64 poison, metadata !2115, metadata !DIExpression()), !dbg !2114
  tail call void @llvm.dbg.value(metadata i1 poison, metadata !2081, metadata !DIExpression()), !dbg !2078
  br label %Else6, !dbg !2116

Then6.us.preheader:                               ; preds = %Block4.2
  %13 = fpext float %.sroa.042.0.copyload to double
  %14 = fpext <2 x float> %7 to <2 x double>
  %15 = fpext float %.sroa.344.0.copyload to double
  %16 = fpext float %.sroa.5.0.copyload to double
  %17 = fpext float %.sroa.546.0.copyload to double
  call void @llvm.dbg.value(metadata i32 poison, metadata !2113, metadata !DIExpression()), !dbg !2114
  call void @llvm.dbg.value(metadata i64 0, metadata !2115, metadata !DIExpression()), !dbg !2114
  tail call void @llvm.dbg.value(metadata i1 poison, metadata !2081, metadata !DIExpression()), !dbg !2078
  call void @llvm.dbg.value(metadata i32 %.sroa.0.0.copyload55, metadata !2113, metadata !DIExpression()), !dbg !2114
  %18 = zext i32 %.sroa.0.0.copyload55 to i64, !dbg !2118
  %19 = getelementptr inbounds [3 x float], ptr %0, i64 %18, !dbg !2118
  tail call void @llvm.dbg.value(metadata float undef, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !2121
  %20 = load <2 x float>, ptr %19, align 4, !dbg !2118
  tail call void @llvm.dbg.value(metadata float undef, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !2121
  %.sroa.349.0..sroa_idx = getelementptr inbounds i8, ptr %19, i64 8, !dbg !2118
  %.sroa.349.0.copyload = load float, ptr %.sroa.349.0..sroa_idx, align 4, !dbg !2118
  tail call void @llvm.dbg.value(metadata float %.sroa.349.0.copyload, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !2121
  tail call void @llvm.dbg.value(metadata i1 true, metadata !2122, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 0, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float undef, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %21 = extractelement <2 x float> %20, i64 0, !dbg !2136
  %22 = tail call float @llvm.fabs.f32(float %21), !dbg !2136
  %23 = bitcast float %22 to i32, !dbg !2136
  %24 = icmp ult i32 %23, 2139095040, !dbg !2137
  br i1 %24, label %Then12.us, label %Block20.us, !dbg !2138

Then15.us:                                        ; preds = %Then12.us.1
  %25 = fpext <2 x float> %20 to <2 x double>, !dbg !2139
  call void @llvm.dbg.value(metadata double undef, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double %29, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata double undef, metadata !2141, metadata !DIExpression()), !dbg !2142
  %26 = fsub <2 x double> %25, %14, !dbg !2143
  %27 = extractelement <2 x double> %26, i64 0, !dbg !2145
  %28 = fmul double %27, %13, !dbg !2145
  %29 = fadd double %28, 0.000000e+00, !dbg !2147
  %30 = extractelement <2 x double> %26, i64 1, !dbg !2145
  %31 = fmul double %30, %15, !dbg !2145
  %32 = fadd double %29, %31, !dbg !2147
  tail call void @llvm.dbg.value(metadata double %32, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double undef, metadata !2123, metadata !DIExpression()), !dbg !2121
  %33 = fmul <2 x double> %26, %26, !dbg !2148
  %shift = shufflevector <2 x double> %33, <2 x double> poison, <2 x i32> <i32 1, i32 poison>, !dbg !2149
  %34 = fadd <2 x double> %33, %shift, !dbg !2149
  %35 = extractelement <2 x double> %34, i64 0, !dbg !2149
  tail call void @llvm.dbg.value(metadata double %35, metadata !2123, metadata !DIExpression()), !dbg !2121
  %36 = fpext float %.sroa.349.0.copyload to double, !dbg !2139
  %37 = fsub double %36, %16, !dbg !2143
  call void @llvm.dbg.value(metadata double %37, metadata !2141, metadata !DIExpression()), !dbg !2142
  %38 = fmul double %37, %37, !dbg !2148
  %39 = fadd double %35, %38, !dbg !2149
  tail call void @llvm.dbg.value(metadata double %39, metadata !2123, metadata !DIExpression()), !dbg !2121
  %40 = fmul double %37, %17, !dbg !2145
  %41 = fadd double %32, %40, !dbg !2147
  tail call void @llvm.dbg.value(metadata double %41, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata i1 true, metadata !2122, metadata !DIExpression()), !dbg !2121
  %42 = fcmp ugt double %39, 0.000000e+00
  br i1 %42, label %Else17.us, label %Block20.us, !dbg !2150

Else17.us:                                        ; preds = %Then15.us
  call void @llvm.dbg.value(metadata double %39, metadata !1986, metadata !DIExpression()), !dbg !2154
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2158
  %43 = tail call double @llvm.fabs.f64(double %39), !dbg !2159
  %44 = bitcast double %43 to i64, !dbg !2159
  %45 = icmp ult i64 %44, 9218868437227405312, !dbg !2160
  br i1 %45, label %Else18.us, label %Block20.us, !dbg !2161

Else18.us:                                        ; preds = %Else17.us
  call void @llvm.dbg.value(metadata double %41, metadata !1986, metadata !DIExpression()), !dbg !2164
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2168
  %46 = tail call double @llvm.fabs.f64(double %41), !dbg !2169
  %47 = bitcast double %46 to i64, !dbg !2169
  %48 = icmp ult i64 %47, 9218868437227405312, !dbg !2170
  br i1 %48, label %Else19.us, label %Block20.us, !dbg !2171

Else19.us:                                        ; preds = %Else18.us
  %49 = fdiv double %41, %39, !dbg !2173
  %50 = tail call double @llvm.maxnum.f64(double %49, double 0.000000e+00), !dbg !2176
  br label %Block20.us, !dbg !2173

Block20.us:                                       ; preds = %Then12.us.1, %Then12.us, %Then6.us.preheader, %Else19.us, %Else18.us, %Else17.us, %Then15.us
  %51 = phi double [ %50, %Else19.us ], [ 0.000000e+00, %Else17.us ], [ 0.000000e+00, %Then15.us ], [ 0.000000e+00, %Else18.us ], [ 0.000000e+00, %Then6.us.preheader ], [ 0.000000e+00, %Then12.us ], [ 0.000000e+00, %Then12.us.1 ], !dbg !2177
  %52 = getelementptr inbounds [6 x double], ptr %3, i64 %.sroa.0.034, i64 0, !dbg !2179
  store double %51, ptr %52, align 8, !dbg !2177
  call void @llvm.dbg.value(metadata i32 poison, metadata !2113, metadata !DIExpression()), !dbg !2114
  call void @llvm.dbg.value(metadata i64 1, metadata !2115, metadata !DIExpression()), !dbg !2114
  tail call void @llvm.dbg.value(metadata i1 poison, metadata !2081, metadata !DIExpression()), !dbg !2078
  call void @llvm.dbg.value(metadata i32 %.sroa.3.0.copyload57, metadata !2113, metadata !DIExpression()), !dbg !2114
  %53 = zext i32 %.sroa.3.0.copyload57 to i64, !dbg !2118
  %54 = getelementptr inbounds [3 x float], ptr %0, i64 %53, !dbg !2118
  tail call void @llvm.dbg.value(metadata float undef, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !2121
  %55 = load <2 x float>, ptr %54, align 4, !dbg !2118
  tail call void @llvm.dbg.value(metadata float undef, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !2121
  %.sroa.349.0..sroa_idx.1 = getelementptr inbounds i8, ptr %54, i64 8, !dbg !2118
  %.sroa.349.0.copyload.1 = load float, ptr %.sroa.349.0..sroa_idx.1, align 4, !dbg !2118
  tail call void @llvm.dbg.value(metadata float %.sroa.349.0.copyload.1, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !2121
  tail call void @llvm.dbg.value(metadata i1 true, metadata !2122, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 0, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float undef, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %56 = extractelement <2 x float> %55, i64 0, !dbg !2136
  %57 = tail call float @llvm.fabs.f32(float %56), !dbg !2136
  %58 = bitcast float %57 to i32, !dbg !2136
  %59 = icmp ult i32 %58, 2139095040, !dbg !2137
  br i1 %59, label %Then12.us.154, label %Block20.us.1, !dbg !2138

Then12.us.154:                                    ; preds = %Block20.us
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 1, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float undef, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %60 = extractelement <2 x float> %55, i64 1, !dbg !2136
  %61 = tail call float @llvm.fabs.f32(float %60), !dbg !2136
  %62 = bitcast float %61 to i32, !dbg !2136
  %63 = icmp ult i32 %62, 2139095040, !dbg !2137
  br i1 %63, label %Then12.us.1.1, label %Block20.us.1, !dbg !2138

Then12.us.1.1:                                    ; preds = %Then12.us.154
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 2, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float %.sroa.349.0.copyload.1, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %64 = tail call float @llvm.fabs.f32(float %.sroa.349.0.copyload.1), !dbg !2136
  %65 = bitcast float %64 to i32, !dbg !2136
  %66 = icmp ult i32 %65, 2139095040, !dbg !2137
  br i1 %66, label %Then15.us.1, label %Block20.us.1, !dbg !2138

Then15.us.1:                                      ; preds = %Then12.us.1.1
  %67 = fpext <2 x float> %55 to <2 x double>, !dbg !2139
  call void @llvm.dbg.value(metadata double undef, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double %71, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata double undef, metadata !2141, metadata !DIExpression()), !dbg !2142
  %68 = fsub <2 x double> %67, %14, !dbg !2143
  %69 = extractelement <2 x double> %68, i64 0, !dbg !2145
  %70 = fmul double %69, %13, !dbg !2145
  %71 = fadd double %70, 0.000000e+00, !dbg !2147
  %72 = extractelement <2 x double> %68, i64 1, !dbg !2145
  %73 = fmul double %72, %15, !dbg !2145
  %74 = fadd double %71, %73, !dbg !2147
  tail call void @llvm.dbg.value(metadata double %74, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double undef, metadata !2123, metadata !DIExpression()), !dbg !2121
  %75 = fmul <2 x double> %68, %68, !dbg !2148
  %shift.1 = shufflevector <2 x double> %75, <2 x double> poison, <2 x i32> <i32 1, i32 poison>, !dbg !2149
  %76 = fadd <2 x double> %75, %shift.1, !dbg !2149
  %77 = extractelement <2 x double> %76, i64 0, !dbg !2149
  tail call void @llvm.dbg.value(metadata double %77, metadata !2123, metadata !DIExpression()), !dbg !2121
  %78 = fpext float %.sroa.349.0.copyload.1 to double, !dbg !2139
  %79 = fsub double %78, %16, !dbg !2143
  call void @llvm.dbg.value(metadata double %79, metadata !2141, metadata !DIExpression()), !dbg !2142
  %80 = fmul double %79, %79, !dbg !2148
  %81 = fadd double %77, %80, !dbg !2149
  tail call void @llvm.dbg.value(metadata double %81, metadata !2123, metadata !DIExpression()), !dbg !2121
  %82 = fmul double %79, %17, !dbg !2145
  %83 = fadd double %74, %82, !dbg !2147
  tail call void @llvm.dbg.value(metadata double %83, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata i1 true, metadata !2122, metadata !DIExpression()), !dbg !2121
  %84 = fcmp ugt double %81, 0.000000e+00
  br i1 %84, label %Else17.us.1, label %Block20.us.1, !dbg !2150

Else17.us.1:                                      ; preds = %Then15.us.1
  call void @llvm.dbg.value(metadata double %81, metadata !1986, metadata !DIExpression()), !dbg !2154
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2158
  %85 = tail call double @llvm.fabs.f64(double %81), !dbg !2159
  %86 = bitcast double %85 to i64, !dbg !2159
  %87 = icmp ult i64 %86, 9218868437227405312, !dbg !2160
  br i1 %87, label %Else18.us.1, label %Block20.us.1, !dbg !2161

Else18.us.1:                                      ; preds = %Else17.us.1
  call void @llvm.dbg.value(metadata double %83, metadata !1986, metadata !DIExpression()), !dbg !2164
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2168
  %88 = tail call double @llvm.fabs.f64(double %83), !dbg !2169
  %89 = bitcast double %88 to i64, !dbg !2169
  %90 = icmp ult i64 %89, 9218868437227405312, !dbg !2170
  br i1 %90, label %Else19.us.1, label %Block20.us.1, !dbg !2171

Else19.us.1:                                      ; preds = %Else18.us.1
  %91 = fdiv double %83, %81, !dbg !2173
  %92 = tail call double @llvm.maxnum.f64(double %91, double 0.000000e+00), !dbg !2176
  br label %Block20.us.1, !dbg !2173

Block20.us.1:                                     ; preds = %Else19.us.1, %Else18.us.1, %Else17.us.1, %Then15.us.1, %Then12.us.1.1, %Then12.us.154, %Block20.us
  %93 = phi double [ %92, %Else19.us.1 ], [ 0.000000e+00, %Else17.us.1 ], [ 0.000000e+00, %Then15.us.1 ], [ 0.000000e+00, %Else18.us.1 ], [ 0.000000e+00, %Block20.us ], [ 0.000000e+00, %Then12.us.154 ], [ 0.000000e+00, %Then12.us.1.1 ], !dbg !2177
  %94 = getelementptr inbounds [6 x double], ptr %3, i64 %.sroa.0.034, i64 1, !dbg !2179
  store double %93, ptr %94, align 8, !dbg !2177
  call void @llvm.dbg.value(metadata i32 poison, metadata !2113, metadata !DIExpression()), !dbg !2114
  call void @llvm.dbg.value(metadata i64 2, metadata !2115, metadata !DIExpression()), !dbg !2114
  tail call void @llvm.dbg.value(metadata i1 poison, metadata !2081, metadata !DIExpression()), !dbg !2078
  call void @llvm.dbg.value(metadata i32 %.sroa.4.0.copyload59, metadata !2113, metadata !DIExpression()), !dbg !2114
  %95 = zext i32 %.sroa.4.0.copyload59 to i64, !dbg !2118
  %96 = getelementptr inbounds [3 x float], ptr %0, i64 %95, !dbg !2118
  tail call void @llvm.dbg.value(metadata float undef, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !2121
  %97 = load <2 x float>, ptr %96, align 4, !dbg !2118
  tail call void @llvm.dbg.value(metadata float undef, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !2121
  %.sroa.349.0..sroa_idx.2 = getelementptr inbounds i8, ptr %96, i64 8, !dbg !2118
  %.sroa.349.0.copyload.2 = load float, ptr %.sroa.349.0..sroa_idx.2, align 4, !dbg !2118
  tail call void @llvm.dbg.value(metadata float %.sroa.349.0.copyload.2, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !2121
  tail call void @llvm.dbg.value(metadata i1 true, metadata !2122, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 0, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float undef, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %98 = extractelement <2 x float> %97, i64 0, !dbg !2136
  %99 = tail call float @llvm.fabs.f32(float %98), !dbg !2136
  %100 = bitcast float %99 to i32, !dbg !2136
  %101 = icmp ult i32 %100, 2139095040, !dbg !2137
  br i1 %101, label %Then12.us.2, label %Block20.us.2, !dbg !2138

Then12.us.2:                                      ; preds = %Block20.us.1
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 1, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float undef, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %102 = extractelement <2 x float> %97, i64 1, !dbg !2136
  %103 = tail call float @llvm.fabs.f32(float %102), !dbg !2136
  %104 = bitcast float %103 to i32, !dbg !2136
  %105 = icmp ult i32 %104, 2139095040, !dbg !2137
  br i1 %105, label %Then12.us.1.2, label %Block20.us.2, !dbg !2138

Then12.us.1.2:                                    ; preds = %Then12.us.2
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 2, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float %.sroa.349.0.copyload.2, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %106 = tail call float @llvm.fabs.f32(float %.sroa.349.0.copyload.2), !dbg !2136
  %107 = bitcast float %106 to i32, !dbg !2136
  %108 = icmp ult i32 %107, 2139095040, !dbg !2137
  br i1 %108, label %Then15.us.2, label %Block20.us.2, !dbg !2138

Then15.us.2:                                      ; preds = %Then12.us.1.2
  %109 = fpext <2 x float> %97 to <2 x double>, !dbg !2139
  call void @llvm.dbg.value(metadata double undef, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double %113, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata double undef, metadata !2141, metadata !DIExpression()), !dbg !2142
  %110 = fsub <2 x double> %109, %14, !dbg !2143
  %111 = extractelement <2 x double> %110, i64 0, !dbg !2145
  %112 = fmul double %111, %13, !dbg !2145
  %113 = fadd double %112, 0.000000e+00, !dbg !2147
  %114 = extractelement <2 x double> %110, i64 1, !dbg !2145
  %115 = fmul double %114, %15, !dbg !2145
  %116 = fadd double %113, %115, !dbg !2147
  tail call void @llvm.dbg.value(metadata double %116, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double undef, metadata !2123, metadata !DIExpression()), !dbg !2121
  %117 = fmul <2 x double> %110, %110, !dbg !2148
  %shift.2 = shufflevector <2 x double> %117, <2 x double> poison, <2 x i32> <i32 1, i32 poison>, !dbg !2149
  %118 = fadd <2 x double> %117, %shift.2, !dbg !2149
  %119 = extractelement <2 x double> %118, i64 0, !dbg !2149
  tail call void @llvm.dbg.value(metadata double %119, metadata !2123, metadata !DIExpression()), !dbg !2121
  %120 = fpext float %.sroa.349.0.copyload.2 to double, !dbg !2139
  %121 = fsub double %120, %16, !dbg !2143
  call void @llvm.dbg.value(metadata double %121, metadata !2141, metadata !DIExpression()), !dbg !2142
  %122 = fmul double %121, %121, !dbg !2148
  %123 = fadd double %119, %122, !dbg !2149
  tail call void @llvm.dbg.value(metadata double %123, metadata !2123, metadata !DIExpression()), !dbg !2121
  %124 = fmul double %121, %17, !dbg !2145
  %125 = fadd double %116, %124, !dbg !2147
  tail call void @llvm.dbg.value(metadata double %125, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata i1 true, metadata !2122, metadata !DIExpression()), !dbg !2121
  %126 = fcmp ugt double %123, 0.000000e+00
  br i1 %126, label %Else17.us.2, label %Block20.us.2, !dbg !2150

Else17.us.2:                                      ; preds = %Then15.us.2
  call void @llvm.dbg.value(metadata double %123, metadata !1986, metadata !DIExpression()), !dbg !2154
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2158
  %127 = tail call double @llvm.fabs.f64(double %123), !dbg !2159
  %128 = bitcast double %127 to i64, !dbg !2159
  %129 = icmp ult i64 %128, 9218868437227405312, !dbg !2160
  br i1 %129, label %Else18.us.2, label %Block20.us.2, !dbg !2161

Else18.us.2:                                      ; preds = %Else17.us.2
  call void @llvm.dbg.value(metadata double %125, metadata !1986, metadata !DIExpression()), !dbg !2164
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2168
  %130 = tail call double @llvm.fabs.f64(double %125), !dbg !2169
  %131 = bitcast double %130 to i64, !dbg !2169
  %132 = icmp ult i64 %131, 9218868437227405312, !dbg !2170
  br i1 %132, label %Else19.us.2, label %Block20.us.2, !dbg !2171

Else19.us.2:                                      ; preds = %Else18.us.2
  %133 = fdiv double %125, %123, !dbg !2173
  %134 = tail call double @llvm.maxnum.f64(double %133, double 0.000000e+00), !dbg !2176
  br label %Block20.us.2, !dbg !2173

Block20.us.2:                                     ; preds = %Else19.us.2, %Else18.us.2, %Else17.us.2, %Then15.us.2, %Then12.us.1.2, %Then12.us.2, %Block20.us.1
  %135 = phi double [ %134, %Else19.us.2 ], [ 0.000000e+00, %Else17.us.2 ], [ 0.000000e+00, %Then15.us.2 ], [ 0.000000e+00, %Else18.us.2 ], [ 0.000000e+00, %Block20.us.1 ], [ 0.000000e+00, %Then12.us.2 ], [ 0.000000e+00, %Then12.us.1.2 ], !dbg !2177
  %136 = getelementptr inbounds [6 x double], ptr %3, i64 %.sroa.0.034, i64 2, !dbg !2179
  store double %135, ptr %136, align 8, !dbg !2177
  call void @llvm.dbg.value(metadata i32 poison, metadata !2113, metadata !DIExpression()), !dbg !2114
  call void @llvm.dbg.value(metadata i64 3, metadata !2115, metadata !DIExpression()), !dbg !2114
  tail call void @llvm.dbg.value(metadata i1 poison, metadata !2081, metadata !DIExpression()), !dbg !2078
  call void @llvm.dbg.value(metadata i32 %.sroa.5.0.copyload63, metadata !2113, metadata !DIExpression()), !dbg !2114
  %137 = zext i32 %.sroa.5.0.copyload63 to i64, !dbg !2118
  %138 = getelementptr inbounds [3 x float], ptr %0, i64 %137, !dbg !2118
  tail call void @llvm.dbg.value(metadata float undef, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !2121
  %139 = load <2 x float>, ptr %138, align 4, !dbg !2118
  tail call void @llvm.dbg.value(metadata float undef, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !2121
  %.sroa.349.0..sroa_idx.3 = getelementptr inbounds i8, ptr %138, i64 8, !dbg !2118
  %.sroa.349.0.copyload.3 = load float, ptr %.sroa.349.0..sroa_idx.3, align 4, !dbg !2118
  tail call void @llvm.dbg.value(metadata float %.sroa.349.0.copyload.3, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !2121
  tail call void @llvm.dbg.value(metadata i1 true, metadata !2122, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 0, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float undef, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %140 = extractelement <2 x float> %139, i64 0, !dbg !2136
  %141 = tail call float @llvm.fabs.f32(float %140), !dbg !2136
  %142 = bitcast float %141 to i32, !dbg !2136
  %143 = icmp ult i32 %142, 2139095040, !dbg !2137
  br i1 %143, label %Then12.us.3, label %Block20.us.3, !dbg !2138

Then12.us.3:                                      ; preds = %Block20.us.2
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 1, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float undef, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %144 = extractelement <2 x float> %139, i64 1, !dbg !2136
  %145 = tail call float @llvm.fabs.f32(float %144), !dbg !2136
  %146 = bitcast float %145 to i32, !dbg !2136
  %147 = icmp ult i32 %146, 2139095040, !dbg !2137
  br i1 %147, label %Then12.us.1.3, label %Block20.us.3, !dbg !2138

Then12.us.1.3:                                    ; preds = %Then12.us.3
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 2, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float %.sroa.349.0.copyload.3, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %148 = tail call float @llvm.fabs.f32(float %.sroa.349.0.copyload.3), !dbg !2136
  %149 = bitcast float %148 to i32, !dbg !2136
  %150 = icmp ult i32 %149, 2139095040, !dbg !2137
  br i1 %150, label %Then15.us.3, label %Block20.us.3, !dbg !2138

Then15.us.3:                                      ; preds = %Then12.us.1.3
  %151 = fpext <2 x float> %139 to <2 x double>, !dbg !2139
  call void @llvm.dbg.value(metadata double undef, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double %155, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata double undef, metadata !2141, metadata !DIExpression()), !dbg !2142
  %152 = fsub <2 x double> %151, %14, !dbg !2143
  %153 = extractelement <2 x double> %152, i64 0, !dbg !2145
  %154 = fmul double %153, %13, !dbg !2145
  %155 = fadd double %154, 0.000000e+00, !dbg !2147
  %156 = extractelement <2 x double> %152, i64 1, !dbg !2145
  %157 = fmul double %156, %15, !dbg !2145
  %158 = fadd double %155, %157, !dbg !2147
  tail call void @llvm.dbg.value(metadata double %158, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double undef, metadata !2123, metadata !DIExpression()), !dbg !2121
  %159 = fmul <2 x double> %152, %152, !dbg !2148
  %shift.3 = shufflevector <2 x double> %159, <2 x double> poison, <2 x i32> <i32 1, i32 poison>, !dbg !2149
  %160 = fadd <2 x double> %159, %shift.3, !dbg !2149
  %161 = extractelement <2 x double> %160, i64 0, !dbg !2149
  tail call void @llvm.dbg.value(metadata double %161, metadata !2123, metadata !DIExpression()), !dbg !2121
  %162 = fpext float %.sroa.349.0.copyload.3 to double, !dbg !2139
  %163 = fsub double %162, %16, !dbg !2143
  call void @llvm.dbg.value(metadata double %163, metadata !2141, metadata !DIExpression()), !dbg !2142
  %164 = fmul double %163, %163, !dbg !2148
  %165 = fadd double %161, %164, !dbg !2149
  tail call void @llvm.dbg.value(metadata double %165, metadata !2123, metadata !DIExpression()), !dbg !2121
  %166 = fmul double %163, %17, !dbg !2145
  %167 = fadd double %158, %166, !dbg !2147
  tail call void @llvm.dbg.value(metadata double %167, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata i1 true, metadata !2122, metadata !DIExpression()), !dbg !2121
  %168 = fcmp ugt double %165, 0.000000e+00
  br i1 %168, label %Else17.us.3, label %Block20.us.3, !dbg !2150

Else17.us.3:                                      ; preds = %Then15.us.3
  call void @llvm.dbg.value(metadata double %165, metadata !1986, metadata !DIExpression()), !dbg !2154
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2158
  %169 = tail call double @llvm.fabs.f64(double %165), !dbg !2159
  %170 = bitcast double %169 to i64, !dbg !2159
  %171 = icmp ult i64 %170, 9218868437227405312, !dbg !2160
  br i1 %171, label %Else18.us.3, label %Block20.us.3, !dbg !2161

Else18.us.3:                                      ; preds = %Else17.us.3
  call void @llvm.dbg.value(metadata double %167, metadata !1986, metadata !DIExpression()), !dbg !2164
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2168
  %172 = tail call double @llvm.fabs.f64(double %167), !dbg !2169
  %173 = bitcast double %172 to i64, !dbg !2169
  %174 = icmp ult i64 %173, 9218868437227405312, !dbg !2170
  br i1 %174, label %Else19.us.3, label %Block20.us.3, !dbg !2171

Else19.us.3:                                      ; preds = %Else18.us.3
  %175 = fdiv double %167, %165, !dbg !2173
  %176 = tail call double @llvm.maxnum.f64(double %175, double 0.000000e+00), !dbg !2176
  br label %Block20.us.3, !dbg !2173

Block20.us.3:                                     ; preds = %Else19.us.3, %Else18.us.3, %Else17.us.3, %Then15.us.3, %Then12.us.1.3, %Then12.us.3, %Block20.us.2
  %177 = phi double [ %176, %Else19.us.3 ], [ 0.000000e+00, %Else17.us.3 ], [ 0.000000e+00, %Then15.us.3 ], [ 0.000000e+00, %Else18.us.3 ], [ 0.000000e+00, %Block20.us.2 ], [ 0.000000e+00, %Then12.us.3 ], [ 0.000000e+00, %Then12.us.1.3 ], !dbg !2177
  %178 = getelementptr inbounds [6 x double], ptr %3, i64 %.sroa.0.034, i64 3, !dbg !2179
  store double %177, ptr %178, align 8, !dbg !2177
  call void @llvm.dbg.value(metadata i32 poison, metadata !2113, metadata !DIExpression()), !dbg !2114
  call void @llvm.dbg.value(metadata i64 4, metadata !2115, metadata !DIExpression()), !dbg !2114
  tail call void @llvm.dbg.value(metadata i1 poison, metadata !2081, metadata !DIExpression()), !dbg !2078
  call void @llvm.dbg.value(metadata i32 %.sroa.6.0.copyload65, metadata !2113, metadata !DIExpression()), !dbg !2114
  %179 = zext i32 %.sroa.6.0.copyload65 to i64, !dbg !2118
  %180 = getelementptr inbounds [3 x float], ptr %0, i64 %179, !dbg !2118
  tail call void @llvm.dbg.value(metadata float undef, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !2121
  %181 = load <2 x float>, ptr %180, align 4, !dbg !2118
  tail call void @llvm.dbg.value(metadata float undef, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !2121
  %.sroa.349.0..sroa_idx.4 = getelementptr inbounds i8, ptr %180, i64 8, !dbg !2118
  %.sroa.349.0.copyload.4 = load float, ptr %.sroa.349.0..sroa_idx.4, align 4, !dbg !2118
  tail call void @llvm.dbg.value(metadata float %.sroa.349.0.copyload.4, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !2121
  tail call void @llvm.dbg.value(metadata i1 true, metadata !2122, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 0, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float undef, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %182 = extractelement <2 x float> %181, i64 0, !dbg !2136
  %183 = tail call float @llvm.fabs.f32(float %182), !dbg !2136
  %184 = bitcast float %183 to i32, !dbg !2136
  %185 = icmp ult i32 %184, 2139095040, !dbg !2137
  br i1 %185, label %Then12.us.4, label %Block20.us.4, !dbg !2138

Then12.us.4:                                      ; preds = %Block20.us.3
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 1, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float undef, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %186 = extractelement <2 x float> %181, i64 1, !dbg !2136
  %187 = tail call float @llvm.fabs.f32(float %186), !dbg !2136
  %188 = bitcast float %187 to i32, !dbg !2136
  %189 = icmp ult i32 %188, 2139095040, !dbg !2137
  br i1 %189, label %Then12.us.1.4, label %Block20.us.4, !dbg !2138

Then12.us.1.4:                                    ; preds = %Then12.us.4
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 2, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float %.sroa.349.0.copyload.4, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %190 = tail call float @llvm.fabs.f32(float %.sroa.349.0.copyload.4), !dbg !2136
  %191 = bitcast float %190 to i32, !dbg !2136
  %192 = icmp ult i32 %191, 2139095040, !dbg !2137
  br i1 %192, label %Then15.us.4, label %Block20.us.4, !dbg !2138

Then15.us.4:                                      ; preds = %Then12.us.1.4
  %193 = fpext <2 x float> %181 to <2 x double>, !dbg !2139
  call void @llvm.dbg.value(metadata double undef, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double %197, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata double undef, metadata !2141, metadata !DIExpression()), !dbg !2142
  %194 = fsub <2 x double> %193, %14, !dbg !2143
  %195 = extractelement <2 x double> %194, i64 0, !dbg !2145
  %196 = fmul double %195, %13, !dbg !2145
  %197 = fadd double %196, 0.000000e+00, !dbg !2147
  %198 = extractelement <2 x double> %194, i64 1, !dbg !2145
  %199 = fmul double %198, %15, !dbg !2145
  %200 = fadd double %197, %199, !dbg !2147
  tail call void @llvm.dbg.value(metadata double %200, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double undef, metadata !2123, metadata !DIExpression()), !dbg !2121
  %201 = fmul <2 x double> %194, %194, !dbg !2148
  %shift.4 = shufflevector <2 x double> %201, <2 x double> poison, <2 x i32> <i32 1, i32 poison>, !dbg !2149
  %202 = fadd <2 x double> %201, %shift.4, !dbg !2149
  %203 = extractelement <2 x double> %202, i64 0, !dbg !2149
  tail call void @llvm.dbg.value(metadata double %203, metadata !2123, metadata !DIExpression()), !dbg !2121
  %204 = fpext float %.sroa.349.0.copyload.4 to double, !dbg !2139
  %205 = fsub double %204, %16, !dbg !2143
  call void @llvm.dbg.value(metadata double %205, metadata !2141, metadata !DIExpression()), !dbg !2142
  %206 = fmul double %205, %205, !dbg !2148
  %207 = fadd double %203, %206, !dbg !2149
  tail call void @llvm.dbg.value(metadata double %207, metadata !2123, metadata !DIExpression()), !dbg !2121
  %208 = fmul double %205, %17, !dbg !2145
  %209 = fadd double %200, %208, !dbg !2147
  tail call void @llvm.dbg.value(metadata double %209, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata i1 true, metadata !2122, metadata !DIExpression()), !dbg !2121
  %210 = fcmp ugt double %207, 0.000000e+00
  br i1 %210, label %Else17.us.4, label %Block20.us.4, !dbg !2150

Else17.us.4:                                      ; preds = %Then15.us.4
  call void @llvm.dbg.value(metadata double %207, metadata !1986, metadata !DIExpression()), !dbg !2154
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2158
  %211 = tail call double @llvm.fabs.f64(double %207), !dbg !2159
  %212 = bitcast double %211 to i64, !dbg !2159
  %213 = icmp ult i64 %212, 9218868437227405312, !dbg !2160
  br i1 %213, label %Else18.us.4, label %Block20.us.4, !dbg !2161

Else18.us.4:                                      ; preds = %Else17.us.4
  call void @llvm.dbg.value(metadata double %209, metadata !1986, metadata !DIExpression()), !dbg !2164
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2168
  %214 = tail call double @llvm.fabs.f64(double %209), !dbg !2169
  %215 = bitcast double %214 to i64, !dbg !2169
  %216 = icmp ult i64 %215, 9218868437227405312, !dbg !2170
  br i1 %216, label %Else19.us.4, label %Block20.us.4, !dbg !2171

Else19.us.4:                                      ; preds = %Else18.us.4
  %217 = fdiv double %209, %207, !dbg !2173
  %218 = tail call double @llvm.maxnum.f64(double %217, double 0.000000e+00), !dbg !2176
  br label %Block20.us.4, !dbg !2173

Block20.us.4:                                     ; preds = %Else19.us.4, %Else18.us.4, %Else17.us.4, %Then15.us.4, %Then12.us.1.4, %Then12.us.4, %Block20.us.3
  %219 = phi double [ %218, %Else19.us.4 ], [ 0.000000e+00, %Else17.us.4 ], [ 0.000000e+00, %Then15.us.4 ], [ 0.000000e+00, %Else18.us.4 ], [ 0.000000e+00, %Block20.us.3 ], [ 0.000000e+00, %Then12.us.4 ], [ 0.000000e+00, %Then12.us.1.4 ], !dbg !2177
  %220 = getelementptr inbounds [6 x double], ptr %3, i64 %.sroa.0.034, i64 4, !dbg !2179
  store double %219, ptr %220, align 8, !dbg !2177
  call void @llvm.dbg.value(metadata i32 poison, metadata !2113, metadata !DIExpression()), !dbg !2114
  call void @llvm.dbg.value(metadata i64 5, metadata !2115, metadata !DIExpression()), !dbg !2114
  tail call void @llvm.dbg.value(metadata i1 poison, metadata !2081, metadata !DIExpression()), !dbg !2078
  call void @llvm.dbg.value(metadata i32 %.sroa.7.0.copyload67, metadata !2113, metadata !DIExpression()), !dbg !2114
  %221 = zext i32 %.sroa.7.0.copyload67 to i64, !dbg !2118
  %222 = getelementptr inbounds [3 x float], ptr %0, i64 %221, !dbg !2118
  tail call void @llvm.dbg.value(metadata float undef, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !2121
  %223 = load <2 x float>, ptr %222, align 4, !dbg !2118
  tail call void @llvm.dbg.value(metadata float undef, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !2121
  %.sroa.349.0..sroa_idx.5 = getelementptr inbounds i8, ptr %222, i64 8, !dbg !2118
  %.sroa.349.0.copyload.5 = load float, ptr %.sroa.349.0..sroa_idx.5, align 4, !dbg !2118
  tail call void @llvm.dbg.value(metadata float %.sroa.349.0.copyload.5, metadata !2120, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !2121
  tail call void @llvm.dbg.value(metadata i1 true, metadata !2122, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 0, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float undef, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %224 = extractelement <2 x float> %223, i64 0, !dbg !2136
  %225 = tail call float @llvm.fabs.f32(float %224), !dbg !2136
  %226 = bitcast float %225 to i32, !dbg !2136
  %227 = icmp ult i32 %226, 2139095040, !dbg !2137
  br i1 %227, label %Then12.us.5, label %Block20.us.5, !dbg !2138

Then12.us.5:                                      ; preds = %Block20.us.4
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 1, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float undef, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %228 = extractelement <2 x float> %223, i64 1, !dbg !2136
  %229 = tail call float @llvm.fabs.f32(float %228), !dbg !2136
  %230 = bitcast float %229 to i32, !dbg !2136
  %231 = icmp ult i32 %230, 2139095040, !dbg !2137
  br i1 %231, label %Then12.us.1.5, label %Block20.us.5, !dbg !2138

Then12.us.1.5:                                    ; preds = %Then12.us.5
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 2, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float %.sroa.349.0.copyload.5, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %232 = tail call float @llvm.fabs.f32(float %.sroa.349.0.copyload.5), !dbg !2136
  %233 = bitcast float %232 to i32, !dbg !2136
  %234 = icmp ult i32 %233, 2139095040, !dbg !2137
  br i1 %234, label %Then15.us.5, label %Block20.us.5, !dbg !2138

Then15.us.5:                                      ; preds = %Then12.us.1.5
  %235 = fpext <2 x float> %223 to <2 x double>, !dbg !2139
  call void @llvm.dbg.value(metadata double undef, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double %239, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata double undef, metadata !2141, metadata !DIExpression()), !dbg !2142
  %236 = fsub <2 x double> %235, %14, !dbg !2143
  %237 = extractelement <2 x double> %236, i64 0, !dbg !2145
  %238 = fmul double %237, %13, !dbg !2145
  %239 = fadd double %238, 0.000000e+00, !dbg !2147
  %240 = extractelement <2 x double> %236, i64 1, !dbg !2145
  %241 = fmul double %240, %15, !dbg !2145
  %242 = fadd double %239, %241, !dbg !2147
  tail call void @llvm.dbg.value(metadata double %242, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double undef, metadata !2123, metadata !DIExpression()), !dbg !2121
  %243 = fmul <2 x double> %236, %236, !dbg !2148
  %shift.5 = shufflevector <2 x double> %243, <2 x double> poison, <2 x i32> <i32 1, i32 poison>, !dbg !2149
  %244 = fadd <2 x double> %243, %shift.5, !dbg !2149
  %245 = extractelement <2 x double> %244, i64 0, !dbg !2149
  tail call void @llvm.dbg.value(metadata double %245, metadata !2123, metadata !DIExpression()), !dbg !2121
  %246 = fpext float %.sroa.349.0.copyload.5 to double, !dbg !2139
  %247 = fsub double %246, %16, !dbg !2143
  call void @llvm.dbg.value(metadata double %247, metadata !2141, metadata !DIExpression()), !dbg !2142
  %248 = fmul double %247, %247, !dbg !2148
  %249 = fadd double %245, %248, !dbg !2149
  tail call void @llvm.dbg.value(metadata double %249, metadata !2123, metadata !DIExpression()), !dbg !2121
  %250 = fmul double %247, %17, !dbg !2145
  %251 = fadd double %242, %250, !dbg !2147
  tail call void @llvm.dbg.value(metadata double %251, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata i1 true, metadata !2122, metadata !DIExpression()), !dbg !2121
  %252 = fcmp ugt double %249, 0.000000e+00
  br i1 %252, label %Else17.us.5, label %Block20.us.5, !dbg !2150

Else17.us.5:                                      ; preds = %Then15.us.5
  call void @llvm.dbg.value(metadata double %249, metadata !1986, metadata !DIExpression()), !dbg !2154
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2158
  %253 = tail call double @llvm.fabs.f64(double %249), !dbg !2159
  %254 = bitcast double %253 to i64, !dbg !2159
  %255 = icmp ult i64 %254, 9218868437227405312, !dbg !2160
  br i1 %255, label %Else18.us.5, label %Block20.us.5, !dbg !2161

Else18.us.5:                                      ; preds = %Else17.us.5
  call void @llvm.dbg.value(metadata double %251, metadata !1986, metadata !DIExpression()), !dbg !2164
  call void @llvm.dbg.value(metadata i64 9223372036854775807, metadata !1995, metadata !DIExpression()), !dbg !2168
  %256 = tail call double @llvm.fabs.f64(double %251), !dbg !2169
  %257 = bitcast double %256 to i64, !dbg !2169
  %258 = icmp ult i64 %257, 9218868437227405312, !dbg !2170
  br i1 %258, label %Else19.us.5, label %Block20.us.5, !dbg !2171

Else19.us.5:                                      ; preds = %Else18.us.5
  %259 = fdiv double %251, %249, !dbg !2173
  %260 = tail call double @llvm.maxnum.f64(double %259, double 0.000000e+00), !dbg !2176
  br label %Block20.us.5, !dbg !2173

Block20.us.5:                                     ; preds = %Else19.us.5, %Else18.us.5, %Else17.us.5, %Then15.us.5, %Then12.us.1.5, %Then12.us.5, %Block20.us.4
  %261 = phi double [ %260, %Else19.us.5 ], [ 0.000000e+00, %Else17.us.5 ], [ 0.000000e+00, %Then15.us.5 ], [ 0.000000e+00, %Else18.us.5 ], [ 0.000000e+00, %Block20.us.4 ], [ 0.000000e+00, %Then12.us.5 ], [ 0.000000e+00, %Then12.us.1.5 ], !dbg !2177
  %262 = getelementptr inbounds [6 x double], ptr %3, i64 %.sroa.0.034, i64 5, !dbg !2179
  store double %261, ptr %262, align 8, !dbg !2177
  br label %Else6, !dbg !2116

Then12.us:                                        ; preds = %Then6.us.preheader
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 1, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float undef, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %263 = extractelement <2 x float> %20, i64 1, !dbg !2136
  %264 = tail call float @llvm.fabs.f32(float %263), !dbg !2136
  %265 = bitcast float %264 to i32, !dbg !2136
  %266 = icmp ult i32 %265, 2139095040, !dbg !2137
  br i1 %266, label %Then12.us.1, label %Block20.us, !dbg !2138

Then12.us.1:                                      ; preds = %Then12.us
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata double poison, metadata !2141, metadata !DIExpression()), !dbg !2142
  tail call void @llvm.dbg.value(metadata double poison, metadata !2123, metadata !DIExpression()), !dbg !2121
  tail call void @llvm.dbg.value(metadata double poison, metadata !2124, metadata !DIExpression()), !dbg !2121
  call void @llvm.dbg.value(metadata i64 2, metadata !2125, metadata !DIExpression()), !dbg !2130
  call void @llvm.dbg.value(metadata float %.sroa.349.0.copyload, metadata !2088, metadata !DIExpression()), !dbg !2131
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2135
  %267 = tail call float @llvm.fabs.f32(float %.sroa.349.0.copyload), !dbg !2136
  %268 = bitcast float %267 to i32, !dbg !2136
  %269 = icmp ult i32 %268, 2139095040, !dbg !2137
  br i1 %269, label %Then15.us, label %Block20.us, !dbg !2138

Block4:                                           ; preds = %Then4, %Then5
  %270 = phi i1 [ true, %Then4 ], [ false, %Then5 ]
  call void @llvm.dbg.value(metadata i64 1, metadata !2082, metadata !DIExpression()), !dbg !2087
  call void @llvm.dbg.value(metadata float undef, metadata !2088, metadata !DIExpression()), !dbg !2092
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2097
  %271 = extractelement <2 x float> %7, i64 1, !dbg !2098
  %272 = tail call float @llvm.fabs.f32(float %271), !dbg !2098
  %273 = bitcast float %272 to i32, !dbg !2098
  %274 = icmp ult i32 %273, 2139095040, !dbg !2099
  br i1 %274, label %Then4.1, label %Then5.1, !dbg !2101

Then4.1:                                          ; preds = %Block4
  call void @llvm.dbg.value(metadata float %.sroa.344.0.copyload, metadata !2088, metadata !DIExpression()), !dbg !2181
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2185
  %275 = tail call float @llvm.fabs.f32(float %.sroa.344.0.copyload), !dbg !2186
  %276 = bitcast float %275 to i32, !dbg !2186
  %277 = icmp ult i32 %276, 2139095040, !dbg !2187
  br i1 %277, label %Block4.1, label %Then5.1, !dbg !2188

Then5.1:                                          ; preds = %Then4.1, %Block4
  tail call void @llvm.dbg.value(metadata i1 false, metadata !2081, metadata !DIExpression()), !dbg !2078
  br label %Block4.1, !dbg !2190

Block4.1:                                         ; preds = %Then5.1, %Then4.1
  %278 = phi i1 [ %270, %Then4.1 ], [ false, %Then5.1 ]
  call void @llvm.dbg.value(metadata i64 2, metadata !2082, metadata !DIExpression()), !dbg !2087
  call void @llvm.dbg.value(metadata float %.sroa.5.0.copyload, metadata !2088, metadata !DIExpression()), !dbg !2092
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2097
  %279 = tail call float @llvm.fabs.f32(float %.sroa.5.0.copyload), !dbg !2098
  %280 = bitcast float %279 to i32, !dbg !2098
  %281 = icmp ult i32 %280, 2139095040, !dbg !2099
  br i1 %281, label %Then4.2, label %Then6.preheader, !dbg !2101

Then4.2:                                          ; preds = %Block4.1
  call void @llvm.dbg.value(metadata float %.sroa.546.0.copyload, metadata !2088, metadata !DIExpression()), !dbg !2181
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2185
  %282 = tail call float @llvm.fabs.f32(float %.sroa.546.0.copyload), !dbg !2186
  %283 = bitcast float %282 to i32, !dbg !2186
  %284 = icmp ult i32 %283, 2139095040, !dbg !2187
  br i1 %284, label %Block4.2, label %Then6.preheader, !dbg !2188

Block4.2:                                         ; preds = %Then4.2
  %285 = getelementptr inbounds [6 x i32], ptr %2, i64 %.sroa.0.034, !dbg !2193
  %.sroa.0.0.copyload55 = load i32, ptr %285, align 4, !dbg !2193
  %.sroa.3.0..sroa_idx56 = getelementptr inbounds i8, ptr %285, i64 4, !dbg !2193
  %.sroa.3.0.copyload57 = load i32, ptr %.sroa.3.0..sroa_idx56, align 4, !dbg !2193
  %.sroa.4.0..sroa_idx58 = getelementptr inbounds i8, ptr %285, i64 8, !dbg !2193
  %.sroa.4.0.copyload59 = load i32, ptr %.sroa.4.0..sroa_idx58, align 4, !dbg !2193
  %.sroa.5.0..sroa_idx62 = getelementptr inbounds i8, ptr %285, i64 12, !dbg !2193
  %.sroa.5.0.copyload63 = load i32, ptr %.sroa.5.0..sroa_idx62, align 4, !dbg !2193
  %.sroa.6.0..sroa_idx64 = getelementptr inbounds i8, ptr %285, i64 16, !dbg !2193
  %.sroa.6.0.copyload65 = load i32, ptr %.sroa.6.0..sroa_idx64, align 4, !dbg !2193
  %.sroa.7.0..sroa_idx66 = getelementptr inbounds i8, ptr %285, i64 20, !dbg !2193
  %.sroa.7.0.copyload67 = load i32, ptr %.sroa.7.0..sroa_idx66, align 4, !dbg !2193
  br i1 %278, label %Then6.us.preheader, label %Then6.preheader, !dbg !2194

Then4:                                            ; preds = %Then
  call void @llvm.dbg.value(metadata float %.sroa.042.0.copyload, metadata !2088, metadata !DIExpression()), !dbg !2181
  call void @llvm.dbg.value(metadata i32 2147483647, metadata !2096, metadata !DIExpression()), !dbg !2185
  %286 = tail call float @llvm.fabs.f32(float %.sroa.042.0.copyload), !dbg !2186
  %287 = bitcast float %286 to i32, !dbg !2186
  %288 = icmp ult i32 %287, 2139095040, !dbg !2187
  br i1 %288, label %Block4, label %Then5, !dbg !2188

Then5:                                            ; preds = %Then, %Then4
  tail call void @llvm.dbg.value(metadata i1 false, metadata !2081, metadata !DIExpression()), !dbg !2078
  br label %Block4, !dbg !2190

Else6:                                            ; preds = %Block20.us.5, %Then6.preheader
  %289 = add nuw i64 %.sroa.0.034, 1, !dbg !2116
  %exitcond38.not = icmp eq i64 %289, %4, !dbg !2067
  br i1 %exitcond38.not, label %Else, label %Then, !dbg !2067
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.maxnum.f64(double, double) #1

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: nounwind uwtable
define weak_odr dso_local i64 @getauxval(i64 %0) local_unnamed_addr #4 !dbg !2196 {
Entry:
  call void @llvm.dbg.value(metadata i64 %0, metadata !2199, metadata !DIExpression()), !dbg !2200
  ret i64 0, !dbg !2201
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fabs.f32(float) #5

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #5

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) uwtable "frame-pointer"="none" "probe-stack"="__zig_probe_stack" "target-cpu"="znver4" "target-features"="-16bit-mode,-32bit-mode,-3dnow,-3dnowa,+64bit,+adx,+aes,+allow-light-256-bit,-amx-bf16,-amx-complex,-amx-fp16,-amx-int8,-amx-tile,+avx,-avx10.1-256,-avx10.1-512,+avx2,+avx512bf16,+avx512bitalg,+avx512bw,+avx512cd,+avx512dq,-avx512er,+avx512f,-avx512fp16,+avx512ifma,-avx512pf,+avx512vbmi,+avx512vbmi2,+avx512vl,+avx512vnni,-avx512vp2intersect,+avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,+branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,+clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+evex512,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,+fast-bextr,-fast-gather,-fast-hops,+fast-lzcnt,+fast-movbe,+fast-scalar-fsqrt,+fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,+fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-idivq-to-divl,+invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,-movdir64b,-movdiri,-mwaitx,-ndd,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,-pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prefetchwt1,+prfchw,-ptwrite,-push2pop2,-raoint,+rdpid,+rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,+sbb-dep-breaking,-serialize,-seses,-sgx,+sha,-sha512,+shstk,-slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-soft-float,+sse,+sse2,+sse3,+sse4.1,+sse4.2,+sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,-waitpkg,-wbnoinvd,-widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { nounwind uwtable "frame-pointer"="none" "probe-stack"="__zig_probe_stack" "target-cpu"="znver4" "target-features"="-16bit-mode,-32bit-mode,-3dnow,-3dnowa,+64bit,+adx,+aes,+allow-light-256-bit,-amx-bf16,-amx-complex,-amx-fp16,-amx-int8,-amx-tile,+avx,-avx10.1-256,-avx10.1-512,+avx2,+avx512bf16,+avx512bitalg,+avx512bw,+avx512cd,+avx512dq,-avx512er,+avx512f,-avx512fp16,+avx512ifma,-avx512pf,+avx512vbmi,+avx512vbmi2,+avx512vl,+avx512vnni,-avx512vp2intersect,+avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,+branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,+clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+evex512,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,+fast-bextr,-fast-gather,-fast-hops,+fast-lzcnt,+fast-movbe,+fast-scalar-fsqrt,+fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,+fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-idivq-to-divl,+invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,-movdir64b,-movdiri,-mwaitx,-ndd,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,-pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prefetchwt1,+prfchw,-ptwrite,-push2pop2,-raoint,+rdpid,+rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,+sbb-dep-breaking,-serialize,-seses,-sgx,+sha,-sha512,+shstk,-slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-soft-float,+sse,+sse2,+sse3,+sse4.1,+sse4.2,+sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,-waitpkg,-wbnoinvd,-widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves" }
attributes #5 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!llvm.dbg.cu = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 2, !"Dwarf Version", i32 4}
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "zig 0.13.0", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, globals: !1428, splitDebugInlining: false)
!3 = !DIFile(filename: "probe", directory: "<workspace>/site-tmp/edge-hoist")
!4 = !{!5, !21, !111, !117, !149, !156, !227, !236, !242, !249, !255, !264, !268, !273, !322, !339, !348, !529, !537, !601, !613, !625, !631, !639, !662, !686, !699, !704, !857, !900, !913, !914, !920, !924, !945, !1316, !1329, !1335, !1339, !1345, !1373, !1379}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "builtin.CompilerBackend", scope: !6, file: !6, line: 977, baseType: !7, size: 64, align: 64, elements: !8)
!6 = !DIFile(filename: "builtin.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!7 = !DIBasicType(name: "u64", size: 64, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12, !13, !14, !15, !16, !17, !18, !19, !20}
!9 = !DIEnumerator(name: "other", value: 0, isUnsigned: true)
!10 = !DIEnumerator(name: "stage1", value: 1, isUnsigned: true)
!11 = !DIEnumerator(name: "stage2_llvm", value: 2, isUnsigned: true)
!12 = !DIEnumerator(name: "stage2_c", value: 3, isUnsigned: true)
!13 = !DIEnumerator(name: "stage2_wasm", value: 4, isUnsigned: true)
!14 = !DIEnumerator(name: "stage2_arm", value: 5, isUnsigned: true)
!15 = !DIEnumerator(name: "stage2_x86_64", value: 6, isUnsigned: true)
!16 = !DIEnumerator(name: "stage2_aarch64", value: 7, isUnsigned: true)
!17 = !DIEnumerator(name: "stage2_x86", value: 8, isUnsigned: true)
!18 = !DIEnumerator(name: "stage2_riscv64", value: 9, isUnsigned: true)
!19 = !DIEnumerator(name: "stage2_sparc64", value: 10, isUnsigned: true)
!20 = !DIEnumerator(name: "stage2_spirv64", value: 11, isUnsigned: true)
!21 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Target.Cpu.Arch", scope: !23, file: !22, line: 3433, baseType: !47, size: 8, align: 8, elements: !48)
!22 = !DIFile(filename: "Target.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!23 = !DICompositeType(tag: DW_TAG_structure_type, name: "Target.Cpu", scope: !2, size: 448, align: 64, elements: !24)
!24 = !{!25, !45, !46}
!25 = !DIDerivedType(tag: DW_TAG_member, name: "model", scope: !23, baseType: !26, size: 64, align: 64)
!26 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*Target.Cpu.Model", baseType: !27, size: 64, align: 64)
!27 = !DICompositeType(tag: DW_TAG_structure_type, name: "Target.Cpu.Model", scope: !2, size: 576, align: 64, elements: !28)
!28 = !{!29, !37, !38}
!29 = !DIDerivedType(tag: DW_TAG_member, name: "name", scope: !27, baseType: !30, size: 128, align: 64)
!30 = !DICompositeType(tag: DW_TAG_structure_type, name: "[]u8", scope: !2, size: 128, align: 64, elements: !31)
!31 = !{!32, !35}
!32 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !30, baseType: !33, size: 64, align: 64)
!33 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*u8", baseType: !34, size: 64, align: 8)
!34 = !DIBasicType(name: "u8", size: 8, encoding: DW_ATE_unsigned)
!35 = !DIDerivedType(tag: DW_TAG_member, name: "len", scope: !30, baseType: !36, size: 64, align: 64, offset: 64)
!36 = !DIBasicType(name: "usize", size: 64, encoding: DW_ATE_unsigned)
!37 = !DIDerivedType(tag: DW_TAG_member, name: "llvm_name", scope: !27, baseType: !30, size: 128, align: 64, offset: 128)
!38 = !DIDerivedType(tag: DW_TAG_member, name: "features", scope: !27, baseType: !39, size: 320, align: 64, offset: 256)
!39 = !DICompositeType(tag: DW_TAG_structure_type, name: "Target.Cpu.Feature.Set", scope: !2, size: 320, align: 64, elements: !40)
!40 = !{!41}
!41 = !DIDerivedType(tag: DW_TAG_member, name: "ints", scope: !39, baseType: !42, size: 320, align: 64)
!42 = !DICompositeType(tag: DW_TAG_array_type, baseType: !36, size: 320, align: 64, elements: !43)
!43 = !{!44}
!44 = !DISubrange(count: 5, lowerBound: -2384)
!45 = !DIDerivedType(tag: DW_TAG_member, name: "features", scope: !23, baseType: !39, size: 320, align: 64, offset: 64)
!46 = !DIDerivedType(tag: DW_TAG_member, name: "arch", scope: !23, baseType: !21, size: 8, align: 8, offset: 384)
!47 = !DIBasicType(name: "u6", size: 8, encoding: DW_ATE_unsigned)
!48 = !{!49, !50, !51, !52, !53, !54, !55, !56, !57, !58, !59, !60, !61, !62, !63, !64, !65, !66, !67, !68, !69, !70, !71, !72, !73, !74, !75, !76, !77, !78, !79, !80, !81, !82, !83, !84, !85, !86, !87, !88, !89, !90, !91, !92, !93, !94, !95, !96, !97, !98, !99, !100, !101, !102, !103, !104, !105, !106, !107, !108, !109, !110}
!49 = !DIEnumerator(name: "arm", value: 0, isUnsigned: true)
!50 = !DIEnumerator(name: "armeb", value: 1, isUnsigned: true)
!51 = !DIEnumerator(name: "aarch64", value: 2, isUnsigned: true)
!52 = !DIEnumerator(name: "aarch64_be", value: 3, isUnsigned: true)
!53 = !DIEnumerator(name: "aarch64_32", value: 4, isUnsigned: true)
!54 = !DIEnumerator(name: "arc", value: 5, isUnsigned: true)
!55 = !DIEnumerator(name: "avr", value: 6, isUnsigned: true)
!56 = !DIEnumerator(name: "bpfel", value: 7, isUnsigned: true)
!57 = !DIEnumerator(name: "bpfeb", value: 8, isUnsigned: true)
!58 = !DIEnumerator(name: "csky", value: 9, isUnsigned: true)
!59 = !DIEnumerator(name: "dxil", value: 10, isUnsigned: true)
!60 = !DIEnumerator(name: "hexagon", value: 11, isUnsigned: true)
!61 = !DIEnumerator(name: "loongarch32", value: 12, isUnsigned: true)
!62 = !DIEnumerator(name: "loongarch64", value: 13, isUnsigned: true)
!63 = !DIEnumerator(name: "m68k", value: 14, isUnsigned: true)
!64 = !DIEnumerator(name: "mips", value: 15, isUnsigned: true)
!65 = !DIEnumerator(name: "mipsel", value: 16, isUnsigned: true)
!66 = !DIEnumerator(name: "mips64", value: 17, isUnsigned: true)
!67 = !DIEnumerator(name: "mips64el", value: 18, isUnsigned: true)
!68 = !DIEnumerator(name: "msp430", value: 19, isUnsigned: true)
!69 = !DIEnumerator(name: "powerpc", value: 20, isUnsigned: true)
!70 = !DIEnumerator(name: "powerpcle", value: 21, isUnsigned: true)
!71 = !DIEnumerator(name: "powerpc64", value: 22, isUnsigned: true)
!72 = !DIEnumerator(name: "powerpc64le", value: 23, isUnsigned: true)
!73 = !DIEnumerator(name: "r600", value: 24, isUnsigned: true)
!74 = !DIEnumerator(name: "amdgcn", value: 25, isUnsigned: true)
!75 = !DIEnumerator(name: "riscv32", value: 26, isUnsigned: true)
!76 = !DIEnumerator(name: "riscv64", value: 27, isUnsigned: true)
!77 = !DIEnumerator(name: "sparc", value: 28, isUnsigned: true)
!78 = !DIEnumerator(name: "sparc64", value: 29, isUnsigned: true)
!79 = !DIEnumerator(name: "sparcel", value: 30, isUnsigned: true)
!80 = !DIEnumerator(name: "s390x", value: 31, isUnsigned: true)
!81 = !DIEnumerator(name: "tce", value: 32, isUnsigned: true)
!82 = !DIEnumerator(name: "tcele", value: 33, isUnsigned: true)
!83 = !DIEnumerator(name: "thumb", value: 34, isUnsigned: true)
!84 = !DIEnumerator(name: "thumbeb", value: 35, isUnsigned: true)
!85 = !DIEnumerator(name: "x86", value: 36, isUnsigned: true)
!86 = !DIEnumerator(name: "x86_64", value: 37, isUnsigned: true)
!87 = !DIEnumerator(name: "xcore", value: 38, isUnsigned: true)
!88 = !DIEnumerator(name: "xtensa", value: 39, isUnsigned: true)
!89 = !DIEnumerator(name: "nvptx", value: 40, isUnsigned: true)
!90 = !DIEnumerator(name: "nvptx64", value: 41, isUnsigned: true)
!91 = !DIEnumerator(name: "le32", value: 42, isUnsigned: true)
!92 = !DIEnumerator(name: "le64", value: 43, isUnsigned: true)
!93 = !DIEnumerator(name: "amdil", value: 44, isUnsigned: true)
!94 = !DIEnumerator(name: "amdil64", value: 45, isUnsigned: true)
!95 = !DIEnumerator(name: "hsail", value: 46, isUnsigned: true)
!96 = !DIEnumerator(name: "hsail64", value: 47, isUnsigned: true)
!97 = !DIEnumerator(name: "spir", value: 48, isUnsigned: true)
!98 = !DIEnumerator(name: "spir64", value: 49, isUnsigned: true)
!99 = !DIEnumerator(name: "spirv", value: 50, isUnsigned: true)
!100 = !DIEnumerator(name: "spirv32", value: 51, isUnsigned: true)
!101 = !DIEnumerator(name: "spirv64", value: 52, isUnsigned: true)
!102 = !DIEnumerator(name: "kalimba", value: 53, isUnsigned: true)
!103 = !DIEnumerator(name: "shave", value: 54, isUnsigned: true)
!104 = !DIEnumerator(name: "lanai", value: 55, isUnsigned: true)
!105 = !DIEnumerator(name: "wasm32", value: 56, isUnsigned: true)
!106 = !DIEnumerator(name: "wasm64", value: 57, isUnsigned: true)
!107 = !DIEnumerator(name: "renderscript32", value: 58, isUnsigned: true)
!108 = !DIEnumerator(name: "renderscript64", value: 59, isUnsigned: true)
!109 = !DIEnumerator(name: "ve", value: 60, isUnsigned: true)
!110 = !DIEnumerator(name: "spu_2", value: 61, isUnsigned: true)
!111 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "builtin.OutputMode", scope: !6, file: !6, line: 645, baseType: !112, size: 8, align: 8, elements: !113)
!112 = !DIBasicType(name: "u2", size: 8, encoding: DW_ATE_unsigned)
!113 = !{!114, !115, !116}
!114 = !DIEnumerator(name: "Exe", value: 0, isUnsigned: true)
!115 = !DIEnumerator(name: "Lib", value: 1, isUnsigned: true)
!116 = !DIEnumerator(name: "Obj", value: 2, isUnsigned: true)
!117 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Target.Os.WindowsVersion", scope: !118, file: !22, line: 703, baseType: !206, size: 32, align: 32, elements: !207)
!118 = !DICompositeType(tag: DW_TAG_structure_type, name: "Target.Os", scope: !2, size: 1472, align: 64, elements: !119)
!119 = !{!120, !155}
!120 = !DIDerivedType(tag: DW_TAG_member, name: "version_range", scope: !118, baseType: !121, size: 1408, align: 64)
!121 = !DICompositeType(tag: DW_TAG_structure_type, name: "Target.Os.VersionRange", scope: !2, size: 1408, align: 64, elements: !122)
!122 = !{!123, !148}
!123 = !DIDerivedType(tag: DW_TAG_member, name: "payload", scope: !121, baseType: !124, size: 1344, align: 64)
!124 = !DICompositeType(tag: DW_TAG_union_type, name: "Target.Os.VersionRange:Payload", scope: !2, size: 1408, align: 64, elements: !125)
!125 = !{!126, !138, !143}
!126 = !DIDerivedType(tag: DW_TAG_member, name: "semver", scope: !124, baseType: !127, size: 896, align: 64)
!127 = !DICompositeType(tag: DW_TAG_structure_type, name: "SemanticVersion.Range", scope: !2, size: 896, align: 64, elements: !128)
!128 = !{!129, !137}
!129 = !DIDerivedType(tag: DW_TAG_member, name: "min", scope: !127, baseType: !130, size: 448, align: 64)
!130 = !DICompositeType(tag: DW_TAG_structure_type, name: "SemanticVersion", scope: !2, size: 448, align: 64, elements: !131)
!131 = !{!132, !133, !134, !135, !136}
!132 = !DIDerivedType(tag: DW_TAG_member, name: "major", scope: !130, baseType: !36, size: 64, align: 64)
!133 = !DIDerivedType(tag: DW_TAG_member, name: "minor", scope: !130, baseType: !36, size: 64, align: 64, offset: 64)
!134 = !DIDerivedType(tag: DW_TAG_member, name: "patch", scope: !130, baseType: !36, size: 64, align: 64, offset: 128)
!135 = !DIDerivedType(tag: DW_TAG_member, name: "pre", scope: !130, baseType: !30, size: 128, align: 64, offset: 192)
!136 = !DIDerivedType(tag: DW_TAG_member, name: "build", scope: !130, baseType: !30, size: 128, align: 64, offset: 320)
!137 = !DIDerivedType(tag: DW_TAG_member, name: "max", scope: !127, baseType: !130, size: 448, align: 64, offset: 448)
!138 = !DIDerivedType(tag: DW_TAG_member, name: "linux", scope: !124, baseType: !139, size: 1344, align: 64)
!139 = !DICompositeType(tag: DW_TAG_structure_type, name: "Target.Os.LinuxVersionRange", scope: !2, size: 1344, align: 64, elements: !140)
!140 = !{!141, !142}
!141 = !DIDerivedType(tag: DW_TAG_member, name: "range", scope: !139, baseType: !127, size: 896, align: 64)
!142 = !DIDerivedType(tag: DW_TAG_member, name: "glibc", scope: !139, baseType: !130, size: 448, align: 64, offset: 896)
!143 = !DIDerivedType(tag: DW_TAG_member, name: "windows", scope: !124, baseType: !144, size: 64, align: 32)
!144 = !DICompositeType(tag: DW_TAG_structure_type, name: "Target.Os.WindowsVersion.Range", scope: !2, size: 64, align: 32, elements: !145)
!145 = !{!146, !147}
!146 = !DIDerivedType(tag: DW_TAG_member, name: "min", scope: !144, baseType: !117, size: 32, align: 32)
!147 = !DIDerivedType(tag: DW_TAG_member, name: "max", scope: !144, baseType: !117, size: 32, align: 32, offset: 32)
!148 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !121, baseType: !149, size: 8, align: 8, offset: 1344)
!149 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "@typeInfo(Target.Os.VersionRange).Union.tag_type.?", scope: !121, file: !22, line: 979, baseType: !112, size: 8, align: 8, elements: !150)
!150 = !{!151, !152, !153, !154}
!151 = !DIEnumerator(name: "none", value: 0, isUnsigned: true)
!152 = !DIEnumerator(name: "semver", value: 1, isUnsigned: true)
!153 = !DIEnumerator(name: "linux", value: 2, isUnsigned: true)
!154 = !DIEnumerator(name: "windows", value: 3, isUnsigned: true)
!155 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !118, baseType: !156, size: 8, align: 8, offset: 1408)
!156 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Target.Os.Tag", scope: !118, file: !22, line: 428, baseType: !47, size: 8, align: 8, elements: !157)
!157 = !{!158, !159, !160, !161, !162, !163, !164, !165, !166, !167, !168, !169, !170, !171, !172, !173, !174, !175, !176, !177, !178, !179, !180, !181, !182, !183, !184, !185, !186, !187, !188, !189, !190, !191, !192, !193, !194, !195, !196, !197, !198, !199, !200, !201, !202, !203, !204, !205}
!158 = !DIEnumerator(name: "freestanding", value: 0, isUnsigned: true)
!159 = !DIEnumerator(name: "ananas", value: 1, isUnsigned: true)
!160 = !DIEnumerator(name: "cloudabi", value: 2, isUnsigned: true)
!161 = !DIEnumerator(name: "dragonfly", value: 3, isUnsigned: true)
!162 = !DIEnumerator(name: "freebsd", value: 4, isUnsigned: true)
!163 = !DIEnumerator(name: "fuchsia", value: 5, isUnsigned: true)
!164 = !DIEnumerator(name: "ios", value: 6, isUnsigned: true)
!165 = !DIEnumerator(name: "kfreebsd", value: 7, isUnsigned: true)
!166 = !DIEnumerator(name: "linux", value: 8, isUnsigned: true)
!167 = !DIEnumerator(name: "lv2", value: 9, isUnsigned: true)
!168 = !DIEnumerator(name: "macos", value: 10, isUnsigned: true)
!169 = !DIEnumerator(name: "netbsd", value: 11, isUnsigned: true)
!170 = !DIEnumerator(name: "openbsd", value: 12, isUnsigned: true)
!171 = !DIEnumerator(name: "solaris", value: 13, isUnsigned: true)
!172 = !DIEnumerator(name: "uefi", value: 14, isUnsigned: true)
!173 = !DIEnumerator(name: "windows", value: 15, isUnsigned: true)
!174 = !DIEnumerator(name: "zos", value: 16, isUnsigned: true)
!175 = !DIEnumerator(name: "haiku", value: 17, isUnsigned: true)
!176 = !DIEnumerator(name: "minix", value: 18, isUnsigned: true)
!177 = !DIEnumerator(name: "rtems", value: 19, isUnsigned: true)
!178 = !DIEnumerator(name: "nacl", value: 20, isUnsigned: true)
!179 = !DIEnumerator(name: "aix", value: 21, isUnsigned: true)
!180 = !DIEnumerator(name: "cuda", value: 22, isUnsigned: true)
!181 = !DIEnumerator(name: "nvcl", value: 23, isUnsigned: true)
!182 = !DIEnumerator(name: "amdhsa", value: 24, isUnsigned: true)
!183 = !DIEnumerator(name: "ps4", value: 25, isUnsigned: true)
!184 = !DIEnumerator(name: "ps5", value: 26, isUnsigned: true)
!185 = !DIEnumerator(name: "elfiamcu", value: 27, isUnsigned: true)
!186 = !DIEnumerator(name: "tvos", value: 28, isUnsigned: true)
!187 = !DIEnumerator(name: "watchos", value: 29, isUnsigned: true)
!188 = !DIEnumerator(name: "driverkit", value: 30, isUnsigned: true)
!189 = !DIEnumerator(name: "visionos", value: 31, isUnsigned: true)
!190 = !DIEnumerator(name: "mesa3d", value: 32, isUnsigned: true)
!191 = !DIEnumerator(name: "contiki", value: 33, isUnsigned: true)
!192 = !DIEnumerator(name: "amdpal", value: 34, isUnsigned: true)
!193 = !DIEnumerator(name: "hermit", value: 35, isUnsigned: true)
!194 = !DIEnumerator(name: "hurd", value: 36, isUnsigned: true)
!195 = !DIEnumerator(name: "wasi", value: 37, isUnsigned: true)
!196 = !DIEnumerator(name: "emscripten", value: 38, isUnsigned: true)
!197 = !DIEnumerator(name: "shadermodel", value: 39, isUnsigned: true)
!198 = !DIEnumerator(name: "liteos", value: 40, isUnsigned: true)
!199 = !DIEnumerator(name: "serenity", value: 41, isUnsigned: true)
!200 = !DIEnumerator(name: "opencl", value: 42, isUnsigned: true)
!201 = !DIEnumerator(name: "glsl450", value: 43, isUnsigned: true)
!202 = !DIEnumerator(name: "vulkan", value: 44, isUnsigned: true)
!203 = !DIEnumerator(name: "plan9", value: 45, isUnsigned: true)
!204 = !DIEnumerator(name: "illumos", value: 46, isUnsigned: true)
!205 = !DIEnumerator(name: "other", value: 47, isUnsigned: true)
!206 = !DIBasicType(name: "u32", size: 32, encoding: DW_ATE_unsigned)
!207 = !{!208, !209, !210, !211, !212, !213, !214, !215, !216, !217, !218, !219, !220, !221, !222, !223, !224, !225, !226}
!208 = !DIEnumerator(name: "nt4", value: 67108864, isUnsigned: true)
!209 = !DIEnumerator(name: "win2k", value: 83886080, isUnsigned: true)
!210 = !DIEnumerator(name: "xp", value: 83951616, isUnsigned: true)
!211 = !DIEnumerator(name: "ws2003", value: 84017152, isUnsigned: true)
!212 = !DIEnumerator(name: "vista", value: 100663296, isUnsigned: true)
!213 = !DIEnumerator(name: "win7", value: 100728832, isUnsigned: true)
!214 = !DIEnumerator(name: "win8", value: 100794368, isUnsigned: true)
!215 = !DIEnumerator(name: "win8_1", value: 100859904, isUnsigned: true)
!216 = !DIEnumerator(name: "win10", value: 167772160, isUnsigned: true)
!217 = !DIEnumerator(name: "win10_th2", value: 167772161, isUnsigned: true)
!218 = !DIEnumerator(name: "win10_rs1", value: 167772162, isUnsigned: true)
!219 = !DIEnumerator(name: "win10_rs2", value: 167772163, isUnsigned: true)
!220 = !DIEnumerator(name: "win10_rs3", value: 167772164, isUnsigned: true)
!221 = !DIEnumerator(name: "win10_rs4", value: 167772165, isUnsigned: true)
!222 = !DIEnumerator(name: "win10_rs5", value: 167772166, isUnsigned: true)
!223 = !DIEnumerator(name: "win10_19h1", value: 167772167, isUnsigned: true)
!224 = !DIEnumerator(name: "win10_vb", value: 167772168, isUnsigned: true)
!225 = !DIEnumerator(name: "win10_mn", value: 167772169, isUnsigned: true)
!226 = !DIEnumerator(name: "win10_fe", value: 167772170, isUnsigned: true)
!227 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "builtin.AtomicOrder", scope: !6, file: !6, line: 202, baseType: !228, size: 8, align: 8, elements: !229)
!228 = !DIBasicType(name: "u3", size: 8, encoding: DW_ATE_unsigned)
!229 = !{!230, !231, !232, !233, !234, !235}
!230 = !DIEnumerator(name: "unordered", value: 0, isUnsigned: true)
!231 = !DIEnumerator(name: "monotonic", value: 1, isUnsigned: true)
!232 = !DIEnumerator(name: "acquire", value: 2, isUnsigned: true)
!233 = !DIEnumerator(name: "release", value: 3, isUnsigned: true)
!234 = !DIEnumerator(name: "acq_rel", value: 4, isUnsigned: true)
!235 = !DIEnumerator(name: "seq_cst", value: 5, isUnsigned: true)
!236 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "builtin.OptimizeMode", scope: !6, file: !6, line: 262, baseType: !112, size: 8, align: 8, elements: !237)
!237 = !{!238, !239, !240, !241}
!238 = !DIEnumerator(name: "Debug", value: 0, isUnsigned: true)
!239 = !DIEnumerator(name: "ReleaseSafe", value: 1, isUnsigned: true)
!240 = !DIEnumerator(name: "ReleaseFast", value: 2, isUnsigned: true)
!241 = !DIEnumerator(name: "ReleaseSmall", value: 3, isUnsigned: true)
!242 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "log.Level", scope: !243, file: !243, line: 38, baseType: !112, size: 8, align: 8, elements: !244)
!243 = !DIFile(filename: "log.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!244 = !{!245, !246, !247, !248}
!245 = !DIEnumerator(name: "err", value: 0, isUnsigned: true)
!246 = !DIEnumerator(name: "warn", value: 1, isUnsigned: true)
!247 = !DIEnumerator(name: "info", value: 2, isUnsigned: true)
!248 = !DIEnumerator(name: "debug", value: 3, isUnsigned: true)
!249 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "crypto.SideChannelsMitigations", scope: !250, file: !250, line: 368, baseType: !112, size: 8, align: 8, elements: !251)
!250 = !DIFile(filename: "crypto.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!251 = !{!151, !252, !253, !254}
!252 = !DIEnumerator(name: "basic", value: 1, isUnsigned: true)
!253 = !DIEnumerator(name: "medium", value: 2, isUnsigned: true)
!254 = !DIEnumerator(name: "full", value: 3, isUnsigned: true)
!255 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "debug.SafetyLock.State__enum_3537", scope: !257, file: !256, line: 9113, baseType: !260, size: 8, align: 8, elements: !261)
!256 = !DIFile(filename: "debug.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!257 = !DICompositeType(tag: DW_TAG_structure_type, name: "debug.SafetyLock", scope: !2, size: 8, align: 8, elements: !258)
!258 = !{!259}
!259 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !257, baseType: !255, size: 8, align: 8)
!260 = !DIBasicType(name: "u1", size: 8, encoding: DW_ATE_unsigned)
!261 = !{!262, !263}
!262 = !DIEnumerator(name: "unlocked", value: 0, isUnsigned: true)
!263 = !DIEnumerator(name: "locked", value: 1, isUnsigned: true)
!264 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "builtin.Endian", scope: !6, file: !6, line: 631, baseType: !260, size: 8, align: 8, elements: !265)
!265 = !{!266, !267}
!266 = !DIEnumerator(name: "big", value: 0, isUnsigned: true)
!267 = !DIEnumerator(name: "little", value: 1, isUnsigned: true)
!268 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "dwarf.Format", scope: !269, file: !269, line: 275, baseType: !260, size: 8, align: 8, elements: !270)
!269 = !DIFile(filename: "dwarf.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!270 = !{!271, !272}
!271 = !DIEnumerator(name: "32", value: 0, isUnsigned: true)
!272 = !DIEnumerator(name: "64", value: 1, isUnsigned: true)
!273 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "@typeInfo(dwarf.FormValue).Union.tag_type.?", scope: !274, file: !269, line: 502, baseType: !303, size: 8, align: 8, elements: !304)
!274 = !DICompositeType(tag: DW_TAG_structure_type, name: "dwarf.FormValue", scope: !2, size: 192, align: 64, elements: !275)
!275 = !{!276, !302}
!276 = !DIDerivedType(tag: DW_TAG_member, name: "payload", scope: !274, baseType: !277, size: 128, align: 64)
!277 = !DICompositeType(tag: DW_TAG_union_type, name: "dwarf.FormValue:Payload", scope: !2, size: 192, align: 64, elements: !278)
!278 = !{!279, !280, !281, !282, !283, !288, !290, !291, !293, !294, !295, !296, !297, !298, !299, !300, !301}
!279 = !DIDerivedType(tag: DW_TAG_member, name: "addr", scope: !277, baseType: !7, size: 64, align: 64)
!280 = !DIDerivedType(tag: DW_TAG_member, name: "addrx", scope: !277, baseType: !36, size: 64, align: 64)
!281 = !DIDerivedType(tag: DW_TAG_member, name: "block", scope: !277, baseType: !30, size: 128, align: 64)
!282 = !DIDerivedType(tag: DW_TAG_member, name: "udata", scope: !277, baseType: !7, size: 64, align: 64)
!283 = !DIDerivedType(tag: DW_TAG_member, name: "data16", scope: !277, baseType: !284, size: 64, align: 64)
!284 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[16]u8", baseType: !285, size: 64, align: 8)
!285 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 128, align: 8, elements: !286)
!286 = !{!287}
!287 = !DISubrange(count: 16, lowerBound: -2384)
!288 = !DIDerivedType(tag: DW_TAG_member, name: "sdata", scope: !277, baseType: !289, size: 64, align: 64)
!289 = !DIBasicType(name: "i64", size: 64, encoding: DW_ATE_signed)
!290 = !DIDerivedType(tag: DW_TAG_member, name: "exprloc", scope: !277, baseType: !30, size: 128, align: 64)
!291 = !DIDerivedType(tag: DW_TAG_member, name: "flag", scope: !277, baseType: !292, size: 8, align: 8)
!292 = !DIBasicType(name: "bool", size: 8, encoding: DW_ATE_boolean)
!293 = !DIDerivedType(tag: DW_TAG_member, name: "sec_offset", scope: !277, baseType: !7, size: 64, align: 64)
!294 = !DIDerivedType(tag: DW_TAG_member, name: "ref", scope: !277, baseType: !7, size: 64, align: 64)
!295 = !DIDerivedType(tag: DW_TAG_member, name: "ref_addr", scope: !277, baseType: !7, size: 64, align: 64)
!296 = !DIDerivedType(tag: DW_TAG_member, name: "string", scope: !277, baseType: !30, size: 128, align: 64)
!297 = !DIDerivedType(tag: DW_TAG_member, name: "strp", scope: !277, baseType: !7, size: 64, align: 64)
!298 = !DIDerivedType(tag: DW_TAG_member, name: "strx", scope: !277, baseType: !36, size: 64, align: 64)
!299 = !DIDerivedType(tag: DW_TAG_member, name: "line_strp", scope: !277, baseType: !7, size: 64, align: 64)
!300 = !DIDerivedType(tag: DW_TAG_member, name: "loclistx", scope: !277, baseType: !7, size: 64, align: 64)
!301 = !DIDerivedType(tag: DW_TAG_member, name: "rnglistx", scope: !277, baseType: !7, size: 64, align: 64)
!302 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !274, baseType: !273, size: 8, align: 8, offset: 128)
!303 = !DIBasicType(name: "u5", size: 8, encoding: DW_ATE_unsigned)
!304 = !{!305, !306, !307, !308, !309, !310, !311, !312, !313, !314, !315, !316, !317, !318, !319, !320, !321}
!305 = !DIEnumerator(name: "addr", value: 0, isUnsigned: true)
!306 = !DIEnumerator(name: "addrx", value: 1, isUnsigned: true)
!307 = !DIEnumerator(name: "block", value: 2, isUnsigned: true)
!308 = !DIEnumerator(name: "udata", value: 3, isUnsigned: true)
!309 = !DIEnumerator(name: "data16", value: 4, isUnsigned: true)
!310 = !DIEnumerator(name: "sdata", value: 5, isUnsigned: true)
!311 = !DIEnumerator(name: "exprloc", value: 6, isUnsigned: true)
!312 = !DIEnumerator(name: "flag", value: 7, isUnsigned: true)
!313 = !DIEnumerator(name: "sec_offset", value: 8, isUnsigned: true)
!314 = !DIEnumerator(name: "ref", value: 9, isUnsigned: true)
!315 = !DIEnumerator(name: "ref_addr", value: 10, isUnsigned: true)
!316 = !DIEnumerator(name: "string", value: 11, isUnsigned: true)
!317 = !DIEnumerator(name: "strp", value: 12, isUnsigned: true)
!318 = !DIEnumerator(name: "strx", value: 13, isUnsigned: true)
!319 = !DIEnumerator(name: "line_strp", value: 14, isUnsigned: true)
!320 = !DIEnumerator(name: "loclistx", value: 15, isUnsigned: true)
!321 = !DIEnumerator(name: "rnglistx", value: 16, isUnsigned: true)
!322 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "dwarf.DwarfSection", scope: !269, file: !269, line: 1626, baseType: !323, size: 8, align: 8, elements: !324)
!323 = !DIBasicType(name: "u4", size: 8, encoding: DW_ATE_unsigned)
!324 = !{!325, !326, !327, !328, !329, !330, !331, !332, !333, !334, !335, !336, !337, !338}
!325 = !DIEnumerator(name: "debug_info", value: 0, isUnsigned: true)
!326 = !DIEnumerator(name: "debug_abbrev", value: 1, isUnsigned: true)
!327 = !DIEnumerator(name: "debug_str", value: 2, isUnsigned: true)
!328 = !DIEnumerator(name: "debug_str_offsets", value: 3, isUnsigned: true)
!329 = !DIEnumerator(name: "debug_line", value: 4, isUnsigned: true)
!330 = !DIEnumerator(name: "debug_line_str", value: 5, isUnsigned: true)
!331 = !DIEnumerator(name: "debug_ranges", value: 6, isUnsigned: true)
!332 = !DIEnumerator(name: "debug_loclists", value: 7, isUnsigned: true)
!333 = !DIEnumerator(name: "debug_rnglists", value: 8, isUnsigned: true)
!334 = !DIEnumerator(name: "debug_addr", value: 9, isUnsigned: true)
!335 = !DIEnumerator(name: "debug_names", value: 10, isUnsigned: true)
!336 = !DIEnumerator(name: "debug_frame", value: 11, isUnsigned: true)
!337 = !DIEnumerator(name: "eh_frame", value: 12, isUnsigned: true)
!338 = !DIEnumerator(name: "eh_frame_hdr", value: 13, isUnsigned: true)
!339 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "elf.ET", scope: !340, file: !340, line: 686, baseType: !341, size: 16, align: 16, elements: !342)
!340 = !DIFile(filename: "elf.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!341 = !DIBasicType(name: "u16", size: 16, encoding: DW_ATE_unsigned)
!342 = !{!343, !344, !345, !346, !347}
!343 = !DIEnumerator(name: "NONE", value: 0, isUnsigned: true)
!344 = !DIEnumerator(name: "REL", value: 1, isUnsigned: true)
!345 = !DIEnumerator(name: "EXEC", value: 2, isUnsigned: true)
!346 = !DIEnumerator(name: "DYN", value: 3, isUnsigned: true)
!347 = !DIEnumerator(name: "CORE", value: 4, isUnsigned: true)
!348 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "elf.EM", scope: !340, file: !340, line: 2795, baseType: !341, size: 16, align: 16, elements: !349)
!349 = !{!343, !350, !351, !352, !353, !354, !355, !356, !357, !358, !359, !360, !361, !362, !363, !364, !365, !366, !367, !368, !369, !370, !371, !372, !373, !374, !375, !376, !377, !378, !379, !380, !381, !382, !383, !384, !385, !386, !387, !388, !389, !390, !391, !392, !393, !394, !395, !396, !397, !398, !399, !400, !401, !402, !403, !404, !405, !406, !407, !408, !409, !410, !411, !412, !413, !414, !415, !416, !417, !418, !419, !420, !421, !422, !423, !424, !425, !426, !427, !428, !429, !430, !431, !432, !433, !434, !435, !436, !437, !438, !439, !440, !441, !442, !443, !444, !445, !446, !447, !448, !449, !450, !451, !452, !453, !454, !455, !456, !457, !458, !459, !460, !461, !462, !463, !464, !465, !466, !467, !468, !469, !470, !471, !472, !473, !474, !475, !476, !477, !478, !479, !480, !481, !482, !483, !484, !485, !486, !487, !488, !489, !490, !491, !492, !493, !494, !495, !496, !497, !498, !499, !500, !501, !502, !503, !504, !505, !506, !507, !508, !509, !510, !511, !512, !513, !514, !515, !516, !517, !518, !519, !520, !521, !522, !523, !524, !525, !526, !527, !528}
!350 = !DIEnumerator(name: "M32", value: 1, isUnsigned: true)
!351 = !DIEnumerator(name: "SPARC", value: 2, isUnsigned: true)
!352 = !DIEnumerator(name: "386", value: 3, isUnsigned: true)
!353 = !DIEnumerator(name: "68K", value: 4, isUnsigned: true)
!354 = !DIEnumerator(name: "88K", value: 5, isUnsigned: true)
!355 = !DIEnumerator(name: "IAMCU", value: 6, isUnsigned: true)
!356 = !DIEnumerator(name: "860", value: 7, isUnsigned: true)
!357 = !DIEnumerator(name: "MIPS", value: 8, isUnsigned: true)
!358 = !DIEnumerator(name: "S370", value: 9, isUnsigned: true)
!359 = !DIEnumerator(name: "MIPS_RS3_LE", value: 10, isUnsigned: true)
!360 = !DIEnumerator(name: "SPU_2", value: 13, isUnsigned: true)
!361 = !DIEnumerator(name: "PARISC", value: 15, isUnsigned: true)
!362 = !DIEnumerator(name: "VPP500", value: 17, isUnsigned: true)
!363 = !DIEnumerator(name: "SPARC32PLUS", value: 18, isUnsigned: true)
!364 = !DIEnumerator(name: "960", value: 19, isUnsigned: true)
!365 = !DIEnumerator(name: "PPC", value: 20, isUnsigned: true)
!366 = !DIEnumerator(name: "PPC64", value: 21, isUnsigned: true)
!367 = !DIEnumerator(name: "S390", value: 22, isUnsigned: true)
!368 = !DIEnumerator(name: "SPU", value: 23, isUnsigned: true)
!369 = !DIEnumerator(name: "V800", value: 36, isUnsigned: true)
!370 = !DIEnumerator(name: "FR20", value: 37, isUnsigned: true)
!371 = !DIEnumerator(name: "RH32", value: 38, isUnsigned: true)
!372 = !DIEnumerator(name: "RCE", value: 39, isUnsigned: true)
!373 = !DIEnumerator(name: "ARM", value: 40, isUnsigned: true)
!374 = !DIEnumerator(name: "ALPHA", value: 41, isUnsigned: true)
!375 = !DIEnumerator(name: "SH", value: 42, isUnsigned: true)
!376 = !DIEnumerator(name: "SPARCV9", value: 43, isUnsigned: true)
!377 = !DIEnumerator(name: "TRICORE", value: 44, isUnsigned: true)
!378 = !DIEnumerator(name: "ARC", value: 45, isUnsigned: true)
!379 = !DIEnumerator(name: "H8_300", value: 46, isUnsigned: true)
!380 = !DIEnumerator(name: "H8_300H", value: 47, isUnsigned: true)
!381 = !DIEnumerator(name: "H8S", value: 48, isUnsigned: true)
!382 = !DIEnumerator(name: "H8_500", value: 49, isUnsigned: true)
!383 = !DIEnumerator(name: "IA_64", value: 50, isUnsigned: true)
!384 = !DIEnumerator(name: "MIPS_X", value: 51, isUnsigned: true)
!385 = !DIEnumerator(name: "COLDFIRE", value: 52, isUnsigned: true)
!386 = !DIEnumerator(name: "68HC12", value: 53, isUnsigned: true)
!387 = !DIEnumerator(name: "MMA", value: 54, isUnsigned: true)
!388 = !DIEnumerator(name: "PCP", value: 55, isUnsigned: true)
!389 = !DIEnumerator(name: "NCPU", value: 56, isUnsigned: true)
!390 = !DIEnumerator(name: "NDR1", value: 57, isUnsigned: true)
!391 = !DIEnumerator(name: "STARCORE", value: 58, isUnsigned: true)
!392 = !DIEnumerator(name: "ME16", value: 59, isUnsigned: true)
!393 = !DIEnumerator(name: "ST100", value: 60, isUnsigned: true)
!394 = !DIEnumerator(name: "TINYJ", value: 61, isUnsigned: true)
!395 = !DIEnumerator(name: "X86_64", value: 62, isUnsigned: true)
!396 = !DIEnumerator(name: "PDSP", value: 63, isUnsigned: true)
!397 = !DIEnumerator(name: "PDP10", value: 64, isUnsigned: true)
!398 = !DIEnumerator(name: "PDP11", value: 65, isUnsigned: true)
!399 = !DIEnumerator(name: "FX66", value: 66, isUnsigned: true)
!400 = !DIEnumerator(name: "ST9PLUS", value: 67, isUnsigned: true)
!401 = !DIEnumerator(name: "ST7", value: 68, isUnsigned: true)
!402 = !DIEnumerator(name: "68HC16", value: 69, isUnsigned: true)
!403 = !DIEnumerator(name: "68HC11", value: 70, isUnsigned: true)
!404 = !DIEnumerator(name: "68HC08", value: 71, isUnsigned: true)
!405 = !DIEnumerator(name: "68HC05", value: 72, isUnsigned: true)
!406 = !DIEnumerator(name: "SVX", value: 73, isUnsigned: true)
!407 = !DIEnumerator(name: "ST19", value: 74, isUnsigned: true)
!408 = !DIEnumerator(name: "VAX", value: 75, isUnsigned: true)
!409 = !DIEnumerator(name: "CRIS", value: 76, isUnsigned: true)
!410 = !DIEnumerator(name: "JAVELIN", value: 77, isUnsigned: true)
!411 = !DIEnumerator(name: "FIREPATH", value: 78, isUnsigned: true)
!412 = !DIEnumerator(name: "ZSP", value: 79, isUnsigned: true)
!413 = !DIEnumerator(name: "MMIX", value: 80, isUnsigned: true)
!414 = !DIEnumerator(name: "HUANY", value: 81, isUnsigned: true)
!415 = !DIEnumerator(name: "PRISM", value: 82, isUnsigned: true)
!416 = !DIEnumerator(name: "AVR", value: 83, isUnsigned: true)
!417 = !DIEnumerator(name: "FR30", value: 84, isUnsigned: true)
!418 = !DIEnumerator(name: "D10V", value: 85, isUnsigned: true)
!419 = !DIEnumerator(name: "D30V", value: 86, isUnsigned: true)
!420 = !DIEnumerator(name: "V850", value: 87, isUnsigned: true)
!421 = !DIEnumerator(name: "M32R", value: 88, isUnsigned: true)
!422 = !DIEnumerator(name: "MN10300", value: 89, isUnsigned: true)
!423 = !DIEnumerator(name: "MN10200", value: 90, isUnsigned: true)
!424 = !DIEnumerator(name: "PJ", value: 91, isUnsigned: true)
!425 = !DIEnumerator(name: "OPENRISC", value: 92, isUnsigned: true)
!426 = !DIEnumerator(name: "ARC_COMPACT", value: 93, isUnsigned: true)
!427 = !DIEnumerator(name: "XTENSA", value: 94, isUnsigned: true)
!428 = !DIEnumerator(name: "VIDEOCORE", value: 95, isUnsigned: true)
!429 = !DIEnumerator(name: "TMM_GPP", value: 96, isUnsigned: true)
!430 = !DIEnumerator(name: "NS32K", value: 97, isUnsigned: true)
!431 = !DIEnumerator(name: "TPC", value: 98, isUnsigned: true)
!432 = !DIEnumerator(name: "SNP1K", value: 99, isUnsigned: true)
!433 = !DIEnumerator(name: "ST200", value: 100, isUnsigned: true)
!434 = !DIEnumerator(name: "IP2K", value: 101, isUnsigned: true)
!435 = !DIEnumerator(name: "MAX", value: 102, isUnsigned: true)
!436 = !DIEnumerator(name: "CR", value: 103, isUnsigned: true)
!437 = !DIEnumerator(name: "F2MC16", value: 104, isUnsigned: true)
!438 = !DIEnumerator(name: "MSP430", value: 105, isUnsigned: true)
!439 = !DIEnumerator(name: "BLACKFIN", value: 106, isUnsigned: true)
!440 = !DIEnumerator(name: "SE_C33", value: 107, isUnsigned: true)
!441 = !DIEnumerator(name: "SEP", value: 108, isUnsigned: true)
!442 = !DIEnumerator(name: "ARCA", value: 109, isUnsigned: true)
!443 = !DIEnumerator(name: "UNICORE", value: 110, isUnsigned: true)
!444 = !DIEnumerator(name: "EXCESS", value: 111, isUnsigned: true)
!445 = !DIEnumerator(name: "DXP", value: 112, isUnsigned: true)
!446 = !DIEnumerator(name: "ALTERA_NIOS2", value: 113, isUnsigned: true)
!447 = !DIEnumerator(name: "CRX", value: 114, isUnsigned: true)
!448 = !DIEnumerator(name: "XGATE", value: 115, isUnsigned: true)
!449 = !DIEnumerator(name: "C166", value: 116, isUnsigned: true)
!450 = !DIEnumerator(name: "M16C", value: 117, isUnsigned: true)
!451 = !DIEnumerator(name: "DSPIC30F", value: 118, isUnsigned: true)
!452 = !DIEnumerator(name: "CE", value: 119, isUnsigned: true)
!453 = !DIEnumerator(name: "M32C", value: 120, isUnsigned: true)
!454 = !DIEnumerator(name: "TSK3000", value: 131, isUnsigned: true)
!455 = !DIEnumerator(name: "RS08", value: 132, isUnsigned: true)
!456 = !DIEnumerator(name: "SHARC", value: 133, isUnsigned: true)
!457 = !DIEnumerator(name: "ECOG2", value: 134, isUnsigned: true)
!458 = !DIEnumerator(name: "SCORE7", value: 135, isUnsigned: true)
!459 = !DIEnumerator(name: "DSP24", value: 136, isUnsigned: true)
!460 = !DIEnumerator(name: "VIDEOCORE3", value: 137, isUnsigned: true)
!461 = !DIEnumerator(name: "LATTICEMICO32", value: 138, isUnsigned: true)
!462 = !DIEnumerator(name: "SE_C17", value: 139, isUnsigned: true)
!463 = !DIEnumerator(name: "TI_C6000", value: 140, isUnsigned: true)
!464 = !DIEnumerator(name: "TI_C2000", value: 141, isUnsigned: true)
!465 = !DIEnumerator(name: "TI_C5500", value: 142, isUnsigned: true)
!466 = !DIEnumerator(name: "MMDSP_PLUS", value: 160, isUnsigned: true)
!467 = !DIEnumerator(name: "CYPRESS_M8C", value: 161, isUnsigned: true)
!468 = !DIEnumerator(name: "R32C", value: 162, isUnsigned: true)
!469 = !DIEnumerator(name: "TRIMEDIA", value: 163, isUnsigned: true)
!470 = !DIEnumerator(name: "HEXAGON", value: 164, isUnsigned: true)
!471 = !DIEnumerator(name: "8051", value: 165, isUnsigned: true)
!472 = !DIEnumerator(name: "STXP7X", value: 166, isUnsigned: true)
!473 = !DIEnumerator(name: "NDS32", value: 167, isUnsigned: true)
!474 = !DIEnumerator(name: "ECOG1X", value: 168, isUnsigned: true)
!475 = !DIEnumerator(name: "MAXQ30", value: 169, isUnsigned: true)
!476 = !DIEnumerator(name: "XIMO16", value: 170, isUnsigned: true)
!477 = !DIEnumerator(name: "MANIK", value: 171, isUnsigned: true)
!478 = !DIEnumerator(name: "CRAYNV2", value: 172, isUnsigned: true)
!479 = !DIEnumerator(name: "RX", value: 173, isUnsigned: true)
!480 = !DIEnumerator(name: "METAG", value: 174, isUnsigned: true)
!481 = !DIEnumerator(name: "MCST_ELBRUS", value: 175, isUnsigned: true)
!482 = !DIEnumerator(name: "ECOG16", value: 176, isUnsigned: true)
!483 = !DIEnumerator(name: "CR16", value: 177, isUnsigned: true)
!484 = !DIEnumerator(name: "ETPU", value: 178, isUnsigned: true)
!485 = !DIEnumerator(name: "SLE9X", value: 179, isUnsigned: true)
!486 = !DIEnumerator(name: "L10M", value: 180, isUnsigned: true)
!487 = !DIEnumerator(name: "K10M", value: 181, isUnsigned: true)
!488 = !DIEnumerator(name: "AARCH64", value: 183, isUnsigned: true)
!489 = !DIEnumerator(name: "AVR32", value: 185, isUnsigned: true)
!490 = !DIEnumerator(name: "STM8", value: 186, isUnsigned: true)
!491 = !DIEnumerator(name: "TILE64", value: 187, isUnsigned: true)
!492 = !DIEnumerator(name: "TILEPRO", value: 188, isUnsigned: true)
!493 = !DIEnumerator(name: "CUDA", value: 190, isUnsigned: true)
!494 = !DIEnumerator(name: "TILEGX", value: 191, isUnsigned: true)
!495 = !DIEnumerator(name: "CLOUDSHIELD", value: 192, isUnsigned: true)
!496 = !DIEnumerator(name: "COREA_1ST", value: 193, isUnsigned: true)
!497 = !DIEnumerator(name: "COREA_2ND", value: 194, isUnsigned: true)
!498 = !DIEnumerator(name: "ARC_COMPACT2", value: 195, isUnsigned: true)
!499 = !DIEnumerator(name: "OPEN8", value: 196, isUnsigned: true)
!500 = !DIEnumerator(name: "RL78", value: 197, isUnsigned: true)
!501 = !DIEnumerator(name: "VIDEOCORE5", value: 198, isUnsigned: true)
!502 = !DIEnumerator(name: "78KOR", value: 199, isUnsigned: true)
!503 = !DIEnumerator(name: "56800EX", value: 200, isUnsigned: true)
!504 = !DIEnumerator(name: "BA1", value: 201, isUnsigned: true)
!505 = !DIEnumerator(name: "BA2", value: 202, isUnsigned: true)
!506 = !DIEnumerator(name: "XCORE", value: 203, isUnsigned: true)
!507 = !DIEnumerator(name: "MCHP_PIC", value: 204, isUnsigned: true)
!508 = !DIEnumerator(name: "INTEL205", value: 205, isUnsigned: true)
!509 = !DIEnumerator(name: "INTEL206", value: 206, isUnsigned: true)
!510 = !DIEnumerator(name: "INTEL207", value: 207, isUnsigned: true)
!511 = !DIEnumerator(name: "INTEL208", value: 208, isUnsigned: true)
!512 = !DIEnumerator(name: "INTEL209", value: 209, isUnsigned: true)
!513 = !DIEnumerator(name: "KM32", value: 210, isUnsigned: true)
!514 = !DIEnumerator(name: "KMX32", value: 211, isUnsigned: true)
!515 = !DIEnumerator(name: "KMX16", value: 212, isUnsigned: true)
!516 = !DIEnumerator(name: "KMX8", value: 213, isUnsigned: true)
!517 = !DIEnumerator(name: "KVARC", value: 214, isUnsigned: true)
!518 = !DIEnumerator(name: "CDP", value: 215, isUnsigned: true)
!519 = !DIEnumerator(name: "COGE", value: 216, isUnsigned: true)
!520 = !DIEnumerator(name: "COOL", value: 217, isUnsigned: true)
!521 = !DIEnumerator(name: "NORC", value: 218, isUnsigned: true)
!522 = !DIEnumerator(name: "CSR_KALIMBA", value: 219, isUnsigned: true)
!523 = !DIEnumerator(name: "AMDGPU", value: 224, isUnsigned: true)
!524 = !DIEnumerator(name: "RISCV", value: 243, isUnsigned: true)
!525 = !DIEnumerator(name: "LANAI", value: 244, isUnsigned: true)
!526 = !DIEnumerator(name: "BPF", value: 247, isUnsigned: true)
!527 = !DIEnumerator(name: "CSKY", value: 252, isUnsigned: true)
!528 = !DIEnumerator(name: "FRV", value: 21569, isUnsigned: true)
!529 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "elf.COMPRESS", scope: !340, file: !340, line: 2902, baseType: !206, size: 32, align: 32, elements: !530)
!530 = !{!531, !532, !533, !534, !535, !536}
!531 = !DIEnumerator(name: "ZLIB", value: 1, isUnsigned: true)
!532 = !DIEnumerator(name: "ZSTD", value: 2, isUnsigned: true)
!533 = !DIEnumerator(name: "LOOS", value: 1610612736, isUnsigned: true)
!534 = !DIEnumerator(name: "HIOS", value: 1879048191, isUnsigned: true)
!535 = !DIEnumerator(name: "LOPROC", value: 1879048192, isUnsigned: true)
!536 = !DIEnumerator(name: "HIPROC", value: 2147483647, isUnsigned: true)
!537 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "compress.flate.inflate.Inflate(.zlib,u32,io.GenericReader(*io.fixed_buffer_stream.FixedBufferStream([]const u8),error{},(function 'read'))).ReadState", scope: !539, file: !538, line: 149, baseType: !228, size: 8, align: 8, elements: !595)
!538 = !DIFile(filename: "inflate.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/compress/flate")
!539 = !DICompositeType(tag: DW_TAG_structure_type, name: "compress.flate.inflate.Inflate(.zlib,u32,io.GenericReader(*io.fixed_buffer_stream.FixedBufferStream([]const u8),error{},(function 'read')))", scope: !2, size: 610496, align: 64, elements: !540)
!540 = !{!541, !555, !564, !572, !584, !592, !593, !594}
!541 = !DIDerivedType(tag: DW_TAG_member, name: "bits", scope: !539, baseType: !542, size: 128, align: 64)
!542 = !DICompositeType(tag: DW_TAG_structure_type, name: "compress.flate.bit_reader.BitReader(u32,io.GenericReader(*io.fixed_buffer_stream.FixedBufferStream([]const u8),error{},(function 'read')))", scope: !2, size: 128, align: 64, elements: !543)
!543 = !{!544, !553, !554}
!544 = !DIDerivedType(tag: DW_TAG_member, name: "forward_reader", scope: !542, baseType: !545, size: 64, align: 64)
!545 = !DICompositeType(tag: DW_TAG_structure_type, name: "io.GenericReader(*io.fixed_buffer_stream.FixedBufferStream([]const u8),error{},(function 'read'))", scope: !2, size: 64, align: 64, elements: !546)
!546 = !{!547}
!547 = !DIDerivedType(tag: DW_TAG_member, name: "context", scope: !545, baseType: !548, size: 64, align: 64)
!548 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*io.fixed_buffer_stream.FixedBufferStream([]const u8)", baseType: !549, size: 64, align: 64)
!549 = !DICompositeType(tag: DW_TAG_structure_type, name: "io.fixed_buffer_stream.FixedBufferStream([]const u8)", scope: !2, size: 192, align: 64, elements: !550)
!550 = !{!551, !552}
!551 = !DIDerivedType(tag: DW_TAG_member, name: "buffer", scope: !549, baseType: !30, size: 128, align: 64)
!552 = !DIDerivedType(tag: DW_TAG_member, name: "pos", scope: !549, baseType: !36, size: 64, align: 64, offset: 128)
!553 = !DIDerivedType(tag: DW_TAG_member, name: "bits", scope: !542, baseType: !206, size: 32, align: 32, offset: 64)
!554 = !DIDerivedType(tag: DW_TAG_member, name: "nbits", scope: !542, baseType: !206, size: 32, align: 32, offset: 96)
!555 = !DIDerivedType(tag: DW_TAG_member, name: "hist", scope: !539, baseType: !556, size: 524416, align: 64, offset: 128)
!556 = !DICompositeType(tag: DW_TAG_structure_type, name: "compress.flate.CircularBuffer", scope: !2, size: 524416, align: 64, elements: !557)
!557 = !{!558, !559, !560}
!558 = !DIDerivedType(tag: DW_TAG_member, name: "wp", scope: !556, baseType: !36, size: 64, align: 64)
!559 = !DIDerivedType(tag: DW_TAG_member, name: "rp", scope: !556, baseType: !36, size: 64, align: 64, offset: 64)
!560 = !DIDerivedType(tag: DW_TAG_member, name: "buffer", scope: !556, baseType: !561, size: 524288, align: 8, offset: 128)
!561 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 524288, align: 8, elements: !562)
!562 = !{!563}
!563 = !DISubrange(count: 65536, lowerBound: -2384)
!564 = !DIDerivedType(tag: DW_TAG_member, name: "hasher", scope: !539, baseType: !565, size: 128, align: 64, offset: 524544)
!565 = !DICompositeType(tag: DW_TAG_structure_type, name: "compress.flate.container.Container.Hasher(.zlib)", scope: !2, size: 128, align: 64, elements: !566)
!566 = !{!567, !568}
!567 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !565, baseType: !36, size: 64, align: 64)
!568 = !DIDerivedType(tag: DW_TAG_member, name: "hasher", scope: !565, baseType: !569, size: 32, align: 32, offset: 64)
!569 = !DICompositeType(tag: DW_TAG_structure_type, name: "hash.adler.Adler32", scope: !2, size: 32, align: 32, elements: !570)
!570 = !{!571}
!571 = !DIDerivedType(tag: DW_TAG_member, name: "adler", scope: !569, baseType: !206, size: 32, align: 32)
!572 = !DIDerivedType(tag: DW_TAG_member, name: "lit_dec", scope: !539, baseType: !573, size: 51072, align: 64, offset: 524672)
!573 = !DICompositeType(tag: DW_TAG_structure_type, name: "compress.flate.huffman_decoder.HuffmanDecoder(286,15,9)", scope: !2, size: 51072, align: 64, elements: !574)
!574 = !{!575, !580}
!575 = !DIDerivedType(tag: DW_TAG_member, name: "symbols", scope: !573, baseType: !576, size: 18304, align: 64)
!576 = !DICompositeType(tag: DW_TAG_array_type, baseType: !577, size: 18304, align: 64, elements: !578)
!577 = !DIBasicType(name: "compress.flate.huffman_decoder.Symbol", size: 64, encoding: DW_ATE_unsigned)
!578 = !{!579}
!579 = !DISubrange(count: 286, lowerBound: -2384)
!580 = !DIDerivedType(tag: DW_TAG_member, name: "lookup", scope: !573, baseType: !581, size: 32768, align: 64, offset: 18304)
!581 = !DICompositeType(tag: DW_TAG_array_type, baseType: !577, size: 32768, align: 64, elements: !582)
!582 = !{!583}
!583 = !DISubrange(count: 512, lowerBound: -2384)
!584 = !DIDerivedType(tag: DW_TAG_member, name: "dst_dec", scope: !539, baseType: !585, size: 34688, align: 64, offset: 575744)
!585 = !DICompositeType(tag: DW_TAG_structure_type, name: "compress.flate.huffman_decoder.HuffmanDecoder(30,15,9)", scope: !2, size: 34688, align: 64, elements: !586)
!586 = !{!587, !591}
!587 = !DIDerivedType(tag: DW_TAG_member, name: "symbols", scope: !585, baseType: !588, size: 1920, align: 64)
!588 = !DICompositeType(tag: DW_TAG_array_type, baseType: !577, size: 1920, align: 64, elements: !589)
!589 = !{!590}
!590 = !DISubrange(count: 30, lowerBound: -2384)
!591 = !DIDerivedType(tag: DW_TAG_member, name: "lookup", scope: !585, baseType: !581, size: 32768, align: 64, offset: 1920)
!592 = !DIDerivedType(tag: DW_TAG_member, name: "bfinal", scope: !539, baseType: !260, size: 8, align: 8, offset: 610432)
!593 = !DIDerivedType(tag: DW_TAG_member, name: "block_type", scope: !539, baseType: !112, size: 8, align: 8, offset: 610440)
!594 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !539, baseType: !537, size: 8, align: 8, offset: 610448)
!595 = !{!596, !597, !598, !599, !600}
!596 = !DIEnumerator(name: "protocol_header", value: 0, isUnsigned: true)
!597 = !DIEnumerator(name: "block_header", value: 1, isUnsigned: true)
!598 = !DIEnumerator(name: "block", value: 2, isUnsigned: true)
!599 = !DIEnumerator(name: "protocol_footer", value: 3, isUnsigned: true)
!600 = !DIEnumerator(name: "end", value: 4, isUnsigned: true)
!601 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "@typeInfo(dwarf.readEhPointer__union_6084).Union.tag_type.?", scope: !602, file: !269, line: 7390, baseType: !260, size: 8, align: 8, elements: !610)
!602 = !DICompositeType(tag: DW_TAG_structure_type, name: "dwarf.readEhPointer__union_6084", scope: !2, size: 128, align: 64, elements: !603)
!603 = !{!604, !609}
!604 = !DIDerivedType(tag: DW_TAG_member, name: "payload", scope: !602, baseType: !605, size: 64, align: 64)
!605 = !DICompositeType(tag: DW_TAG_union_type, name: "dwarf.readEhPointer__union_6084:Payload", scope: !2, size: 128, align: 64, elements: !606)
!606 = !{!607, !608}
!607 = !DIDerivedType(tag: DW_TAG_member, name: "signed", scope: !605, baseType: !289, size: 64, align: 64)
!608 = !DIDerivedType(tag: DW_TAG_member, name: "unsigned", scope: !605, baseType: !7, size: 64, align: 64)
!609 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !602, baseType: !601, size: 8, align: 8, offset: 64)
!610 = !{!611, !612}
!611 = !DIEnumerator(name: "signed", value: 0, isUnsigned: true)
!612 = !DIEnumerator(name: "unsigned", value: 1, isUnsigned: true)
!613 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "@typeInfo(dwarf.EntryHeader.EntryHeader__union_6095).Union.tag_type.?", scope: !614, file: !269, line: 8090, baseType: !112, size: 8, align: 8, elements: !621)
!614 = !DICompositeType(tag: DW_TAG_structure_type, name: "dwarf.EntryHeader.EntryHeader__union_6095", scope: !2, size: 128, align: 64, elements: !615)
!615 = !{!616, !620}
!616 = !DIDerivedType(tag: DW_TAG_member, name: "payload", scope: !614, baseType: !617, size: 64, align: 64)
!617 = !DICompositeType(tag: DW_TAG_union_type, name: "dwarf.EntryHeader.EntryHeader__union_6095:Payload", scope: !2, size: 128, align: 64, elements: !618)
!618 = !{!619}
!619 = !DIDerivedType(tag: DW_TAG_member, name: "fde", scope: !617, baseType: !7, size: 64, align: 64)
!620 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !614, baseType: !613, size: 8, align: 8, offset: 64)
!621 = !{!622, !623, !624}
!622 = !DIEnumerator(name: "cie", value: 0, isUnsigned: true)
!623 = !DIEnumerator(name: "fde", value: 1, isUnsigned: true)
!624 = !DIEnumerator(name: "terminator", value: 2, isUnsigned: true)
!625 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "meta.FieldEnum(array_hash_map.ArrayHashMapUnmanaged(u64,dwarf.CommonInformationEntry,array_hash_map.AutoContext(u64),false).Data)", scope: !626, file: !626, line: 1985, baseType: !112, size: 8, align: 8, elements: !627)
!626 = !DIFile(filename: "meta.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!627 = !{!628, !629, !630}
!628 = !DIEnumerator(name: "hash", value: 0, isUnsigned: true)
!629 = !DIEnumerator(name: "key", value: 1, isUnsigned: true)
!630 = !DIEnumerator(name: "value", value: 2, isUnsigned: true)
!631 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "@typeInfo(io.tty.Config).Union.tag_type.?", scope: !633, file: !632, line: 404, baseType: !112, size: 8, align: 8, elements: !635)
!632 = !DIFile(filename: "tty.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/io")
!633 = !DICompositeType(tag: DW_TAG_structure_type, name: "io.tty.Config", scope: !2, size: 8, align: 8, elements: !634)
!634 = !{!631}
!635 = !{!636, !637, !638}
!636 = !DIEnumerator(name: "no_color", value: 0, isUnsigned: true)
!637 = !DIEnumerator(name: "escape_codes", value: 1, isUnsigned: true)
!638 = !DIEnumerator(name: "windows_api", value: 2, isUnsigned: true)
!639 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "@typeInfo(dwarf.call_frame.VirtualMachine.RegisterRule).Union.tag_type.?", scope: !641, file: !640, line: 755, baseType: !323, size: 8, align: 8, elements: !652)
!640 = !DIFile(filename: "call_frame.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/dwarf")
!641 = !DICompositeType(tag: DW_TAG_structure_type, name: "dwarf.call_frame.VirtualMachine.RegisterRule", scope: !2, size: 192, align: 64, elements: !642)
!642 = !{!643, !651}
!643 = !DIDerivedType(tag: DW_TAG_member, name: "payload", scope: !641, baseType: !644, size: 128, align: 64)
!644 = !DICompositeType(tag: DW_TAG_union_type, name: "dwarf.call_frame.VirtualMachine.RegisterRule:Payload", scope: !2, size: 192, align: 64, elements: !645)
!645 = !{!646, !647, !648, !649, !650}
!646 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !644, baseType: !289, size: 64, align: 64)
!647 = !DIDerivedType(tag: DW_TAG_member, name: "val_offset", scope: !644, baseType: !289, size: 64, align: 64)
!648 = !DIDerivedType(tag: DW_TAG_member, name: "register", scope: !644, baseType: !34, size: 8, align: 8)
!649 = !DIDerivedType(tag: DW_TAG_member, name: "expression", scope: !644, baseType: !30, size: 128, align: 64)
!650 = !DIDerivedType(tag: DW_TAG_member, name: "val_expression", scope: !644, baseType: !30, size: 128, align: 64)
!651 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !641, baseType: !639, size: 8, align: 8, offset: 128)
!652 = !{!653, !654, !655, !656, !657, !658, !659, !660, !661}
!653 = !DIEnumerator(name: "default", value: 0, isUnsigned: true)
!654 = !DIEnumerator(name: "undefined", value: 1, isUnsigned: true)
!655 = !DIEnumerator(name: "same_value", value: 2, isUnsigned: true)
!656 = !DIEnumerator(name: "offset", value: 3, isUnsigned: true)
!657 = !DIEnumerator(name: "val_offset", value: 4, isUnsigned: true)
!658 = !DIEnumerator(name: "register", value: 5, isUnsigned: true)
!659 = !DIEnumerator(name: "expression", value: 6, isUnsigned: true)
!660 = !DIEnumerator(name: "val_expression", value: 7, isUnsigned: true)
!661 = !DIEnumerator(name: "architectural", value: 8, isUnsigned: true)
!662 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "@typeInfo(dwarf.expressions.StackMachine(.{ .addr_size = 8, .endian = .little, .call_frame_context = true }).Value).Union.tag_type.?", scope: !664, file: !663, line: 297, baseType: !112, size: 8, align: 8, elements: !682)
!663 = !DIFile(filename: "expressions.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/dwarf")
!664 = !DICompositeType(tag: DW_TAG_structure_type, name: "dwarf.expressions.StackMachine(.{ .addr_size = 8, .endian = .little, .call_frame_context = true }).Value", scope: !2, size: 256, align: 64, elements: !665)
!665 = !{!666, !681}
!666 = !DIDerivedType(tag: DW_TAG_member, name: "payload", scope: !664, baseType: !667, size: 192, align: 64)
!667 = !DICompositeType(tag: DW_TAG_union_type, name: "dwarf.expressions.StackMachine(.{ .addr_size = 8, .endian = .little, .call_frame_context = true }).Value:Payload", scope: !2, size: 256, align: 64, elements: !668)
!668 = !{!669, !670, !676}
!669 = !DIDerivedType(tag: DW_TAG_member, name: "generic", scope: !667, baseType: !7, size: 64, align: 64)
!670 = !DIDerivedType(tag: DW_TAG_member, name: "regval_type", scope: !667, baseType: !671, size: 192, align: 64)
!671 = !DICompositeType(tag: DW_TAG_structure_type, name: "dwarf.expressions.StackMachine(.{ .addr_size = 8, .endian = .little, .call_frame_context = true }).Value.Value__struct_7462", scope: !2, size: 192, align: 64, elements: !672)
!672 = !{!673, !674, !675}
!673 = !DIDerivedType(tag: DW_TAG_member, name: "type_offset", scope: !671, baseType: !7, size: 64, align: 64)
!674 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !671, baseType: !7, size: 64, align: 64, offset: 64)
!675 = !DIDerivedType(tag: DW_TAG_member, name: "type_size", scope: !671, baseType: !34, size: 8, align: 8, offset: 128)
!676 = !DIDerivedType(tag: DW_TAG_member, name: "const_type", scope: !667, baseType: !677, size: 192, align: 64)
!677 = !DICompositeType(tag: DW_TAG_structure_type, name: "dwarf.expressions.StackMachine(.{ .addr_size = 8, .endian = .little, .call_frame_context = true }).Value.Value__struct_7463", scope: !2, size: 192, align: 64, elements: !678)
!678 = !{!679, !680}
!679 = !DIDerivedType(tag: DW_TAG_member, name: "type_offset", scope: !677, baseType: !7, size: 64, align: 64)
!680 = !DIDerivedType(tag: DW_TAG_member, name: "value_bytes", scope: !677, baseType: !30, size: 128, align: 64, offset: 64)
!681 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !664, baseType: !662, size: 8, align: 8, offset: 192)
!682 = !{!683, !684, !685}
!683 = !DIEnumerator(name: "generic", value: 0, isUnsigned: true)
!684 = !DIEnumerator(name: "regval_type", value: 1, isUnsigned: true)
!685 = !DIEnumerator(name: "const_type", value: 2, isUnsigned: true)
!686 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "@typeInfo(fmt.Specifier).Union.tag_type.?", scope: !688, file: !687, line: 638, baseType: !112, size: 8, align: 8, elements: !696)
!687 = !DIFile(filename: "fmt.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!688 = !DICompositeType(tag: DW_TAG_structure_type, name: "fmt.Specifier", scope: !2, size: 192, align: 64, elements: !689)
!689 = !{!690, !695}
!690 = !DIDerivedType(tag: DW_TAG_member, name: "payload", scope: !688, baseType: !691, size: 128, align: 64)
!691 = !DICompositeType(tag: DW_TAG_union_type, name: "fmt.Specifier:Payload", scope: !2, size: 192, align: 64, elements: !692)
!692 = !{!693, !694}
!693 = !DIDerivedType(tag: DW_TAG_member, name: "number", scope: !691, baseType: !36, size: 64, align: 64)
!694 = !DIDerivedType(tag: DW_TAG_member, name: "named", scope: !691, baseType: !30, size: 128, align: 64)
!695 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !688, baseType: !686, size: 8, align: 8, offset: 128)
!696 = !{!151, !697, !698}
!697 = !DIEnumerator(name: "number", value: 1, isUnsigned: true)
!698 = !DIEnumerator(name: "named", value: 2, isUnsigned: true)
!699 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "fmt.Alignment", scope: !687, file: !687, line: 43, baseType: !112, size: 8, align: 8, elements: !700)
!700 = !{!701, !702, !703}
!701 = !DIEnumerator(name: "left", value: 0, isUnsigned: true)
!702 = !DIEnumerator(name: "center", value: 1, isUnsigned: true)
!703 = !DIEnumerator(name: "right", value: 2, isUnsigned: true)
!704 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "os.linux.E__enum_7702", scope: !705, file: !705, line: 9200, baseType: !341, size: 16, align: 16, elements: !706)
!705 = !DIFile(filename: "linux.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/os")
!706 = !{!707, !708, !709, !710, !711, !712, !713, !714, !715, !716, !717, !718, !719, !720, !721, !722, !723, !724, !725, !726, !727, !728, !729, !730, !731, !732, !733, !734, !735, !736, !737, !738, !739, !740, !741, !742, !743, !744, !745, !746, !747, !748, !749, !750, !751, !752, !753, !754, !755, !756, !757, !758, !759, !760, !761, !762, !763, !764, !765, !766, !767, !768, !769, !770, !771, !772, !773, !774, !775, !776, !777, !778, !779, !780, !781, !782, !783, !784, !785, !786, !787, !788, !789, !790, !791, !792, !793, !794, !795, !796, !797, !798, !799, !800, !801, !802, !803, !804, !805, !806, !807, !808, !809, !810, !811, !812, !813, !814, !815, !816, !817, !818, !819, !820, !821, !822, !823, !824, !825, !826, !827, !828, !829, !830, !831, !832, !833, !834, !835, !836, !837, !838, !839, !840, !841, !842, !843, !844, !845, !846, !847, !848, !849, !850, !851, !852, !853, !854, !855, !856}
!707 = !DIEnumerator(name: "SUCCESS", value: 0, isUnsigned: true)
!708 = !DIEnumerator(name: "PERM", value: 1, isUnsigned: true)
!709 = !DIEnumerator(name: "NOENT", value: 2, isUnsigned: true)
!710 = !DIEnumerator(name: "SRCH", value: 3, isUnsigned: true)
!711 = !DIEnumerator(name: "INTR", value: 4, isUnsigned: true)
!712 = !DIEnumerator(name: "IO", value: 5, isUnsigned: true)
!713 = !DIEnumerator(name: "NXIO", value: 6, isUnsigned: true)
!714 = !DIEnumerator(name: "2BIG", value: 7, isUnsigned: true)
!715 = !DIEnumerator(name: "NOEXEC", value: 8, isUnsigned: true)
!716 = !DIEnumerator(name: "BADF", value: 9, isUnsigned: true)
!717 = !DIEnumerator(name: "CHILD", value: 10, isUnsigned: true)
!718 = !DIEnumerator(name: "AGAIN", value: 11, isUnsigned: true)
!719 = !DIEnumerator(name: "NOMEM", value: 12, isUnsigned: true)
!720 = !DIEnumerator(name: "ACCES", value: 13, isUnsigned: true)
!721 = !DIEnumerator(name: "FAULT", value: 14, isUnsigned: true)
!722 = !DIEnumerator(name: "NOTBLK", value: 15, isUnsigned: true)
!723 = !DIEnumerator(name: "BUSY", value: 16, isUnsigned: true)
!724 = !DIEnumerator(name: "EXIST", value: 17, isUnsigned: true)
!725 = !DIEnumerator(name: "XDEV", value: 18, isUnsigned: true)
!726 = !DIEnumerator(name: "NODEV", value: 19, isUnsigned: true)
!727 = !DIEnumerator(name: "NOTDIR", value: 20, isUnsigned: true)
!728 = !DIEnumerator(name: "ISDIR", value: 21, isUnsigned: true)
!729 = !DIEnumerator(name: "INVAL", value: 22, isUnsigned: true)
!730 = !DIEnumerator(name: "NFILE", value: 23, isUnsigned: true)
!731 = !DIEnumerator(name: "MFILE", value: 24, isUnsigned: true)
!732 = !DIEnumerator(name: "NOTTY", value: 25, isUnsigned: true)
!733 = !DIEnumerator(name: "TXTBSY", value: 26, isUnsigned: true)
!734 = !DIEnumerator(name: "FBIG", value: 27, isUnsigned: true)
!735 = !DIEnumerator(name: "NOSPC", value: 28, isUnsigned: true)
!736 = !DIEnumerator(name: "SPIPE", value: 29, isUnsigned: true)
!737 = !DIEnumerator(name: "ROFS", value: 30, isUnsigned: true)
!738 = !DIEnumerator(name: "MLINK", value: 31, isUnsigned: true)
!739 = !DIEnumerator(name: "PIPE", value: 32, isUnsigned: true)
!740 = !DIEnumerator(name: "DOM", value: 33, isUnsigned: true)
!741 = !DIEnumerator(name: "RANGE", value: 34, isUnsigned: true)
!742 = !DIEnumerator(name: "DEADLK", value: 35, isUnsigned: true)
!743 = !DIEnumerator(name: "NAMETOOLONG", value: 36, isUnsigned: true)
!744 = !DIEnumerator(name: "NOLCK", value: 37, isUnsigned: true)
!745 = !DIEnumerator(name: "NOSYS", value: 38, isUnsigned: true)
!746 = !DIEnumerator(name: "NOTEMPTY", value: 39, isUnsigned: true)
!747 = !DIEnumerator(name: "LOOP", value: 40, isUnsigned: true)
!748 = !DIEnumerator(name: "NOMSG", value: 42, isUnsigned: true)
!749 = !DIEnumerator(name: "IDRM", value: 43, isUnsigned: true)
!750 = !DIEnumerator(name: "CHRNG", value: 44, isUnsigned: true)
!751 = !DIEnumerator(name: "L2NSYNC", value: 45, isUnsigned: true)
!752 = !DIEnumerator(name: "L3HLT", value: 46, isUnsigned: true)
!753 = !DIEnumerator(name: "L3RST", value: 47, isUnsigned: true)
!754 = !DIEnumerator(name: "LNRNG", value: 48, isUnsigned: true)
!755 = !DIEnumerator(name: "UNATCH", value: 49, isUnsigned: true)
!756 = !DIEnumerator(name: "NOCSI", value: 50, isUnsigned: true)
!757 = !DIEnumerator(name: "L2HLT", value: 51, isUnsigned: true)
!758 = !DIEnumerator(name: "BADE", value: 52, isUnsigned: true)
!759 = !DIEnumerator(name: "BADR", value: 53, isUnsigned: true)
!760 = !DIEnumerator(name: "XFULL", value: 54, isUnsigned: true)
!761 = !DIEnumerator(name: "NOANO", value: 55, isUnsigned: true)
!762 = !DIEnumerator(name: "BADRQC", value: 56, isUnsigned: true)
!763 = !DIEnumerator(name: "BADSLT", value: 57, isUnsigned: true)
!764 = !DIEnumerator(name: "BFONT", value: 59, isUnsigned: true)
!765 = !DIEnumerator(name: "NOSTR", value: 60, isUnsigned: true)
!766 = !DIEnumerator(name: "NODATA", value: 61, isUnsigned: true)
!767 = !DIEnumerator(name: "TIME", value: 62, isUnsigned: true)
!768 = !DIEnumerator(name: "NOSR", value: 63, isUnsigned: true)
!769 = !DIEnumerator(name: "NONET", value: 64, isUnsigned: true)
!770 = !DIEnumerator(name: "NOPKG", value: 65, isUnsigned: true)
!771 = !DIEnumerator(name: "REMOTE", value: 66, isUnsigned: true)
!772 = !DIEnumerator(name: "NOLINK", value: 67, isUnsigned: true)
!773 = !DIEnumerator(name: "ADV", value: 68, isUnsigned: true)
!774 = !DIEnumerator(name: "SRMNT", value: 69, isUnsigned: true)
!775 = !DIEnumerator(name: "COMM", value: 70, isUnsigned: true)
!776 = !DIEnumerator(name: "PROTO", value: 71, isUnsigned: true)
!777 = !DIEnumerator(name: "MULTIHOP", value: 72, isUnsigned: true)
!778 = !DIEnumerator(name: "DOTDOT", value: 73, isUnsigned: true)
!779 = !DIEnumerator(name: "BADMSG", value: 74, isUnsigned: true)
!780 = !DIEnumerator(name: "OVERFLOW", value: 75, isUnsigned: true)
!781 = !DIEnumerator(name: "NOTUNIQ", value: 76, isUnsigned: true)
!782 = !DIEnumerator(name: "BADFD", value: 77, isUnsigned: true)
!783 = !DIEnumerator(name: "REMCHG", value: 78, isUnsigned: true)
!784 = !DIEnumerator(name: "LIBACC", value: 79, isUnsigned: true)
!785 = !DIEnumerator(name: "LIBBAD", value: 80, isUnsigned: true)
!786 = !DIEnumerator(name: "LIBSCN", value: 81, isUnsigned: true)
!787 = !DIEnumerator(name: "LIBMAX", value: 82, isUnsigned: true)
!788 = !DIEnumerator(name: "LIBEXEC", value: 83, isUnsigned: true)
!789 = !DIEnumerator(name: "ILSEQ", value: 84, isUnsigned: true)
!790 = !DIEnumerator(name: "RESTART", value: 85, isUnsigned: true)
!791 = !DIEnumerator(name: "STRPIPE", value: 86, isUnsigned: true)
!792 = !DIEnumerator(name: "USERS", value: 87, isUnsigned: true)
!793 = !DIEnumerator(name: "NOTSOCK", value: 88, isUnsigned: true)
!794 = !DIEnumerator(name: "DESTADDRREQ", value: 89, isUnsigned: true)
!795 = !DIEnumerator(name: "MSGSIZE", value: 90, isUnsigned: true)
!796 = !DIEnumerator(name: "PROTOTYPE", value: 91, isUnsigned: true)
!797 = !DIEnumerator(name: "NOPROTOOPT", value: 92, isUnsigned: true)
!798 = !DIEnumerator(name: "PROTONOSUPPORT", value: 93, isUnsigned: true)
!799 = !DIEnumerator(name: "SOCKTNOSUPPORT", value: 94, isUnsigned: true)
!800 = !DIEnumerator(name: "OPNOTSUPP", value: 95, isUnsigned: true)
!801 = !DIEnumerator(name: "PFNOSUPPORT", value: 96, isUnsigned: true)
!802 = !DIEnumerator(name: "AFNOSUPPORT", value: 97, isUnsigned: true)
!803 = !DIEnumerator(name: "ADDRINUSE", value: 98, isUnsigned: true)
!804 = !DIEnumerator(name: "ADDRNOTAVAIL", value: 99, isUnsigned: true)
!805 = !DIEnumerator(name: "NETDOWN", value: 100, isUnsigned: true)
!806 = !DIEnumerator(name: "NETUNREACH", value: 101, isUnsigned: true)
!807 = !DIEnumerator(name: "NETRESET", value: 102, isUnsigned: true)
!808 = !DIEnumerator(name: "CONNABORTED", value: 103, isUnsigned: true)
!809 = !DIEnumerator(name: "CONNRESET", value: 104, isUnsigned: true)
!810 = !DIEnumerator(name: "NOBUFS", value: 105, isUnsigned: true)
!811 = !DIEnumerator(name: "ISCONN", value: 106, isUnsigned: true)
!812 = !DIEnumerator(name: "NOTCONN", value: 107, isUnsigned: true)
!813 = !DIEnumerator(name: "SHUTDOWN", value: 108, isUnsigned: true)
!814 = !DIEnumerator(name: "TOOMANYREFS", value: 109, isUnsigned: true)
!815 = !DIEnumerator(name: "TIMEDOUT", value: 110, isUnsigned: true)
!816 = !DIEnumerator(name: "CONNREFUSED", value: 111, isUnsigned: true)
!817 = !DIEnumerator(name: "HOSTDOWN", value: 112, isUnsigned: true)
!818 = !DIEnumerator(name: "HOSTUNREACH", value: 113, isUnsigned: true)
!819 = !DIEnumerator(name: "ALREADY", value: 114, isUnsigned: true)
!820 = !DIEnumerator(name: "INPROGRESS", value: 115, isUnsigned: true)
!821 = !DIEnumerator(name: "STALE", value: 116, isUnsigned: true)
!822 = !DIEnumerator(name: "UCLEAN", value: 117, isUnsigned: true)
!823 = !DIEnumerator(name: "NOTNAM", value: 118, isUnsigned: true)
!824 = !DIEnumerator(name: "NAVAIL", value: 119, isUnsigned: true)
!825 = !DIEnumerator(name: "ISNAM", value: 120, isUnsigned: true)
!826 = !DIEnumerator(name: "REMOTEIO", value: 121, isUnsigned: true)
!827 = !DIEnumerator(name: "DQUOT", value: 122, isUnsigned: true)
!828 = !DIEnumerator(name: "NOMEDIUM", value: 123, isUnsigned: true)
!829 = !DIEnumerator(name: "MEDIUMTYPE", value: 124, isUnsigned: true)
!830 = !DIEnumerator(name: "CANCELED", value: 125, isUnsigned: true)
!831 = !DIEnumerator(name: "NOKEY", value: 126, isUnsigned: true)
!832 = !DIEnumerator(name: "KEYEXPIRED", value: 127, isUnsigned: true)
!833 = !DIEnumerator(name: "KEYREVOKED", value: 128, isUnsigned: true)
!834 = !DIEnumerator(name: "KEYREJECTED", value: 129, isUnsigned: true)
!835 = !DIEnumerator(name: "OWNERDEAD", value: 130, isUnsigned: true)
!836 = !DIEnumerator(name: "NOTRECOVERABLE", value: 131, isUnsigned: true)
!837 = !DIEnumerator(name: "RFKILL", value: 132, isUnsigned: true)
!838 = !DIEnumerator(name: "HWPOISON", value: 133, isUnsigned: true)
!839 = !DIEnumerator(name: "NSRNODATA", value: 160, isUnsigned: true)
!840 = !DIEnumerator(name: "NSRFORMERR", value: 161, isUnsigned: true)
!841 = !DIEnumerator(name: "NSRSERVFAIL", value: 162, isUnsigned: true)
!842 = !DIEnumerator(name: "NSRNOTFOUND", value: 163, isUnsigned: true)
!843 = !DIEnumerator(name: "NSRNOTIMP", value: 164, isUnsigned: true)
!844 = !DIEnumerator(name: "NSRREFUSED", value: 165, isUnsigned: true)
!845 = !DIEnumerator(name: "NSRBADQUERY", value: 166, isUnsigned: true)
!846 = !DIEnumerator(name: "NSRBADNAME", value: 167, isUnsigned: true)
!847 = !DIEnumerator(name: "NSRBADFAMILY", value: 168, isUnsigned: true)
!848 = !DIEnumerator(name: "NSRBADRESP", value: 169, isUnsigned: true)
!849 = !DIEnumerator(name: "NSRCONNREFUSED", value: 170, isUnsigned: true)
!850 = !DIEnumerator(name: "NSRTIMEOUT", value: 171, isUnsigned: true)
!851 = !DIEnumerator(name: "NSROF", value: 172, isUnsigned: true)
!852 = !DIEnumerator(name: "NSRFILE", value: 173, isUnsigned: true)
!853 = !DIEnumerator(name: "NSRNOMEM", value: 174, isUnsigned: true)
!854 = !DIEnumerator(name: "NSRDESTRUCTION", value: 175, isUnsigned: true)
!855 = !DIEnumerator(name: "NSRQUERYDOMAINTOOLONG", value: 176, isUnsigned: true)
!856 = !DIEnumerator(name: "NSRCNAMELOOP", value: 177, isUnsigned: true)
!857 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Target.Abi", scope: !22, file: !22, line: 1416, baseType: !47, size: 8, align: 8, elements: !858)
!858 = !{!859, !860, !861, !862, !863, !864, !865, !866, !867, !868, !869, !870, !871, !872, !873, !874, !875, !876, !877, !878, !879, !880, !881, !882, !883, !884, !885, !886, !887, !888, !889, !890, !891, !892, !893, !894, !895, !896, !897, !898, !899}
!859 = !DIEnumerator(name: "none", value: 0, isUnsigned: true)
!860 = !DIEnumerator(name: "gnu", value: 1, isUnsigned: true)
!861 = !DIEnumerator(name: "gnuabin32", value: 2, isUnsigned: true)
!862 = !DIEnumerator(name: "gnuabi64", value: 3, isUnsigned: true)
!863 = !DIEnumerator(name: "gnueabi", value: 4, isUnsigned: true)
!864 = !DIEnumerator(name: "gnueabihf", value: 5, isUnsigned: true)
!865 = !DIEnumerator(name: "gnuf32", value: 6, isUnsigned: true)
!866 = !DIEnumerator(name: "gnuf64", value: 7, isUnsigned: true)
!867 = !DIEnumerator(name: "gnusf", value: 8, isUnsigned: true)
!868 = !DIEnumerator(name: "gnux32", value: 9, isUnsigned: true)
!869 = !DIEnumerator(name: "gnuilp32", value: 10, isUnsigned: true)
!870 = !DIEnumerator(name: "code16", value: 11, isUnsigned: true)
!871 = !DIEnumerator(name: "eabi", value: 12, isUnsigned: true)
!872 = !DIEnumerator(name: "eabihf", value: 13, isUnsigned: true)
!873 = !DIEnumerator(name: "android", value: 14, isUnsigned: true)
!874 = !DIEnumerator(name: "musl", value: 15, isUnsigned: true)
!875 = !DIEnumerator(name: "musleabi", value: 16, isUnsigned: true)
!876 = !DIEnumerator(name: "musleabihf", value: 17, isUnsigned: true)
!877 = !DIEnumerator(name: "muslx32", value: 18, isUnsigned: true)
!878 = !DIEnumerator(name: "msvc", value: 19, isUnsigned: true)
!879 = !DIEnumerator(name: "itanium", value: 20, isUnsigned: true)
!880 = !DIEnumerator(name: "cygnus", value: 21, isUnsigned: true)
!881 = !DIEnumerator(name: "coreclr", value: 22, isUnsigned: true)
!882 = !DIEnumerator(name: "simulator", value: 23, isUnsigned: true)
!883 = !DIEnumerator(name: "macabi", value: 24, isUnsigned: true)
!884 = !DIEnumerator(name: "pixel", value: 25, isUnsigned: true)
!885 = !DIEnumerator(name: "vertex", value: 26, isUnsigned: true)
!886 = !DIEnumerator(name: "geometry", value: 27, isUnsigned: true)
!887 = !DIEnumerator(name: "hull", value: 28, isUnsigned: true)
!888 = !DIEnumerator(name: "domain", value: 29, isUnsigned: true)
!889 = !DIEnumerator(name: "compute", value: 30, isUnsigned: true)
!890 = !DIEnumerator(name: "library", value: 31, isUnsigned: true)
!891 = !DIEnumerator(name: "raygeneration", value: 32, isUnsigned: true)
!892 = !DIEnumerator(name: "intersection", value: 33, isUnsigned: true)
!893 = !DIEnumerator(name: "anyhit", value: 34, isUnsigned: true)
!894 = !DIEnumerator(name: "closesthit", value: 35, isUnsigned: true)
!895 = !DIEnumerator(name: "miss", value: 36, isUnsigned: true)
!896 = !DIEnumerator(name: "callable", value: 37, isUnsigned: true)
!897 = !DIEnumerator(name: "mesh", value: 38, isUnsigned: true)
!898 = !DIEnumerator(name: "amplification", value: 39, isUnsigned: true)
!899 = !DIEnumerator(name: "ohos", value: 40, isUnsigned: true)
!900 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Target.ObjectFormat", scope: !22, file: !22, line: 1525, baseType: !323, size: 8, align: 8, elements: !901)
!901 = !{!902, !903, !904, !905, !906, !907, !908, !909, !910, !911, !912}
!902 = !DIEnumerator(name: "coff", value: 0, isUnsigned: true)
!903 = !DIEnumerator(name: "dxcontainer", value: 1, isUnsigned: true)
!904 = !DIEnumerator(name: "elf", value: 2, isUnsigned: true)
!905 = !DIEnumerator(name: "macho", value: 3, isUnsigned: true)
!906 = !DIEnumerator(name: "spirv", value: 4, isUnsigned: true)
!907 = !DIEnumerator(name: "wasm", value: 5, isUnsigned: true)
!908 = !DIEnumerator(name: "c", value: 6, isUnsigned: true)
!909 = !DIEnumerator(name: "hex", value: 7, isUnsigned: true)
!910 = !DIEnumerator(name: "raw", value: 8, isUnsigned: true)
!911 = !DIEnumerator(name: "plan9", value: 9, isUnsigned: true)
!912 = !DIEnumerator(name: "nvptx", value: 10, isUnsigned: true)
!913 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "builtin.Signedness", scope: !6, file: !6, line: 637, baseType: !260, size: 8, align: 8, elements: !610)
!914 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "fs.File.OpenMode", scope: !915, file: !915, line: 71, baseType: !112, size: 8, align: 8, elements: !916)
!915 = !DIFile(filename: "File.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/fs")
!916 = !{!917, !918, !919}
!917 = !DIEnumerator(name: "read_only", value: 0, isUnsigned: true)
!918 = !DIEnumerator(name: "write_only", value: 1, isUnsigned: true)
!919 = !DIEnumerator(name: "read_write", value: 2, isUnsigned: true)
!920 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "fs.File.Lock", scope: !915, file: !915, line: 79, baseType: !112, size: 8, align: 8, elements: !921)
!921 = !{!151, !922, !923}
!922 = !DIEnumerator(name: "shared", value: 1, isUnsigned: true)
!923 = !DIEnumerator(name: "exclusive", value: 2, isUnsigned: true)
!924 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "io.tty.Color", scope: !632, file: !632, line: 149, baseType: !303, size: 8, align: 8, elements: !925)
!925 = !{!926, !927, !928, !929, !930, !931, !932, !933, !934, !935, !936, !937, !938, !939, !940, !941, !942, !943, !944}
!926 = !DIEnumerator(name: "black", value: 0, isUnsigned: true)
!927 = !DIEnumerator(name: "red", value: 1, isUnsigned: true)
!928 = !DIEnumerator(name: "green", value: 2, isUnsigned: true)
!929 = !DIEnumerator(name: "yellow", value: 3, isUnsigned: true)
!930 = !DIEnumerator(name: "blue", value: 4, isUnsigned: true)
!931 = !DIEnumerator(name: "magenta", value: 5, isUnsigned: true)
!932 = !DIEnumerator(name: "cyan", value: 6, isUnsigned: true)
!933 = !DIEnumerator(name: "white", value: 7, isUnsigned: true)
!934 = !DIEnumerator(name: "bright_black", value: 8, isUnsigned: true)
!935 = !DIEnumerator(name: "bright_red", value: 9, isUnsigned: true)
!936 = !DIEnumerator(name: "bright_green", value: 10, isUnsigned: true)
!937 = !DIEnumerator(name: "bright_yellow", value: 11, isUnsigned: true)
!938 = !DIEnumerator(name: "bright_blue", value: 12, isUnsigned: true)
!939 = !DIEnumerator(name: "bright_magenta", value: 13, isUnsigned: true)
!940 = !DIEnumerator(name: "bright_cyan", value: 14, isUnsigned: true)
!941 = !DIEnumerator(name: "bright_white", value: 15, isUnsigned: true)
!942 = !DIEnumerator(name: "dim", value: 16, isUnsigned: true)
!943 = !DIEnumerator(name: "bold", value: 17, isUnsigned: true)
!944 = !DIEnumerator(name: "reset", value: 18, isUnsigned: true)
!945 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "os.linux.syscalls.X64", scope: !946, file: !946, line: 2449, baseType: !36, size: 64, align: 64, elements: !947)
!946 = !DIFile(filename: "syscalls.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/os/linux")
!947 = !{!948, !949, !950, !951, !952, !953, !954, !955, !956, !957, !958, !959, !960, !961, !962, !963, !964, !965, !966, !967, !968, !969, !970, !971, !972, !973, !974, !975, !976, !977, !978, !979, !980, !981, !982, !983, !984, !985, !986, !987, !988, !989, !990, !991, !992, !993, !994, !995, !996, !997, !998, !999, !1000, !1001, !1002, !1003, !1004, !1005, !1006, !1007, !1008, !1009, !1010, !1011, !1012, !1013, !1014, !1015, !1016, !1017, !1018, !1019, !1020, !1021, !1022, !1023, !1024, !1025, !1026, !1027, !1028, !1029, !1030, !1031, !1032, !1033, !1034, !1035, !1036, !1037, !1038, !1039, !1040, !1041, !1042, !1043, !1044, !1045, !1046, !1047, !1048, !1049, !1050, !1051, !1052, !1053, !1054, !1055, !1056, !1057, !1058, !1059, !1060, !1061, !1062, !1063, !1064, !1065, !1066, !1067, !1068, !1069, !1070, !1071, !1072, !1073, !1074, !1075, !1076, !1077, !1078, !1079, !1080, !1081, !1082, !1083, !1084, !1085, !1086, !1087, !1088, !1089, !1090, !1091, !1092, !1093, !1094, !1095, !1096, !1097, !1098, !1099, !1100, !1101, !1102, !1103, !1104, !1105, !1106, !1107, !1108, !1109, !1110, !1111, !1112, !1113, !1114, !1115, !1116, !1117, !1118, !1119, !1120, !1121, !1122, !1123, !1124, !1125, !1126, !1127, !1128, !1129, !1130, !1131, !1132, !1133, !1134, !1135, !1136, !1137, !1138, !1139, !1140, !1141, !1142, !1143, !1144, !1145, !1146, !1147, !1148, !1149, !1150, !1151, !1152, !1153, !1154, !1155, !1156, !1157, !1158, !1159, !1160, !1161, !1162, !1163, !1164, !1165, !1166, !1167, !1168, !1169, !1170, !1171, !1172, !1173, !1174, !1175, !1176, !1177, !1178, !1179, !1180, !1181, !1182, !1183, !1184, !1185, !1186, !1187, !1188, !1189, !1190, !1191, !1192, !1193, !1194, !1195, !1196, !1197, !1198, !1199, !1200, !1201, !1202, !1203, !1204, !1205, !1206, !1207, !1208, !1209, !1210, !1211, !1212, !1213, !1214, !1215, !1216, !1217, !1218, !1219, !1220, !1221, !1222, !1223, !1224, !1225, !1226, !1227, !1228, !1229, !1230, !1231, !1232, !1233, !1234, !1235, !1236, !1237, !1238, !1239, !1240, !1241, !1242, !1243, !1244, !1245, !1246, !1247, !1248, !1249, !1250, !1251, !1252, !1253, !1254, !1255, !1256, !1257, !1258, !1259, !1260, !1261, !1262, !1263, !1264, !1265, !1266, !1267, !1268, !1269, !1270, !1271, !1272, !1273, !1274, !1275, !1276, !1277, !1278, !1279, !1280, !1281, !1282, !1283, !1284, !1285, !1286, !1287, !1288, !1289, !1290, !1291, !1292, !1293, !1294, !1295, !1296, !1297, !1298, !1299, !1300, !1301, !1302, !1303, !1304, !1305, !1306, !1307, !1308, !1309, !1310, !1311, !1312, !1313, !1314, !1315}
!948 = !DIEnumerator(name: "read", value: 0, isUnsigned: true)
!949 = !DIEnumerator(name: "write", value: 1, isUnsigned: true)
!950 = !DIEnumerator(name: "open", value: 2, isUnsigned: true)
!951 = !DIEnumerator(name: "close", value: 3, isUnsigned: true)
!952 = !DIEnumerator(name: "stat", value: 4, isUnsigned: true)
!953 = !DIEnumerator(name: "fstat", value: 5, isUnsigned: true)
!954 = !DIEnumerator(name: "lstat", value: 6, isUnsigned: true)
!955 = !DIEnumerator(name: "poll", value: 7, isUnsigned: true)
!956 = !DIEnumerator(name: "lseek", value: 8, isUnsigned: true)
!957 = !DIEnumerator(name: "mmap", value: 9, isUnsigned: true)
!958 = !DIEnumerator(name: "mprotect", value: 10, isUnsigned: true)
!959 = !DIEnumerator(name: "munmap", value: 11, isUnsigned: true)
!960 = !DIEnumerator(name: "brk", value: 12, isUnsigned: true)
!961 = !DIEnumerator(name: "rt_sigaction", value: 13, isUnsigned: true)
!962 = !DIEnumerator(name: "rt_sigprocmask", value: 14, isUnsigned: true)
!963 = !DIEnumerator(name: "rt_sigreturn", value: 15, isUnsigned: true)
!964 = !DIEnumerator(name: "ioctl", value: 16, isUnsigned: true)
!965 = !DIEnumerator(name: "pread64", value: 17, isUnsigned: true)
!966 = !DIEnumerator(name: "pwrite64", value: 18, isUnsigned: true)
!967 = !DIEnumerator(name: "readv", value: 19, isUnsigned: true)
!968 = !DIEnumerator(name: "writev", value: 20, isUnsigned: true)
!969 = !DIEnumerator(name: "access", value: 21, isUnsigned: true)
!970 = !DIEnumerator(name: "pipe", value: 22, isUnsigned: true)
!971 = !DIEnumerator(name: "select", value: 23, isUnsigned: true)
!972 = !DIEnumerator(name: "sched_yield", value: 24, isUnsigned: true)
!973 = !DIEnumerator(name: "mremap", value: 25, isUnsigned: true)
!974 = !DIEnumerator(name: "msync", value: 26, isUnsigned: true)
!975 = !DIEnumerator(name: "mincore", value: 27, isUnsigned: true)
!976 = !DIEnumerator(name: "madvise", value: 28, isUnsigned: true)
!977 = !DIEnumerator(name: "shmget", value: 29, isUnsigned: true)
!978 = !DIEnumerator(name: "shmat", value: 30, isUnsigned: true)
!979 = !DIEnumerator(name: "shmctl", value: 31, isUnsigned: true)
!980 = !DIEnumerator(name: "dup", value: 32, isUnsigned: true)
!981 = !DIEnumerator(name: "dup2", value: 33, isUnsigned: true)
!982 = !DIEnumerator(name: "pause", value: 34, isUnsigned: true)
!983 = !DIEnumerator(name: "nanosleep", value: 35, isUnsigned: true)
!984 = !DIEnumerator(name: "getitimer", value: 36, isUnsigned: true)
!985 = !DIEnumerator(name: "alarm", value: 37, isUnsigned: true)
!986 = !DIEnumerator(name: "setitimer", value: 38, isUnsigned: true)
!987 = !DIEnumerator(name: "getpid", value: 39, isUnsigned: true)
!988 = !DIEnumerator(name: "sendfile", value: 40, isUnsigned: true)
!989 = !DIEnumerator(name: "socket", value: 41, isUnsigned: true)
!990 = !DIEnumerator(name: "connect", value: 42, isUnsigned: true)
!991 = !DIEnumerator(name: "accept", value: 43, isUnsigned: true)
!992 = !DIEnumerator(name: "sendto", value: 44, isUnsigned: true)
!993 = !DIEnumerator(name: "recvfrom", value: 45, isUnsigned: true)
!994 = !DIEnumerator(name: "sendmsg", value: 46, isUnsigned: true)
!995 = !DIEnumerator(name: "recvmsg", value: 47, isUnsigned: true)
!996 = !DIEnumerator(name: "shutdown", value: 48, isUnsigned: true)
!997 = !DIEnumerator(name: "bind", value: 49, isUnsigned: true)
!998 = !DIEnumerator(name: "listen", value: 50, isUnsigned: true)
!999 = !DIEnumerator(name: "getsockname", value: 51, isUnsigned: true)
!1000 = !DIEnumerator(name: "getpeername", value: 52, isUnsigned: true)
!1001 = !DIEnumerator(name: "socketpair", value: 53, isUnsigned: true)
!1002 = !DIEnumerator(name: "setsockopt", value: 54, isUnsigned: true)
!1003 = !DIEnumerator(name: "getsockopt", value: 55, isUnsigned: true)
!1004 = !DIEnumerator(name: "clone", value: 56, isUnsigned: true)
!1005 = !DIEnumerator(name: "fork", value: 57, isUnsigned: true)
!1006 = !DIEnumerator(name: "vfork", value: 58, isUnsigned: true)
!1007 = !DIEnumerator(name: "execve", value: 59, isUnsigned: true)
!1008 = !DIEnumerator(name: "exit", value: 60, isUnsigned: true)
!1009 = !DIEnumerator(name: "wait4", value: 61, isUnsigned: true)
!1010 = !DIEnumerator(name: "kill", value: 62, isUnsigned: true)
!1011 = !DIEnumerator(name: "uname", value: 63, isUnsigned: true)
!1012 = !DIEnumerator(name: "semget", value: 64, isUnsigned: true)
!1013 = !DIEnumerator(name: "semop", value: 65, isUnsigned: true)
!1014 = !DIEnumerator(name: "semctl", value: 66, isUnsigned: true)
!1015 = !DIEnumerator(name: "shmdt", value: 67, isUnsigned: true)
!1016 = !DIEnumerator(name: "msgget", value: 68, isUnsigned: true)
!1017 = !DIEnumerator(name: "msgsnd", value: 69, isUnsigned: true)
!1018 = !DIEnumerator(name: "msgrcv", value: 70, isUnsigned: true)
!1019 = !DIEnumerator(name: "msgctl", value: 71, isUnsigned: true)
!1020 = !DIEnumerator(name: "fcntl", value: 72, isUnsigned: true)
!1021 = !DIEnumerator(name: "flock", value: 73, isUnsigned: true)
!1022 = !DIEnumerator(name: "fsync", value: 74, isUnsigned: true)
!1023 = !DIEnumerator(name: "fdatasync", value: 75, isUnsigned: true)
!1024 = !DIEnumerator(name: "truncate", value: 76, isUnsigned: true)
!1025 = !DIEnumerator(name: "ftruncate", value: 77, isUnsigned: true)
!1026 = !DIEnumerator(name: "getdents", value: 78, isUnsigned: true)
!1027 = !DIEnumerator(name: "getcwd", value: 79, isUnsigned: true)
!1028 = !DIEnumerator(name: "chdir", value: 80, isUnsigned: true)
!1029 = !DIEnumerator(name: "fchdir", value: 81, isUnsigned: true)
!1030 = !DIEnumerator(name: "rename", value: 82, isUnsigned: true)
!1031 = !DIEnumerator(name: "mkdir", value: 83, isUnsigned: true)
!1032 = !DIEnumerator(name: "rmdir", value: 84, isUnsigned: true)
!1033 = !DIEnumerator(name: "creat", value: 85, isUnsigned: true)
!1034 = !DIEnumerator(name: "link", value: 86, isUnsigned: true)
!1035 = !DIEnumerator(name: "unlink", value: 87, isUnsigned: true)
!1036 = !DIEnumerator(name: "symlink", value: 88, isUnsigned: true)
!1037 = !DIEnumerator(name: "readlink", value: 89, isUnsigned: true)
!1038 = !DIEnumerator(name: "chmod", value: 90, isUnsigned: true)
!1039 = !DIEnumerator(name: "fchmod", value: 91, isUnsigned: true)
!1040 = !DIEnumerator(name: "chown", value: 92, isUnsigned: true)
!1041 = !DIEnumerator(name: "fchown", value: 93, isUnsigned: true)
!1042 = !DIEnumerator(name: "lchown", value: 94, isUnsigned: true)
!1043 = !DIEnumerator(name: "umask", value: 95, isUnsigned: true)
!1044 = !DIEnumerator(name: "gettimeofday", value: 96, isUnsigned: true)
!1045 = !DIEnumerator(name: "getrlimit", value: 97, isUnsigned: true)
!1046 = !DIEnumerator(name: "getrusage", value: 98, isUnsigned: true)
!1047 = !DIEnumerator(name: "sysinfo", value: 99, isUnsigned: true)
!1048 = !DIEnumerator(name: "times", value: 100, isUnsigned: true)
!1049 = !DIEnumerator(name: "ptrace", value: 101, isUnsigned: true)
!1050 = !DIEnumerator(name: "getuid", value: 102, isUnsigned: true)
!1051 = !DIEnumerator(name: "syslog", value: 103, isUnsigned: true)
!1052 = !DIEnumerator(name: "getgid", value: 104, isUnsigned: true)
!1053 = !DIEnumerator(name: "setuid", value: 105, isUnsigned: true)
!1054 = !DIEnumerator(name: "setgid", value: 106, isUnsigned: true)
!1055 = !DIEnumerator(name: "geteuid", value: 107, isUnsigned: true)
!1056 = !DIEnumerator(name: "getegid", value: 108, isUnsigned: true)
!1057 = !DIEnumerator(name: "setpgid", value: 109, isUnsigned: true)
!1058 = !DIEnumerator(name: "getppid", value: 110, isUnsigned: true)
!1059 = !DIEnumerator(name: "getpgrp", value: 111, isUnsigned: true)
!1060 = !DIEnumerator(name: "setsid", value: 112, isUnsigned: true)
!1061 = !DIEnumerator(name: "setreuid", value: 113, isUnsigned: true)
!1062 = !DIEnumerator(name: "setregid", value: 114, isUnsigned: true)
!1063 = !DIEnumerator(name: "getgroups", value: 115, isUnsigned: true)
!1064 = !DIEnumerator(name: "setgroups", value: 116, isUnsigned: true)
!1065 = !DIEnumerator(name: "setresuid", value: 117, isUnsigned: true)
!1066 = !DIEnumerator(name: "getresuid", value: 118, isUnsigned: true)
!1067 = !DIEnumerator(name: "setresgid", value: 119, isUnsigned: true)
!1068 = !DIEnumerator(name: "getresgid", value: 120, isUnsigned: true)
!1069 = !DIEnumerator(name: "getpgid", value: 121, isUnsigned: true)
!1070 = !DIEnumerator(name: "setfsuid", value: 122, isUnsigned: true)
!1071 = !DIEnumerator(name: "setfsgid", value: 123, isUnsigned: true)
!1072 = !DIEnumerator(name: "getsid", value: 124, isUnsigned: true)
!1073 = !DIEnumerator(name: "capget", value: 125, isUnsigned: true)
!1074 = !DIEnumerator(name: "capset", value: 126, isUnsigned: true)
!1075 = !DIEnumerator(name: "rt_sigpending", value: 127, isUnsigned: true)
!1076 = !DIEnumerator(name: "rt_sigtimedwait", value: 128, isUnsigned: true)
!1077 = !DIEnumerator(name: "rt_sigqueueinfo", value: 129, isUnsigned: true)
!1078 = !DIEnumerator(name: "rt_sigsuspend", value: 130, isUnsigned: true)
!1079 = !DIEnumerator(name: "sigaltstack", value: 131, isUnsigned: true)
!1080 = !DIEnumerator(name: "utime", value: 132, isUnsigned: true)
!1081 = !DIEnumerator(name: "mknod", value: 133, isUnsigned: true)
!1082 = !DIEnumerator(name: "uselib", value: 134, isUnsigned: true)
!1083 = !DIEnumerator(name: "personality", value: 135, isUnsigned: true)
!1084 = !DIEnumerator(name: "ustat", value: 136, isUnsigned: true)
!1085 = !DIEnumerator(name: "statfs", value: 137, isUnsigned: true)
!1086 = !DIEnumerator(name: "fstatfs", value: 138, isUnsigned: true)
!1087 = !DIEnumerator(name: "sysfs", value: 139, isUnsigned: true)
!1088 = !DIEnumerator(name: "getpriority", value: 140, isUnsigned: true)
!1089 = !DIEnumerator(name: "setpriority", value: 141, isUnsigned: true)
!1090 = !DIEnumerator(name: "sched_setparam", value: 142, isUnsigned: true)
!1091 = !DIEnumerator(name: "sched_getparam", value: 143, isUnsigned: true)
!1092 = !DIEnumerator(name: "sched_setscheduler", value: 144, isUnsigned: true)
!1093 = !DIEnumerator(name: "sched_getscheduler", value: 145, isUnsigned: true)
!1094 = !DIEnumerator(name: "sched_get_priority_max", value: 146, isUnsigned: true)
!1095 = !DIEnumerator(name: "sched_get_priority_min", value: 147, isUnsigned: true)
!1096 = !DIEnumerator(name: "sched_rr_get_interval", value: 148, isUnsigned: true)
!1097 = !DIEnumerator(name: "mlock", value: 149, isUnsigned: true)
!1098 = !DIEnumerator(name: "munlock", value: 150, isUnsigned: true)
!1099 = !DIEnumerator(name: "mlockall", value: 151, isUnsigned: true)
!1100 = !DIEnumerator(name: "munlockall", value: 152, isUnsigned: true)
!1101 = !DIEnumerator(name: "vhangup", value: 153, isUnsigned: true)
!1102 = !DIEnumerator(name: "modify_ldt", value: 154, isUnsigned: true)
!1103 = !DIEnumerator(name: "pivot_root", value: 155, isUnsigned: true)
!1104 = !DIEnumerator(name: "_sysctl", value: 156, isUnsigned: true)
!1105 = !DIEnumerator(name: "prctl", value: 157, isUnsigned: true)
!1106 = !DIEnumerator(name: "arch_prctl", value: 158, isUnsigned: true)
!1107 = !DIEnumerator(name: "adjtimex", value: 159, isUnsigned: true)
!1108 = !DIEnumerator(name: "setrlimit", value: 160, isUnsigned: true)
!1109 = !DIEnumerator(name: "chroot", value: 161, isUnsigned: true)
!1110 = !DIEnumerator(name: "sync", value: 162, isUnsigned: true)
!1111 = !DIEnumerator(name: "acct", value: 163, isUnsigned: true)
!1112 = !DIEnumerator(name: "settimeofday", value: 164, isUnsigned: true)
!1113 = !DIEnumerator(name: "mount", value: 165, isUnsigned: true)
!1114 = !DIEnumerator(name: "umount2", value: 166, isUnsigned: true)
!1115 = !DIEnumerator(name: "swapon", value: 167, isUnsigned: true)
!1116 = !DIEnumerator(name: "swapoff", value: 168, isUnsigned: true)
!1117 = !DIEnumerator(name: "reboot", value: 169, isUnsigned: true)
!1118 = !DIEnumerator(name: "sethostname", value: 170, isUnsigned: true)
!1119 = !DIEnumerator(name: "setdomainname", value: 171, isUnsigned: true)
!1120 = !DIEnumerator(name: "iopl", value: 172, isUnsigned: true)
!1121 = !DIEnumerator(name: "ioperm", value: 173, isUnsigned: true)
!1122 = !DIEnumerator(name: "create_module", value: 174, isUnsigned: true)
!1123 = !DIEnumerator(name: "init_module", value: 175, isUnsigned: true)
!1124 = !DIEnumerator(name: "delete_module", value: 176, isUnsigned: true)
!1125 = !DIEnumerator(name: "get_kernel_syms", value: 177, isUnsigned: true)
!1126 = !DIEnumerator(name: "query_module", value: 178, isUnsigned: true)
!1127 = !DIEnumerator(name: "quotactl", value: 179, isUnsigned: true)
!1128 = !DIEnumerator(name: "nfsservctl", value: 180, isUnsigned: true)
!1129 = !DIEnumerator(name: "getpmsg", value: 181, isUnsigned: true)
!1130 = !DIEnumerator(name: "putpmsg", value: 182, isUnsigned: true)
!1131 = !DIEnumerator(name: "afs_syscall", value: 183, isUnsigned: true)
!1132 = !DIEnumerator(name: "tuxcall", value: 184, isUnsigned: true)
!1133 = !DIEnumerator(name: "security", value: 185, isUnsigned: true)
!1134 = !DIEnumerator(name: "gettid", value: 186, isUnsigned: true)
!1135 = !DIEnumerator(name: "readahead", value: 187, isUnsigned: true)
!1136 = !DIEnumerator(name: "setxattr", value: 188, isUnsigned: true)
!1137 = !DIEnumerator(name: "lsetxattr", value: 189, isUnsigned: true)
!1138 = !DIEnumerator(name: "fsetxattr", value: 190, isUnsigned: true)
!1139 = !DIEnumerator(name: "getxattr", value: 191, isUnsigned: true)
!1140 = !DIEnumerator(name: "lgetxattr", value: 192, isUnsigned: true)
!1141 = !DIEnumerator(name: "fgetxattr", value: 193, isUnsigned: true)
!1142 = !DIEnumerator(name: "listxattr", value: 194, isUnsigned: true)
!1143 = !DIEnumerator(name: "llistxattr", value: 195, isUnsigned: true)
!1144 = !DIEnumerator(name: "flistxattr", value: 196, isUnsigned: true)
!1145 = !DIEnumerator(name: "removexattr", value: 197, isUnsigned: true)
!1146 = !DIEnumerator(name: "lremovexattr", value: 198, isUnsigned: true)
!1147 = !DIEnumerator(name: "fremovexattr", value: 199, isUnsigned: true)
!1148 = !DIEnumerator(name: "tkill", value: 200, isUnsigned: true)
!1149 = !DIEnumerator(name: "time", value: 201, isUnsigned: true)
!1150 = !DIEnumerator(name: "futex", value: 202, isUnsigned: true)
!1151 = !DIEnumerator(name: "sched_setaffinity", value: 203, isUnsigned: true)
!1152 = !DIEnumerator(name: "sched_getaffinity", value: 204, isUnsigned: true)
!1153 = !DIEnumerator(name: "set_thread_area", value: 205, isUnsigned: true)
!1154 = !DIEnumerator(name: "io_setup", value: 206, isUnsigned: true)
!1155 = !DIEnumerator(name: "io_destroy", value: 207, isUnsigned: true)
!1156 = !DIEnumerator(name: "io_getevents", value: 208, isUnsigned: true)
!1157 = !DIEnumerator(name: "io_submit", value: 209, isUnsigned: true)
!1158 = !DIEnumerator(name: "io_cancel", value: 210, isUnsigned: true)
!1159 = !DIEnumerator(name: "get_thread_area", value: 211, isUnsigned: true)
!1160 = !DIEnumerator(name: "lookup_dcookie", value: 212, isUnsigned: true)
!1161 = !DIEnumerator(name: "epoll_create", value: 213, isUnsigned: true)
!1162 = !DIEnumerator(name: "epoll_ctl_old", value: 214, isUnsigned: true)
!1163 = !DIEnumerator(name: "epoll_wait_old", value: 215, isUnsigned: true)
!1164 = !DIEnumerator(name: "remap_file_pages", value: 216, isUnsigned: true)
!1165 = !DIEnumerator(name: "getdents64", value: 217, isUnsigned: true)
!1166 = !DIEnumerator(name: "set_tid_address", value: 218, isUnsigned: true)
!1167 = !DIEnumerator(name: "restart_syscall", value: 219, isUnsigned: true)
!1168 = !DIEnumerator(name: "semtimedop", value: 220, isUnsigned: true)
!1169 = !DIEnumerator(name: "fadvise64", value: 221, isUnsigned: true)
!1170 = !DIEnumerator(name: "timer_create", value: 222, isUnsigned: true)
!1171 = !DIEnumerator(name: "timer_settime", value: 223, isUnsigned: true)
!1172 = !DIEnumerator(name: "timer_gettime", value: 224, isUnsigned: true)
!1173 = !DIEnumerator(name: "timer_getoverrun", value: 225, isUnsigned: true)
!1174 = !DIEnumerator(name: "timer_delete", value: 226, isUnsigned: true)
!1175 = !DIEnumerator(name: "clock_settime", value: 227, isUnsigned: true)
!1176 = !DIEnumerator(name: "clock_gettime", value: 228, isUnsigned: true)
!1177 = !DIEnumerator(name: "clock_getres", value: 229, isUnsigned: true)
!1178 = !DIEnumerator(name: "clock_nanosleep", value: 230, isUnsigned: true)
!1179 = !DIEnumerator(name: "exit_group", value: 231, isUnsigned: true)
!1180 = !DIEnumerator(name: "epoll_wait", value: 232, isUnsigned: true)
!1181 = !DIEnumerator(name: "epoll_ctl", value: 233, isUnsigned: true)
!1182 = !DIEnumerator(name: "tgkill", value: 234, isUnsigned: true)
!1183 = !DIEnumerator(name: "utimes", value: 235, isUnsigned: true)
!1184 = !DIEnumerator(name: "vserver", value: 236, isUnsigned: true)
!1185 = !DIEnumerator(name: "mbind", value: 237, isUnsigned: true)
!1186 = !DIEnumerator(name: "set_mempolicy", value: 238, isUnsigned: true)
!1187 = !DIEnumerator(name: "get_mempolicy", value: 239, isUnsigned: true)
!1188 = !DIEnumerator(name: "mq_open", value: 240, isUnsigned: true)
!1189 = !DIEnumerator(name: "mq_unlink", value: 241, isUnsigned: true)
!1190 = !DIEnumerator(name: "mq_timedsend", value: 242, isUnsigned: true)
!1191 = !DIEnumerator(name: "mq_timedreceive", value: 243, isUnsigned: true)
!1192 = !DIEnumerator(name: "mq_notify", value: 244, isUnsigned: true)
!1193 = !DIEnumerator(name: "mq_getsetattr", value: 245, isUnsigned: true)
!1194 = !DIEnumerator(name: "kexec_load", value: 246, isUnsigned: true)
!1195 = !DIEnumerator(name: "waitid", value: 247, isUnsigned: true)
!1196 = !DIEnumerator(name: "add_key", value: 248, isUnsigned: true)
!1197 = !DIEnumerator(name: "request_key", value: 249, isUnsigned: true)
!1198 = !DIEnumerator(name: "keyctl", value: 250, isUnsigned: true)
!1199 = !DIEnumerator(name: "ioprio_set", value: 251, isUnsigned: true)
!1200 = !DIEnumerator(name: "ioprio_get", value: 252, isUnsigned: true)
!1201 = !DIEnumerator(name: "inotify_init", value: 253, isUnsigned: true)
!1202 = !DIEnumerator(name: "inotify_add_watch", value: 254, isUnsigned: true)
!1203 = !DIEnumerator(name: "inotify_rm_watch", value: 255, isUnsigned: true)
!1204 = !DIEnumerator(name: "migrate_pages", value: 256, isUnsigned: true)
!1205 = !DIEnumerator(name: "openat", value: 257, isUnsigned: true)
!1206 = !DIEnumerator(name: "mkdirat", value: 258, isUnsigned: true)
!1207 = !DIEnumerator(name: "mknodat", value: 259, isUnsigned: true)
!1208 = !DIEnumerator(name: "fchownat", value: 260, isUnsigned: true)
!1209 = !DIEnumerator(name: "futimesat", value: 261, isUnsigned: true)
!1210 = !DIEnumerator(name: "fstatat64", value: 262, isUnsigned: true)
!1211 = !DIEnumerator(name: "unlinkat", value: 263, isUnsigned: true)
!1212 = !DIEnumerator(name: "renameat", value: 264, isUnsigned: true)
!1213 = !DIEnumerator(name: "linkat", value: 265, isUnsigned: true)
!1214 = !DIEnumerator(name: "symlinkat", value: 266, isUnsigned: true)
!1215 = !DIEnumerator(name: "readlinkat", value: 267, isUnsigned: true)
!1216 = !DIEnumerator(name: "fchmodat", value: 268, isUnsigned: true)
!1217 = !DIEnumerator(name: "faccessat", value: 269, isUnsigned: true)
!1218 = !DIEnumerator(name: "pselect6", value: 270, isUnsigned: true)
!1219 = !DIEnumerator(name: "ppoll", value: 271, isUnsigned: true)
!1220 = !DIEnumerator(name: "unshare", value: 272, isUnsigned: true)
!1221 = !DIEnumerator(name: "set_robust_list", value: 273, isUnsigned: true)
!1222 = !DIEnumerator(name: "get_robust_list", value: 274, isUnsigned: true)
!1223 = !DIEnumerator(name: "splice", value: 275, isUnsigned: true)
!1224 = !DIEnumerator(name: "tee", value: 276, isUnsigned: true)
!1225 = !DIEnumerator(name: "sync_file_range", value: 277, isUnsigned: true)
!1226 = !DIEnumerator(name: "vmsplice", value: 278, isUnsigned: true)
!1227 = !DIEnumerator(name: "move_pages", value: 279, isUnsigned: true)
!1228 = !DIEnumerator(name: "utimensat", value: 280, isUnsigned: true)
!1229 = !DIEnumerator(name: "epoll_pwait", value: 281, isUnsigned: true)
!1230 = !DIEnumerator(name: "signalfd", value: 282, isUnsigned: true)
!1231 = !DIEnumerator(name: "timerfd_create", value: 283, isUnsigned: true)
!1232 = !DIEnumerator(name: "eventfd", value: 284, isUnsigned: true)
!1233 = !DIEnumerator(name: "fallocate", value: 285, isUnsigned: true)
!1234 = !DIEnumerator(name: "timerfd_settime", value: 286, isUnsigned: true)
!1235 = !DIEnumerator(name: "timerfd_gettime", value: 287, isUnsigned: true)
!1236 = !DIEnumerator(name: "accept4", value: 288, isUnsigned: true)
!1237 = !DIEnumerator(name: "signalfd4", value: 289, isUnsigned: true)
!1238 = !DIEnumerator(name: "eventfd2", value: 290, isUnsigned: true)
!1239 = !DIEnumerator(name: "epoll_create1", value: 291, isUnsigned: true)
!1240 = !DIEnumerator(name: "dup3", value: 292, isUnsigned: true)
!1241 = !DIEnumerator(name: "pipe2", value: 293, isUnsigned: true)
!1242 = !DIEnumerator(name: "inotify_init1", value: 294, isUnsigned: true)
!1243 = !DIEnumerator(name: "preadv", value: 295, isUnsigned: true)
!1244 = !DIEnumerator(name: "pwritev", value: 296, isUnsigned: true)
!1245 = !DIEnumerator(name: "rt_tgsigqueueinfo", value: 297, isUnsigned: true)
!1246 = !DIEnumerator(name: "perf_event_open", value: 298, isUnsigned: true)
!1247 = !DIEnumerator(name: "recvmmsg", value: 299, isUnsigned: true)
!1248 = !DIEnumerator(name: "fanotify_init", value: 300, isUnsigned: true)
!1249 = !DIEnumerator(name: "fanotify_mark", value: 301, isUnsigned: true)
!1250 = !DIEnumerator(name: "prlimit64", value: 302, isUnsigned: true)
!1251 = !DIEnumerator(name: "name_to_handle_at", value: 303, isUnsigned: true)
!1252 = !DIEnumerator(name: "open_by_handle_at", value: 304, isUnsigned: true)
!1253 = !DIEnumerator(name: "clock_adjtime", value: 305, isUnsigned: true)
!1254 = !DIEnumerator(name: "syncfs", value: 306, isUnsigned: true)
!1255 = !DIEnumerator(name: "sendmmsg", value: 307, isUnsigned: true)
!1256 = !DIEnumerator(name: "setns", value: 308, isUnsigned: true)
!1257 = !DIEnumerator(name: "getcpu", value: 309, isUnsigned: true)
!1258 = !DIEnumerator(name: "process_vm_readv", value: 310, isUnsigned: true)
!1259 = !DIEnumerator(name: "process_vm_writev", value: 311, isUnsigned: true)
!1260 = !DIEnumerator(name: "kcmp", value: 312, isUnsigned: true)
!1261 = !DIEnumerator(name: "finit_module", value: 313, isUnsigned: true)
!1262 = !DIEnumerator(name: "sched_setattr", value: 314, isUnsigned: true)
!1263 = !DIEnumerator(name: "sched_getattr", value: 315, isUnsigned: true)
!1264 = !DIEnumerator(name: "renameat2", value: 316, isUnsigned: true)
!1265 = !DIEnumerator(name: "seccomp", value: 317, isUnsigned: true)
!1266 = !DIEnumerator(name: "getrandom", value: 318, isUnsigned: true)
!1267 = !DIEnumerator(name: "memfd_create", value: 319, isUnsigned: true)
!1268 = !DIEnumerator(name: "kexec_file_load", value: 320, isUnsigned: true)
!1269 = !DIEnumerator(name: "bpf", value: 321, isUnsigned: true)
!1270 = !DIEnumerator(name: "execveat", value: 322, isUnsigned: true)
!1271 = !DIEnumerator(name: "userfaultfd", value: 323, isUnsigned: true)
!1272 = !DIEnumerator(name: "membarrier", value: 324, isUnsigned: true)
!1273 = !DIEnumerator(name: "mlock2", value: 325, isUnsigned: true)
!1274 = !DIEnumerator(name: "copy_file_range", value: 326, isUnsigned: true)
!1275 = !DIEnumerator(name: "preadv2", value: 327, isUnsigned: true)
!1276 = !DIEnumerator(name: "pwritev2", value: 328, isUnsigned: true)
!1277 = !DIEnumerator(name: "pkey_mprotect", value: 329, isUnsigned: true)
!1278 = !DIEnumerator(name: "pkey_alloc", value: 330, isUnsigned: true)
!1279 = !DIEnumerator(name: "pkey_free", value: 331, isUnsigned: true)
!1280 = !DIEnumerator(name: "statx", value: 332, isUnsigned: true)
!1281 = !DIEnumerator(name: "io_pgetevents", value: 333, isUnsigned: true)
!1282 = !DIEnumerator(name: "rseq", value: 334, isUnsigned: true)
!1283 = !DIEnumerator(name: "pidfd_send_signal", value: 424, isUnsigned: true)
!1284 = !DIEnumerator(name: "io_uring_setup", value: 425, isUnsigned: true)
!1285 = !DIEnumerator(name: "io_uring_enter", value: 426, isUnsigned: true)
!1286 = !DIEnumerator(name: "io_uring_register", value: 427, isUnsigned: true)
!1287 = !DIEnumerator(name: "open_tree", value: 428, isUnsigned: true)
!1288 = !DIEnumerator(name: "move_mount", value: 429, isUnsigned: true)
!1289 = !DIEnumerator(name: "fsopen", value: 430, isUnsigned: true)
!1290 = !DIEnumerator(name: "fsconfig", value: 431, isUnsigned: true)
!1291 = !DIEnumerator(name: "fsmount", value: 432, isUnsigned: true)
!1292 = !DIEnumerator(name: "fspick", value: 433, isUnsigned: true)
!1293 = !DIEnumerator(name: "pidfd_open", value: 434, isUnsigned: true)
!1294 = !DIEnumerator(name: "clone3", value: 435, isUnsigned: true)
!1295 = !DIEnumerator(name: "close_range", value: 436, isUnsigned: true)
!1296 = !DIEnumerator(name: "openat2", value: 437, isUnsigned: true)
!1297 = !DIEnumerator(name: "pidfd_getfd", value: 438, isUnsigned: true)
!1298 = !DIEnumerator(name: "faccessat2", value: 439, isUnsigned: true)
!1299 = !DIEnumerator(name: "process_madvise", value: 440, isUnsigned: true)
!1300 = !DIEnumerator(name: "epoll_pwait2", value: 441, isUnsigned: true)
!1301 = !DIEnumerator(name: "mount_setattr", value: 442, isUnsigned: true)
!1302 = !DIEnumerator(name: "quotactl_fd", value: 443, isUnsigned: true)
!1303 = !DIEnumerator(name: "landlock_create_ruleset", value: 444, isUnsigned: true)
!1304 = !DIEnumerator(name: "landlock_add_rule", value: 445, isUnsigned: true)
!1305 = !DIEnumerator(name: "landlock_restrict_self", value: 446, isUnsigned: true)
!1306 = !DIEnumerator(name: "memfd_secret", value: 447, isUnsigned: true)
!1307 = !DIEnumerator(name: "process_mrelease", value: 448, isUnsigned: true)
!1308 = !DIEnumerator(name: "futex_waitv", value: 449, isUnsigned: true)
!1309 = !DIEnumerator(name: "set_mempolicy_home_node", value: 450, isUnsigned: true)
!1310 = !DIEnumerator(name: "cachestat", value: 451, isUnsigned: true)
!1311 = !DIEnumerator(name: "fchmodat2", value: 452, isUnsigned: true)
!1312 = !DIEnumerator(name: "map_shadow_stack", value: 453, isUnsigned: true)
!1313 = !DIEnumerator(name: "futex_wake", value: 454, isUnsigned: true)
!1314 = !DIEnumerator(name: "futex_wait", value: 455, isUnsigned: true)
!1315 = !DIEnumerator(name: "futex_requeue", value: 456, isUnsigned: true)
!1316 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "fs.File.Kind", scope: !915, file: !915, line: 42, baseType: !323, size: 8, align: 8, elements: !1317)
!1317 = !{!1318, !1319, !1320, !1321, !1322, !1323, !1324, !1325, !1326, !1327, !1328}
!1318 = !DIEnumerator(name: "block_device", value: 0, isUnsigned: true)
!1319 = !DIEnumerator(name: "character_device", value: 1, isUnsigned: true)
!1320 = !DIEnumerator(name: "directory", value: 2, isUnsigned: true)
!1321 = !DIEnumerator(name: "named_pipe", value: 3, isUnsigned: true)
!1322 = !DIEnumerator(name: "sym_link", value: 4, isUnsigned: true)
!1323 = !DIEnumerator(name: "file", value: 5, isUnsigned: true)
!1324 = !DIEnumerator(name: "unix_domain_socket", value: 6, isUnsigned: true)
!1325 = !DIEnumerator(name: "whiteout", value: 7, isUnsigned: true)
!1326 = !DIEnumerator(name: "door", value: 8, isUnsigned: true)
!1327 = !DIEnumerator(name: "event_port", value: 9, isUnsigned: true)
!1328 = !DIEnumerator(name: "unknown", value: 10, isUnsigned: true)
!1329 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "array_hash_map.CapacityIndexType", scope: !1330, file: !1330, line: 5883, baseType: !112, size: 8, align: 8, elements: !1331)
!1330 = !DIFile(filename: "array_hash_map.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!1331 = !{!1332, !1333, !1334}
!1332 = !DIEnumerator(name: "u8", value: 0, isUnsigned: true)
!1333 = !DIEnumerator(name: "u16", value: 1, isUnsigned: true)
!1334 = !DIEnumerator(name: "u32", value: 2, isUnsigned: true)
!1335 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "fmt.Case", scope: !687, file: !687, line: 2467, baseType: !260, size: 8, align: 8, elements: !1336)
!1336 = !{!1337, !1338}
!1337 = !DIEnumerator(name: "lower", value: 0, isUnsigned: true)
!1338 = !DIEnumerator(name: "upper", value: 1, isUnsigned: true)
!1339 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "sort.pdq.Hint", scope: !1340, file: !1340, line: 96, baseType: !112, size: 8, align: 8, elements: !1341)
!1340 = !DIFile(filename: "pdq.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/sort")
!1341 = !{!1342, !1343, !1344}
!1342 = !DIEnumerator(name: "increasing", value: 0, isUnsigned: true)
!1343 = !DIEnumerator(name: "decreasing", value: 1, isUnsigned: true)
!1344 = !DIEnumerator(name: "unknown", value: 2, isUnsigned: true)
!1345 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "dwarf.call_frame.Opcode", scope: !640, file: !640, line: 144, baseType: !34, size: 8, align: 8, elements: !1346)
!1346 = !{!1347, !1348, !1349, !1350, !1351, !1352, !1353, !1354, !1355, !1356, !1357, !1358, !1359, !1360, !1361, !1362, !1363, !1364, !1365, !1366, !1367, !1368, !1369, !1370, !1371, !1372}
!1347 = !DIEnumerator(name: "advance_loc", value: 64, isUnsigned: true)
!1348 = !DIEnumerator(name: "offset", value: 128, isUnsigned: true)
!1349 = !DIEnumerator(name: "restore", value: 192, isUnsigned: true)
!1350 = !DIEnumerator(name: "nop", value: 0, isUnsigned: true)
!1351 = !DIEnumerator(name: "set_loc", value: 1, isUnsigned: true)
!1352 = !DIEnumerator(name: "advance_loc1", value: 2, isUnsigned: true)
!1353 = !DIEnumerator(name: "advance_loc2", value: 3, isUnsigned: true)
!1354 = !DIEnumerator(name: "advance_loc4", value: 4, isUnsigned: true)
!1355 = !DIEnumerator(name: "offset_extended", value: 5, isUnsigned: true)
!1356 = !DIEnumerator(name: "restore_extended", value: 6, isUnsigned: true)
!1357 = !DIEnumerator(name: "undefined", value: 7, isUnsigned: true)
!1358 = !DIEnumerator(name: "same_value", value: 8, isUnsigned: true)
!1359 = !DIEnumerator(name: "register", value: 9, isUnsigned: true)
!1360 = !DIEnumerator(name: "remember_state", value: 10, isUnsigned: true)
!1361 = !DIEnumerator(name: "restore_state", value: 11, isUnsigned: true)
!1362 = !DIEnumerator(name: "def_cfa", value: 12, isUnsigned: true)
!1363 = !DIEnumerator(name: "def_cfa_register", value: 13, isUnsigned: true)
!1364 = !DIEnumerator(name: "def_cfa_offset", value: 14, isUnsigned: true)
!1365 = !DIEnumerator(name: "def_cfa_expression", value: 15, isUnsigned: true)
!1366 = !DIEnumerator(name: "expression", value: 16, isUnsigned: true)
!1367 = !DIEnumerator(name: "offset_extended_sf", value: 17, isUnsigned: true)
!1368 = !DIEnumerator(name: "def_cfa_sf", value: 18, isUnsigned: true)
!1369 = !DIEnumerator(name: "def_cfa_offset_sf", value: 19, isUnsigned: true)
!1370 = !DIEnumerator(name: "val_offset", value: 20, isUnsigned: true)
!1371 = !DIEnumerator(name: "val_offset_sf", value: 21, isUnsigned: true)
!1372 = !DIEnumerator(name: "val_expression", value: 22, isUnsigned: true)
!1373 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "math.Order", scope: !1374, file: !1374, line: 7831, baseType: !112, size: 8, align: 8, elements: !1375)
!1374 = !DIFile(filename: "math.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!1375 = !{!1376, !1377, !1378}
!1376 = !DIEnumerator(name: "gt", value: 0, isUnsigned: true)
!1377 = !DIEnumerator(name: "lt", value: 1, isUnsigned: true)
!1378 = !DIEnumerator(name: "eq", value: 2, isUnsigned: true)
!1379 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "@typeInfo(dwarf.expressions.StackMachine(.{ .addr_size = 8, .endian = .little, .call_frame_context = true }).Operand).Union.tag_type.?", scope: !1380, file: !663, line: 194, baseType: !323, size: 8, align: 8, elements: !1417)
!1380 = !DICompositeType(tag: DW_TAG_structure_type, name: "dwarf.expressions.StackMachine(.{ .addr_size = 8, .endian = .little, .call_frame_context = true }).Operand", scope: !2, size: 256, align: 64, elements: !1381)
!1381 = !{!1382, !1416}
!1382 = !DIDerivedType(tag: DW_TAG_member, name: "payload", scope: !1380, baseType: !1383, size: 192, align: 64)
!1383 = !DICompositeType(tag: DW_TAG_union_type, name: "dwarf.expressions.StackMachine(.{ .addr_size = 8, .endian = .little, .call_frame_context = true }).Operand:Payload", scope: !2, size: 256, align: 64, elements: !1384)
!1384 = !{!1385, !1386, !1387, !1388, !1390, !1395, !1400, !1401, !1406, !1411}
!1385 = !DIDerivedType(tag: DW_TAG_member, name: "generic", scope: !1383, baseType: !7, size: 64, align: 64)
!1386 = !DIDerivedType(tag: DW_TAG_member, name: "register", scope: !1383, baseType: !34, size: 8, align: 8)
!1387 = !DIDerivedType(tag: DW_TAG_member, name: "type_size", scope: !1383, baseType: !34, size: 8, align: 8)
!1388 = !DIDerivedType(tag: DW_TAG_member, name: "branch_offset", scope: !1383, baseType: !1389, size: 16, align: 16)
!1389 = !DIBasicType(name: "i16", size: 16, encoding: DW_ATE_signed)
!1390 = !DIDerivedType(tag: DW_TAG_member, name: "base_register", scope: !1383, baseType: !1391, size: 128, align: 64)
!1391 = !DICompositeType(tag: DW_TAG_structure_type, name: "dwarf.expressions.StackMachine(.{ .addr_size = 8, .endian = .little, .call_frame_context = true }).Operand.Operand__struct_8800", scope: !2, size: 128, align: 64, elements: !1392)
!1392 = !{!1393, !1394}
!1393 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !1391, baseType: !289, size: 64, align: 64)
!1394 = !DIDerivedType(tag: DW_TAG_member, name: "base_register", scope: !1391, baseType: !34, size: 8, align: 8, offset: 64)
!1395 = !DIDerivedType(tag: DW_TAG_member, name: "composite_location", scope: !1383, baseType: !1396, size: 128, align: 64)
!1396 = !DICompositeType(tag: DW_TAG_structure_type, name: "dwarf.expressions.StackMachine(.{ .addr_size = 8, .endian = .little, .call_frame_context = true }).Operand.Operand__struct_8801", scope: !2, size: 128, align: 64, elements: !1397)
!1397 = !{!1398, !1399}
!1398 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !1396, baseType: !7, size: 64, align: 64)
!1399 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !1396, baseType: !289, size: 64, align: 64, offset: 64)
!1400 = !DIDerivedType(tag: DW_TAG_member, name: "block", scope: !1383, baseType: !30, size: 128, align: 64)
!1401 = !DIDerivedType(tag: DW_TAG_member, name: "register_type", scope: !1383, baseType: !1402, size: 128, align: 64)
!1402 = !DICompositeType(tag: DW_TAG_structure_type, name: "dwarf.expressions.StackMachine(.{ .addr_size = 8, .endian = .little, .call_frame_context = true }).Operand.Operand__struct_8802", scope: !2, size: 128, align: 64, elements: !1403)
!1403 = !{!1404, !1405}
!1404 = !DIDerivedType(tag: DW_TAG_member, name: "type_offset", scope: !1402, baseType: !7, size: 64, align: 64)
!1405 = !DIDerivedType(tag: DW_TAG_member, name: "register", scope: !1402, baseType: !34, size: 8, align: 8, offset: 64)
!1406 = !DIDerivedType(tag: DW_TAG_member, name: "const_type", scope: !1383, baseType: !1407, size: 192, align: 64)
!1407 = !DICompositeType(tag: DW_TAG_structure_type, name: "dwarf.expressions.StackMachine(.{ .addr_size = 8, .endian = .little, .call_frame_context = true }).Operand.Operand__struct_8803", scope: !2, size: 192, align: 64, elements: !1408)
!1408 = !{!1409, !1410}
!1409 = !DIDerivedType(tag: DW_TAG_member, name: "type_offset", scope: !1407, baseType: !7, size: 64, align: 64)
!1410 = !DIDerivedType(tag: DW_TAG_member, name: "value_bytes", scope: !1407, baseType: !30, size: 128, align: 64, offset: 64)
!1411 = !DIDerivedType(tag: DW_TAG_member, name: "deref_type", scope: !1383, baseType: !1412, size: 128, align: 64)
!1412 = !DICompositeType(tag: DW_TAG_structure_type, name: "dwarf.expressions.StackMachine(.{ .addr_size = 8, .endian = .little, .call_frame_context = true }).Operand.Operand__struct_8804", scope: !2, size: 128, align: 64, elements: !1413)
!1413 = !{!1414, !1415}
!1414 = !DIDerivedType(tag: DW_TAG_member, name: "type_offset", scope: !1412, baseType: !7, size: 64, align: 64)
!1415 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !1412, baseType: !34, size: 8, align: 8, offset: 64)
!1416 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !1380, baseType: !1379, size: 8, align: 8, offset: 192)
!1417 = !{!1418, !1419, !1420, !1421, !1422, !1423, !1424, !1425, !1426, !1427}
!1418 = !DIEnumerator(name: "generic", value: 0, isUnsigned: true)
!1419 = !DIEnumerator(name: "register", value: 1, isUnsigned: true)
!1420 = !DIEnumerator(name: "type_size", value: 2, isUnsigned: true)
!1421 = !DIEnumerator(name: "branch_offset", value: 3, isUnsigned: true)
!1422 = !DIEnumerator(name: "base_register", value: 4, isUnsigned: true)
!1423 = !DIEnumerator(name: "composite_location", value: 5, isUnsigned: true)
!1424 = !DIEnumerator(name: "block", value: 6, isUnsigned: true)
!1425 = !DIEnumerator(name: "register_type", value: 7, isUnsigned: true)
!1426 = !DIEnumerator(name: "const_type", value: 8, isUnsigned: true)
!1427 = !DIEnumerator(name: "deref_type", value: 9, isUnsigned: true)
!1428 = !{!1429, !1432, !1434, !1437, !1439, !1442, !1444, !1450, !1452, !1454, !1456, !1458, !1460, !1462, !1464, !1477, !1479, !1481, !1486, !1488, !1491, !1502, !1504, !1507, !1509, !1512, !1518, !1520, !1522, !1524, !1528, !1533, !1535, !1537, !1539, !1541, !1543, !1545, !1551, !1553, !1555, !1557, !1566, !1575, !1577, !1609, !1615, !1617, !1621, !1627, !1631, !1633, !1635, !1638, !1656, !1662, !1665, !1671, !1673, !1676, !1682, !1688, !1690, !1696, !1702, !1707, !1713, !1715, !1717, !1719, !1729, !1732, !1738, !1740, !1742, !1744, !1750, !1768, !1771, !1774, !1776, !1779, !1781, !1783, !1785, !1788, !1790, !1792, !1798, !1800, !1802, !1805, !1808, !1814, !1817, !1820, !1828, !1835, !1838, !1840, !1842, !1846, !1848, !1850, !1852, !1854, !1856, !1858, !1860, !1862, !1864, !1866, !1868, !1874, !1878, !1880, !1893, !1903, !1905, !1909}
!1429 = !DIGlobalVariableExpression(var: !1430, expr: !DIExpression())
!1430 = distinct !DIGlobalVariable(name: "zig_backend", linkageName: "builtin.zig_backend", scope: !1431, file: !1431, line: 6, type: !5, isLocal: true, isDefinition: true)
!1431 = !DIFile(filename: "builtin.zig", directory: "/home/agent/.cache/zig/b/a7883daba9e3826ab2577dfa3dc5a9de")
!1432 = !DIGlobalVariableExpression(var: !1433, expr: !DIExpression())
!1433 = distinct !DIGlobalVariable(name: "empty", linkageName: "Target.Cpu.Feature.Set.empty", scope: !22, file: !22, line: 842, type: !39, isLocal: true, isDefinition: true)
!1434 = !DIGlobalVariableExpression(var: !1435, expr: !DIExpression())
!1435 = distinct !DIGlobalVariable(name: "znver4", linkageName: "Target.x86.cpu.znver4", scope: !1436, file: !1436, line: 4666, type: !27, isLocal: true, isDefinition: true)
!1436 = !DIFile(filename: "x86.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/Target")
!1437 = !DIGlobalVariableExpression(var: !1438, expr: !DIExpression())
!1438 = distinct !DIGlobalVariable(name: "cpu", linkageName: "builtin.cpu", scope: !1431, file: !1431, line: 13, type: !23, isLocal: true, isDefinition: true)
!1439 = !DIGlobalVariableExpression(var: !1440, expr: !DIExpression())
!1440 = distinct !DIGlobalVariable(name: "simplified_logic", linkageName: "start.simplified_logic", scope: !1441, file: !1441, line: 19, type: !292, isLocal: true, isDefinition: true)
!1441 = !DIFile(filename: "start.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!1442 = !DIGlobalVariableExpression(var: !1443, expr: !DIExpression())
!1443 = distinct !DIGlobalVariable(name: "output_mode", linkageName: "builtin.output_mode", scope: !1431, file: !1431, line: 8, type: !111, isLocal: true, isDefinition: true)
!1444 = !DIGlobalVariableExpression(var: !1445, expr: !DIExpression())
!1445 = distinct !DIGlobalVariable(name: "index_out_of_bounds", linkageName: "builtin.panic_messages.index_out_of_bounds", scope: !6, file: !6, line: 913, type: !1446, isLocal: true, isDefinition: true)
!1446 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[19:0]u8", baseType: !1447, size: 64, align: 8)
!1447 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 160, align: 8, elements: !1448)
!1448 = !{!1449}
!1449 = !DISubrange(count: 19, lowerBound: -2384)
!1450 = !DIGlobalVariableExpression(var: !1451, expr: !DIExpression())
!1451 = distinct !DIGlobalVariable(name: "os", linkageName: "builtin.os", scope: !1431, file: !1431, line: 95, type: !118, isLocal: true, isDefinition: true)
!1452 = !DIGlobalVariableExpression(var: !1453, expr: !DIExpression())
!1453 = distinct !DIGlobalVariable(name: "mode", linkageName: "builtin.mode", scope: !1431, file: !1431, line: 125, type: !236, isLocal: true, isDefinition: true)
!1454 = !DIGlobalVariableExpression(var: !1455, expr: !DIExpression())
!1455 = distinct !DIGlobalVariable(name: "runtime_safety", linkageName: "debug.runtime_safety", scope: !256, file: !256, line: 21, type: !292, isLocal: true, isDefinition: true)
!1456 = !DIGlobalVariableExpression(var: !1457, expr: !DIExpression())
!1457 = distinct !DIGlobalVariable(name: "native_os", linkageName: "debug.native_os", scope: !256, file: !256, line: 18, type: !156, isLocal: true, isDefinition: true)
!1458 = !DIGlobalVariableExpression(var: !1459, expr: !DIExpression())
!1459 = distinct !DIGlobalVariable(name: "have_segfault_handling_support", linkageName: "debug.have_segfault_handling_support", scope: !256, file: !256, line: 2517, type: !292, isLocal: true, isDefinition: true)
!1460 = !DIGlobalVariableExpression(var: !1461, expr: !DIExpression())
!1461 = distinct !DIGlobalVariable(name: "default_enable_segfault_handler", linkageName: "debug.default_enable_segfault_handler", scope: !256, file: !256, line: 2531, type: !292, isLocal: true, isDefinition: true)
!1462 = !DIGlobalVariableExpression(var: !1463, expr: !DIExpression())
!1463 = distinct !DIGlobalVariable(name: "default_level", linkageName: "log.default_level", scope: !243, file: !243, line: 102, type: !242, isLocal: true, isDefinition: true)
!1464 = !DIGlobalVariableExpression(var: !1465, expr: !DIExpression())
!1465 = distinct !DIGlobalVariable(name: "options", linkageName: "std.options", scope: !1466, file: !1466, line: 110, type: !1467, isLocal: true, isDefinition: true)
!1466 = !DIFile(filename: "std.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!1467 = !DICompositeType(tag: DW_TAG_structure_type, name: "std.Options", scope: !2, size: 128, align: 64, elements: !1468)
!1468 = !{!1469, !1470, !1471, !1472, !1473, !1474, !1475, !1476}
!1469 = !DIDerivedType(tag: DW_TAG_member, name: "fmt_max_depth", scope: !1467, baseType: !36, size: 64, align: 64)
!1470 = !DIDerivedType(tag: DW_TAG_member, name: "enable_segfault_handler", scope: !1467, baseType: !292, size: 8, align: 8, offset: 64)
!1471 = !DIDerivedType(tag: DW_TAG_member, name: "log_level", scope: !1467, baseType: !242, size: 8, align: 8, offset: 72)
!1472 = !DIDerivedType(tag: DW_TAG_member, name: "crypto_always_getrandom", scope: !1467, baseType: !292, size: 8, align: 8, offset: 80)
!1473 = !DIDerivedType(tag: DW_TAG_member, name: "crypto_fork_safety", scope: !1467, baseType: !292, size: 8, align: 8, offset: 88)
!1474 = !DIDerivedType(tag: DW_TAG_member, name: "keep_sigpipe", scope: !1467, baseType: !292, size: 8, align: 8, offset: 96)
!1475 = !DIDerivedType(tag: DW_TAG_member, name: "http_disable_tls", scope: !1467, baseType: !292, size: 8, align: 8, offset: 104)
!1476 = !DIDerivedType(tag: DW_TAG_member, name: "side_channels_mitigations", scope: !1467, baseType: !249, size: 8, align: 8, offset: 112)
!1477 = !DIGlobalVariableExpression(var: !1478, expr: !DIExpression())
!1478 = distinct !DIGlobalVariable(name: "enable_segfault_handler", linkageName: "debug.enable_segfault_handler", scope: !256, file: !256, line: 2530, type: !292, isLocal: true, isDefinition: true)
!1479 = !DIGlobalVariableExpression(var: !1480, expr: !DIExpression())
!1480 = distinct !DIGlobalVariable(name: "panic_stage", linkageName: "debug.panic_stage", scope: !256, file: !256, line: 455, type: !36, isLocal: true, isDefinition: true)
!1481 = !DIGlobalVariableExpression(var: !1482, expr: !DIExpression())
!1482 = distinct !DIGlobalVariable(name: "panicking", linkageName: "debug.panicking", scope: !256, file: !256, line: 448, type: !1483, isLocal: true, isDefinition: true)
!1483 = !DICompositeType(tag: DW_TAG_structure_type, name: "atomic.Value(u8)", scope: !2, size: 8, align: 8, elements: !1484)
!1484 = !{!1485}
!1485 = !DIDerivedType(tag: DW_TAG_member, name: "raw", scope: !1483, baseType: !34, size: 8, align: 8)
!1486 = !DIGlobalVariableExpression(var: !1487, expr: !DIExpression())
!1487 = distinct !DIGlobalVariable(name: "single_threaded", linkageName: "builtin.single_threaded", scope: !1431, file: !1431, line: 11, type: !292, isLocal: true, isDefinition: true)
!1488 = !DIGlobalVariableExpression(var: !1489, expr: !DIExpression())
!1489 = distinct !DIGlobalVariable(name: "unlocked", linkageName: "Thread.Mutex.FutexImpl.unlocked", scope: !1490, file: !1490, line: 158, type: !206, isLocal: true, isDefinition: true)
!1490 = !DIFile(filename: "Mutex.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/Thread")
!1491 = !DIGlobalVariableExpression(var: !1492, expr: !DIExpression())
!1492 = distinct !DIGlobalVariable(name: "panic_mutex", linkageName: "debug.panic_mutex", scope: !256, file: !256, line: 451, type: !1493, isLocal: true, isDefinition: true)
!1493 = !DICompositeType(tag: DW_TAG_structure_type, name: "Thread.Mutex", scope: !2, size: 32, align: 32, elements: !1494)
!1494 = !{!1495}
!1495 = !DIDerivedType(tag: DW_TAG_member, name: "impl", scope: !1493, baseType: !1496, size: 32, align: 32)
!1496 = !DICompositeType(tag: DW_TAG_structure_type, name: "Thread.Mutex.FutexImpl", scope: !2, size: 32, align: 32, elements: !1497)
!1497 = !{!1498}
!1498 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !1496, baseType: !1499, size: 32, align: 32)
!1499 = !DICompositeType(tag: DW_TAG_structure_type, name: "atomic.Value(u32)", scope: !2, size: 32, align: 32, elements: !1500)
!1500 = !{!1501}
!1501 = !DIDerivedType(tag: DW_TAG_member, name: "raw", scope: !1499, baseType: !206, size: 32, align: 32)
!1502 = !DIGlobalVariableExpression(var: !1503, expr: !DIExpression())
!1503 = distinct !DIGlobalVariable(name: "link_libc", linkageName: "builtin.link_libc", scope: !1431, file: !1431, line: 126, type: !292, isLocal: true, isDefinition: true)
!1504 = !DIGlobalVariableExpression(var: !1505, expr: !DIExpression())
!1505 = distinct !DIGlobalVariable(name: "native_os", linkageName: "posix.native_os", scope: !1506, file: !1506, line: 26, type: !156, isLocal: true, isDefinition: true)
!1506 = !DIFile(filename: "posix.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!1507 = !DIGlobalVariableExpression(var: !1508, expr: !DIExpression())
!1508 = distinct !DIGlobalVariable(name: "use_libc", linkageName: "posix.use_libc", scope: !1506, file: !1506, line: 33, type: !292, isLocal: true, isDefinition: true)
!1509 = !DIGlobalVariableExpression(var: !1510, expr: !DIExpression())
!1510 = distinct !DIGlobalVariable(name: "native_os", linkageName: "Thread.native_os", scope: !1511, file: !1511, line: 10, type: !156, isLocal: true, isDefinition: true)
!1511 = !DIFile(filename: "Thread.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!1512 = !DIGlobalVariableExpression(var: !1513, expr: !DIExpression())
!1513 = distinct !DIGlobalVariable(name: "invalid_error_code", linkageName: "builtin.panic_messages.invalid_error_code", scope: !6, file: !6, line: 898, type: !1514, isLocal: true, isDefinition: true)
!1514 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[18:0]u8", baseType: !1515, size: 64, align: 8)
!1515 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 152, align: 8, elements: !1516)
!1516 = !{!1517}
!1517 = !DISubrange(count: 18, lowerBound: -2384)
!1518 = !DIGlobalVariableExpression(var: !1519, expr: !DIExpression())
!1519 = distinct !DIGlobalVariable(name: "native_arch", linkageName: "os.linux.native_arch", scope: !705, file: !705, line: 15, type: !21, isLocal: true, isDefinition: true)
!1520 = !DIGlobalVariableExpression(var: !1521, expr: !DIExpression())
!1521 = distinct !DIGlobalVariable(name: "is_mips", linkageName: "os.linux.is_mips", scope: !705, file: !705, line: 17, type: !292, isLocal: true, isDefinition: true)
!1522 = !DIGlobalVariableExpression(var: !1523, expr: !DIExpression())
!1523 = distinct !DIGlobalVariable(name: "is_sparc", linkageName: "os.linux.is_sparc", scope: !705, file: !705, line: 20, type: !292, isLocal: true, isDefinition: true)
!1524 = !DIGlobalVariableExpression(var: !1525, expr: !DIExpression())
!1525 = distinct !DIGlobalVariable(name: "DFL", linkageName: "os.linux.SIG__struct_2936.DFL", scope: !705, file: !705, line: 3199, type: !1526, isLocal: true, isDefinition: true)
!1526 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*anyopaque", baseType: !1527, size: 64, align: 8)
!1527 = !DIBasicType(name: "anyopaque", encoding: DW_ATE_signed)
!1528 = !DIGlobalVariableExpression(var: !1529, expr: !DIExpression())
!1529 = distinct !DIGlobalVariable(name: "empty_sigset", linkageName: "os.linux.empty_sigset", scope: !705, file: !705, line: 4344, type: !1530, isLocal: true, isDefinition: true)
!1530 = !DICompositeType(tag: DW_TAG_array_type, baseType: !206, size: 1024, align: 32, elements: !1531)
!1531 = !{!1532}
!1532 = !DISubrange(count: 32, lowerBound: -2384)
!1533 = !DIGlobalVariableExpression(var: !1534, expr: !DIExpression())
!1534 = distinct !DIGlobalVariable(name: "empty_sigset", linkageName: "posix.empty_sigset", scope: !1506, file: !1506, line: 119, type: !1530, isLocal: true, isDefinition: true)
!1535 = !DIGlobalVariableExpression(var: !1536, expr: !DIExpression())
!1536 = distinct !DIGlobalVariable(name: "extern_getauxval", linkageName: "os.linux.extern_getauxval", scope: !705, file: !705, line: 389, type: !292, isLocal: true, isDefinition: true)
!1537 = !DIGlobalVariableExpression(var: !1538, expr: !DIExpression())
!1538 = distinct !DIGlobalVariable(name: "use_pthreads", linkageName: "Thread.use_pthreads", scope: !1511, file: !1511, line: 23, type: !292, isLocal: true, isDefinition: true)
!1539 = !DIGlobalVariableExpression(var: !1540, expr: !DIExpression())
!1540 = distinct !DIGlobalVariable(name: "incorrect_alignment", linkageName: "builtin.panic_messages.incorrect_alignment", scope: !6, file: !6, line: 897, type: !1446, isLocal: true, isDefinition: true)
!1541 = !DIGlobalVariableExpression(var: !1542, expr: !DIExpression())
!1542 = distinct !DIGlobalVariable(name: "all_mask", linkageName: "os.linux.all_mask", scope: !705, file: !705, line: 4300, type: !1530, isLocal: true, isDefinition: true)
!1543 = !DIGlobalVariableExpression(var: !1544, expr: !DIExpression())
!1544 = distinct !DIGlobalVariable(name: "abort_entered", linkageName: "posix.abort.global.abort_entered", scope: !1506, file: !1506, line: 662, type: !292, isLocal: true, isDefinition: true)
!1545 = !DIGlobalVariableExpression(var: !1546, expr: !DIExpression())
!1546 = distinct !DIGlobalVariable(name: "unwrap_error", linkageName: "builtin.panic_messages.unwrap_error", scope: !6, file: !6, line: 912, type: !1547, isLocal: true, isDefinition: true)
!1547 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[23:0]u8", baseType: !1548, size: 64, align: 8)
!1548 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 192, align: 8, elements: !1549)
!1549 = !{!1550}
!1550 = !DISubrange(count: 23, lowerBound: -2384)
!1551 = !DIGlobalVariableExpression(var: !1552, expr: !DIExpression())
!1552 = distinct !DIGlobalVariable(name: "corrupt_switch", linkageName: "builtin.panic_messages.corrupt_switch", scope: !6, file: !6, line: 908, type: !1547, isLocal: true, isDefinition: true)
!1553 = !DIGlobalVariableExpression(var: !1554, expr: !DIExpression())
!1554 = distinct !DIGlobalVariable(name: "abi", linkageName: "builtin.abi", scope: !1431, file: !1431, line: 12, type: !857, isLocal: true, isDefinition: true)
!1555 = !DIGlobalVariableExpression(var: !1556, expr: !DIExpression())
!1556 = distinct !DIGlobalVariable(name: "object_format", linkageName: "builtin.object_format", scope: !1431, file: !1431, line: 124, type: !900, isLocal: true, isDefinition: true)
!1557 = !DIGlobalVariableExpression(var: !1558, expr: !DIExpression())
!1558 = distinct !DIGlobalVariable(name: "none", linkageName: "Target.DynamicLinker.none", scope: !22, file: !22, line: 1669, type: !1559, isLocal: true, isDefinition: true)
!1559 = !DICompositeType(tag: DW_TAG_structure_type, name: "Target.DynamicLinker", scope: !2, size: 2048, align: 8, elements: !1560)
!1560 = !{!1561, !1565}
!1561 = !DIDerivedType(tag: DW_TAG_member, name: "buffer", scope: !1559, baseType: !1562, size: 2040, align: 8)
!1562 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 2040, align: 8, elements: !1563)
!1563 = !{!1564}
!1564 = !DISubrange(count: 255, lowerBound: -2384)
!1565 = !DIDerivedType(tag: DW_TAG_member, name: "len", scope: !1559, baseType: !34, size: 8, align: 8, offset: 2040)
!1566 = !DIGlobalVariableExpression(var: !1567, expr: !DIExpression())
!1567 = distinct !DIGlobalVariable(name: "target", linkageName: "builtin.target", scope: !1431, file: !1431, line: 117, type: !1568, isLocal: true, isDefinition: true)
!1568 = !DICompositeType(tag: DW_TAG_structure_type, name: "Target", scope: !2, size: 4032, align: 64, elements: !1569)
!1569 = !{!1570, !1571, !1572, !1573, !1574}
!1570 = !DIDerivedType(tag: DW_TAG_member, name: "cpu", scope: !1568, baseType: !23, size: 448, align: 64)
!1571 = !DIDerivedType(tag: DW_TAG_member, name: "os", scope: !1568, baseType: !118, size: 1472, align: 64, offset: 448)
!1572 = !DIDerivedType(tag: DW_TAG_member, name: "abi", scope: !1568, baseType: !857, size: 8, align: 8, offset: 1920)
!1573 = !DIDerivedType(tag: DW_TAG_member, name: "ofmt", scope: !1568, baseType: !900, size: 8, align: 8, offset: 1928)
!1574 = !DIDerivedType(tag: DW_TAG_member, name: "dynamic_linker", scope: !1568, baseType: !1559, size: 2048, align: 8, offset: 1936)
!1575 = !DIGlobalVariableExpression(var: !1576, expr: !DIExpression())
!1576 = distinct !DIGlobalVariable(name: "strip_debug_info", linkageName: "builtin.strip_debug_info", scope: !1431, file: !1431, line: 133, type: !292, isLocal: true, isDefinition: true)
!1577 = !DIGlobalVariableExpression(var: !1578, expr: !DIExpression())
!1578 = distinct !DIGlobalVariable(name: "self_debug_info", linkageName: "debug.self_debug_info", scope: !256, file: !256, line: 105, type: !1579, isLocal: true, isDefinition: true)
!1579 = !DICompositeType(tag: DW_TAG_structure_type, name: "?debug.DebugInfo", scope: !2, size: 512, align: 64, elements: !1580)
!1580 = !{!1581, !1608}
!1581 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !1579, baseType: !1582, size: 448, align: 64)
!1582 = !DICompositeType(tag: DW_TAG_structure_type, name: "debug.DebugInfo", scope: !2, size: 448, align: 64, elements: !1583)
!1583 = !{!1584, !1595}
!1584 = !DIDerivedType(tag: DW_TAG_member, name: "allocator", scope: !1582, baseType: !1585, size: 128, align: 64)
!1585 = !DICompositeType(tag: DW_TAG_structure_type, name: "mem.Allocator", scope: !2, size: 128, align: 64, elements: !1586)
!1586 = !{!1587, !1588}
!1587 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !1585, baseType: !1526, size: 64, align: 64)
!1588 = !DIDerivedType(tag: DW_TAG_member, name: "vtable", scope: !1585, baseType: !1589, size: 64, align: 64, offset: 64)
!1589 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*mem.Allocator.VTable", baseType: !1590, size: 64, align: 64)
!1590 = !DICompositeType(tag: DW_TAG_structure_type, name: "mem.Allocator.VTable", scope: !2, size: 192, align: 64, elements: !1591)
!1591 = !{!1592, !1593, !1594}
!1592 = !DIDerivedType(tag: DW_TAG_member, name: "alloc", scope: !1590, baseType: !1526, size: 64, align: 64)
!1593 = !DIDerivedType(tag: DW_TAG_member, name: "resize", scope: !1590, baseType: !1526, size: 64, align: 64, offset: 64)
!1594 = !DIDerivedType(tag: DW_TAG_member, name: "free", scope: !1590, baseType: !1526, size: 64, align: 64, offset: 128)
!1595 = !DIDerivedType(tag: DW_TAG_member, name: "address_map", scope: !1582, baseType: !1596, size: 320, align: 64, offset: 128)
!1596 = !DICompositeType(tag: DW_TAG_structure_type, name: "hash_map.HashMap(usize,*debug.ModuleDebugInfo__struct_3356,hash_map.AutoContext(usize),80)", scope: !2, size: 320, align: 64, elements: !1597)
!1597 = !{!1598, !1607}
!1598 = !DIDerivedType(tag: DW_TAG_member, name: "unmanaged", scope: !1596, baseType: !1599, size: 192, align: 64)
!1599 = !DICompositeType(tag: DW_TAG_structure_type, name: "hash_map.HashMapUnmanaged(usize,*debug.ModuleDebugInfo__struct_3356,hash_map.AutoContext(usize),80)", scope: !2, size: 192, align: 64, elements: !1600)
!1600 = !{!1601, !1604, !1605, !1606}
!1601 = !DIDerivedType(tag: DW_TAG_member, name: "metadata", scope: !1599, baseType: !1602, size: 64, align: 64)
!1602 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*hash_map.HashMapUnmanaged(usize,*debug.ModuleDebugInfo__struct_3356,hash_map.AutoContext(usize),80).Metadata", baseType: !1603, size: 64, align: 8)
!1603 = !DIBasicType(name: "hash_map.HashMapUnmanaged(usize,*debug.ModuleDebugInfo__struct_3356,hash_map.AutoContext(usize),80).Metadata", size: 8, encoding: DW_ATE_unsigned)
!1604 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !1599, baseType: !206, size: 32, align: 32, offset: 64)
!1605 = !DIDerivedType(tag: DW_TAG_member, name: "available", scope: !1599, baseType: !206, size: 32, align: 32, offset: 96)
!1606 = !DIDerivedType(tag: DW_TAG_member, name: "pointer_stability", scope: !1599, baseType: !257, size: 8, align: 8, offset: 128)
!1607 = !DIDerivedType(tag: DW_TAG_member, name: "allocator", scope: !1596, baseType: !1585, size: 128, align: 64, offset: 192)
!1608 = !DIDerivedType(tag: DW_TAG_member, name: "some", scope: !1579, baseType: !34, size: 8, align: 8, offset: 448)
!1609 = !DIGlobalVariableExpression(var: !1610, expr: !DIExpression())
!1610 = distinct !DIGlobalVariable(name: "unwrap_null", linkageName: "builtin.panic_messages.unwrap_null", scope: !6, file: !6, line: 895, type: !1611, isLocal: true, isDefinition: true)
!1611 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[25:0]u8", baseType: !1612, size: 64, align: 8)
!1612 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 208, align: 8, elements: !1613)
!1613 = !{!1614}
!1614 = !DISubrange(count: 25, lowerBound: -2384)
!1615 = !DIGlobalVariableExpression(var: !1616, expr: !DIExpression())
!1616 = distinct !DIGlobalVariable(name: "native_os", linkageName: "io.tty.native_os", scope: !632, file: !632, line: 6, type: !156, isLocal: true, isDefinition: true)
!1617 = !DIGlobalVariableExpression(var: !1618, expr: !DIExpression())
!1618 = distinct !DIGlobalVariable(name: "integer_overflow", linkageName: "builtin.panic_messages.integer_overflow", scope: !6, file: !6, line: 901, type: !1619, isLocal: true, isDefinition: true)
!1619 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[16:0]u8", baseType: !1620, size: 64, align: 8)
!1620 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 136, align: 8, elements: !286)
!1621 = !DIGlobalVariableExpression(var: !1622, expr: !DIExpression())
!1622 = distinct !DIGlobalVariable(name: "start_index_greater_than_end", linkageName: "builtin.panic_messages.start_index_greater_than_end", scope: !6, file: !6, line: 914, type: !1623, isLocal: true, isDefinition: true)
!1623 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[36:0]u8", baseType: !1624, size: 64, align: 8)
!1624 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 296, align: 8, elements: !1625)
!1625 = !{!1626}
!1626 = !DISubrange(count: 36, lowerBound: -2384)
!1627 = !DIGlobalVariableExpression(var: !1628, expr: !DIExpression())
!1628 = distinct !DIGlobalVariable(name: "cast_to_null", linkageName: "builtin.panic_messages.cast_to_null", scope: !6, file: !6, line: 896, type: !1629, isLocal: true, isDefinition: true)
!1629 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[30:0]u8", baseType: !1630, size: 64, align: 8)
!1630 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 248, align: 8, elements: !589)
!1631 = !DIGlobalVariableExpression(var: !1632, expr: !DIExpression())
!1632 = distinct !DIGlobalVariable(name: "native_arch", linkageName: "debug.native_arch", scope: !256, file: !256, line: 17, type: !21, isLocal: true, isDefinition: true)
!1633 = !DIGlobalVariableExpression(var: !1634, expr: !DIExpression())
!1634 = distinct !DIGlobalVariable(name: "native_endian", linkageName: "debug.native_endian", scope: !256, file: !256, line: 19, type: !264, isLocal: true, isDefinition: true)
!1635 = !DIGlobalVariableExpression(var: !1636, expr: !DIExpression())
!1636 = distinct !DIGlobalVariable(name: "native_endian", linkageName: "mem.native_endian", scope: !1637, file: !1637, line: 9, type: !264, isLocal: true, isDefinition: true)
!1637 = !DIFile(filename: "mem.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!1638 = !DIGlobalVariableExpression(var: !1639, expr: !DIExpression())
!1639 = distinct !DIGlobalVariable(name: "null_section_array", linkageName: "dwarf.DwarfInfo.null_section_array", scope: !269, file: !269, line: 604, type: !1640, isLocal: true, isDefinition: true)
!1640 = !DICompositeType(tag: DW_TAG_array_type, baseType: !1641, size: 5376, align: 64, elements: !1654)
!1641 = !DICompositeType(tag: DW_TAG_structure_type, name: "?dwarf.DwarfInfo.Section", scope: !2, size: 384, align: 64, elements: !1642)
!1642 = !{!1643, !1653}
!1643 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !1641, baseType: !1644, size: 320, align: 64)
!1644 = !DICompositeType(tag: DW_TAG_structure_type, name: "dwarf.DwarfInfo.Section", scope: !2, size: 320, align: 64, elements: !1645)
!1645 = !{!1646, !1647, !1652}
!1646 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !1644, baseType: !30, size: 128, align: 64)
!1647 = !DIDerivedType(tag: DW_TAG_member, name: "virtual_address", scope: !1644, baseType: !1648, size: 128, align: 64, offset: 128)
!1648 = !DICompositeType(tag: DW_TAG_structure_type, name: "?usize", scope: !2, size: 128, align: 64, elements: !1649)
!1649 = !{!1650, !1651}
!1650 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !1648, baseType: !36, size: 64, align: 64)
!1651 = !DIDerivedType(tag: DW_TAG_member, name: "some", scope: !1648, baseType: !34, size: 8, align: 8, offset: 64)
!1652 = !DIDerivedType(tag: DW_TAG_member, name: "owned", scope: !1644, baseType: !292, size: 8, align: 8, offset: 256)
!1653 = !DIDerivedType(tag: DW_TAG_member, name: "some", scope: !1641, baseType: !34, size: 8, align: 8, offset: 320)
!1654 = !{!1655}
!1655 = !DISubrange(count: 14, lowerBound: -2384)
!1656 = !DIGlobalVariableExpression(var: !1657, expr: !DIExpression())
!1657 = distinct !DIGlobalVariable(name: "MAGIC", linkageName: "elf.MAGIC", scope: !340, file: !340, line: 434, type: !1658, isLocal: true, isDefinition: true)
!1658 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[4:0]u8", baseType: !1659, size: 64, align: 8)
!1659 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 40, align: 8, elements: !1660)
!1660 = !{!1661}
!1661 = !DISubrange(count: 4, lowerBound: -2384)
!1662 = !DIGlobalVariableExpression(var: !1663, expr: !DIExpression())
!1663 = distinct !DIGlobalVariable(name: "native_os", linkageName: "fs.path.native_os", scope: !1664, file: !1664, line: 29, type: !156, isLocal: true, isDefinition: true)
!1664 = !DIFile(filename: "path.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/fs")
!1665 = !DIGlobalVariableExpression(var: !1666, expr: !DIExpression())
!1666 = distinct !DIGlobalVariable(name: "memcpy_len_mismatch", linkageName: "builtin.panic_messages.memcpy_len_mismatch", scope: !6, file: !6, line: 916, type: !1667, isLocal: true, isDefinition: true)
!1667 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[40:0]u8", baseType: !1668, size: 64, align: 8)
!1668 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 328, align: 8, elements: !1669)
!1669 = !{!1670}
!1670 = !DISubrange(count: 40, lowerBound: -2384)
!1671 = !DIGlobalVariableExpression(var: !1672, expr: !DIExpression())
!1672 = distinct !DIGlobalVariable(name: "memcpy_alias", linkageName: "builtin.panic_messages.memcpy_alias", scope: !6, file: !6, line: 917, type: !1547, isLocal: true, isDefinition: true)
!1673 = !DIGlobalVariableExpression(var: !1674, expr: !DIExpression())
!1674 = distinct !DIGlobalVariable(name: "native_os", linkageName: "fs.native_os", scope: !1675, file: !1675, line: 11, type: !156, isLocal: true, isDefinition: true)
!1675 = !DIFile(filename: "fs.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!1676 = !DIGlobalVariableExpression(var: !1677, expr: !DIExpression())
!1677 = distinct !DIGlobalVariable(name: "for_len_mismatch", linkageName: "builtin.panic_messages.for_len_mismatch", scope: !6, file: !6, line: 915, type: !1678, isLocal: true, isDefinition: true)
!1678 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[44:0]u8", baseType: !1679, size: 64, align: 8)
!1679 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 360, align: 8, elements: !1680)
!1680 = !{!1681}
!1681 = !DISubrange(count: 44, lowerBound: -2384)
!1682 = !DIGlobalVariableExpression(var: !1683, expr: !DIExpression())
!1683 = distinct !DIGlobalVariable(name: "unreach", linkageName: "builtin.panic_messages.unreach", scope: !6, file: !6, line: 894, type: !1684, isLocal: true, isDefinition: true)
!1684 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[24:0]u8", baseType: !1685, size: 64, align: 8)
!1685 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 200, align: 8, elements: !1686)
!1686 = !{!1687}
!1687 = !DISubrange(count: 24, lowerBound: -2384)
!1688 = !DIGlobalVariableExpression(var: !1689, expr: !DIExpression())
!1689 = distinct !DIGlobalVariable(name: "native_endian", linkageName: "dwarf.native_endian", scope: !269, file: !269, line: 9, type: !264, isLocal: true, isDefinition: true)
!1690 = !DIGlobalVariableExpression(var: !1691, expr: !DIExpression())
!1691 = distinct !DIGlobalVariable(name: "cast_truncated_data", linkageName: "builtin.panic_messages.cast_truncated_data", scope: !6, file: !6, line: 899, type: !1692, isLocal: true, isDefinition: true)
!1692 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[27:0]u8", baseType: !1693, size: 64, align: 8)
!1693 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 224, align: 8, elements: !1694)
!1694 = !{!1695}
!1695 = !DISubrange(count: 27, lowerBound: -2384)
!1696 = !DIGlobalVariableExpression(var: !1697, expr: !DIExpression())
!1697 = distinct !DIGlobalVariable(name: "negative_to_unsigned", linkageName: "builtin.panic_messages.negative_to_unsigned", scope: !6, file: !6, line: 900, type: !1698, isLocal: true, isDefinition: true)
!1698 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[50:0]u8", baseType: !1699, size: 64, align: 8)
!1699 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 408, align: 8, elements: !1700)
!1700 = !{!1701}
!1701 = !DISubrange(count: 50, lowerBound: -2384)
!1702 = !DIGlobalVariableExpression(var: !1703, expr: !DIExpression())
!1703 = distinct !DIGlobalVariable(name: "index_capacities", linkageName: "array_hash_map.index_capacities", scope: !1330, file: !1330, line: 1994, type: !1704, isLocal: true, isDefinition: true)
!1704 = !DICompositeType(tag: DW_TAG_array_type, baseType: !206, size: 1056, align: 32, elements: !1705)
!1705 = !{!1706}
!1706 = !DISubrange(count: 33, lowerBound: -2384)
!1707 = !DIGlobalVariableExpression(var: !1708, expr: !DIExpression())
!1708 = distinct !DIGlobalVariable(name: "sentinel_mismatch", linkageName: "builtin.panic_messages.sentinel_mismatch", scope: !6, file: !6, line: 911, type: !1709, isLocal: true, isDefinition: true)
!1709 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[17:0]u8", baseType: !1710, size: 64, align: 8)
!1710 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 144, align: 8, elements: !1711)
!1711 = !{!1712}
!1712 = !DISubrange(count: 17, lowerBound: -2384)
!1713 = !DIGlobalVariableExpression(var: !1714, expr: !DIExpression())
!1714 = distinct !DIGlobalVariable(name: "divide_by_zero", linkageName: "builtin.panic_messages.divide_by_zero", scope: !6, file: !6, line: 904, type: !1619, isLocal: true, isDefinition: true)
!1715 = !DIGlobalVariableExpression(var: !1716, expr: !DIExpression())
!1716 = distinct !DIGlobalVariable(name: "have_ucontext", linkageName: "debug.have_ucontext", scope: !256, file: !256, line: 204, type: !292, isLocal: true, isDefinition: true)
!1717 = !DIGlobalVariableExpression(var: !1718, expr: !DIExpression())
!1718 = distinct !DIGlobalVariable(name: "have_getcontext", linkageName: "debug.have_getcontext", scope: !256, file: !256, line: 240, type: !292, isLocal: true, isDefinition: true)
!1719 = !DIGlobalVariableExpression(var: !1720, expr: !DIExpression(DW_OP_constu, 0, DW_OP_stack_value))
!1720 = distinct !DIGlobalVariable(name: "elf_aux_maybe", linkageName: "os.linux.elf_aux_maybe", scope: !705, file: !705, line: 387, type: !1721, isLocal: true, isDefinition: true)
!1721 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*elf.Elf64_auxv_t", baseType: !1722, size: 64, align: 64)
!1722 = !DICompositeType(tag: DW_TAG_structure_type, name: "elf.Elf64_auxv_t", scope: !2, size: 128, align: 64, elements: !1723)
!1723 = !{!1724, !1725}
!1724 = !DIDerivedType(tag: DW_TAG_member, name: "a_type", scope: !1722, baseType: !7, size: 64, align: 64)
!1725 = !DIDerivedType(tag: DW_TAG_member, name: "a_un", scope: !1722, baseType: !1726, size: 64, align: 64, offset: 64)
!1726 = !DICompositeType(tag: DW_TAG_union_type, name: "elf.Elf64_auxv_t.Elf64_auxv_t__union_7502", scope: !2, size: 64, align: 64, elements: !1727)
!1727 = !{!1728}
!1728 = !DIDerivedType(tag: DW_TAG_member, name: "a_val", scope: !1726, baseType: !7, size: 64, align: 64)
!1729 = !DIGlobalVariableExpression(var: !1730, expr: !DIExpression())
!1730 = distinct !DIGlobalVariable(name: "is_windows", linkageName: "io.is_windows", scope: !1731, file: !1731, line: 5, type: !292, isLocal: true, isDefinition: true)
!1731 = !DIFile(filename: "io.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!1732 = !DIGlobalVariableExpression(var: !1733, expr: !DIExpression())
!1733 = distinct !DIGlobalVariable(name: "tls_thread_id", linkageName: "Thread.LinuxThreadImpl.tls_thread_id", scope: !1511, file: !1511, line: 1047, type: !1734, isLocal: true, isDefinition: true)
!1734 = !DICompositeType(tag: DW_TAG_structure_type, name: "?u32", scope: !2, size: 64, align: 32, elements: !1735)
!1735 = !{!1736, !1737}
!1736 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !1734, baseType: !206, size: 32, align: 32)
!1737 = !DIDerivedType(tag: DW_TAG_member, name: "some", scope: !1734, baseType: !34, size: 8, align: 8, offset: 32)
!1738 = !DIGlobalVariableExpression(var: !1739, expr: !DIExpression())
!1739 = distinct !DIGlobalVariable(name: "is_windows", linkageName: "fs.File.is_windows", scope: !915, file: !915, line: 1737, type: !292, isLocal: true, isDefinition: true)
!1740 = !DIGlobalVariableExpression(var: !1741, expr: !DIExpression())
!1741 = distinct !DIGlobalVariable(name: "max_format_args", linkageName: "fmt.max_format_args", scope: !687, file: !687, line: 388, type: !341, isLocal: true, isDefinition: true)
!1742 = !DIGlobalVariableExpression(var: !1743, expr: !DIExpression())
!1743 = distinct !DIGlobalVariable(name: "app_mask", linkageName: "os.linux.app_mask", scope: !705, file: !705, line: 4301, type: !1530, isLocal: true, isDefinition: true)
!1744 = !DIGlobalVariableExpression(var: !1745, expr: !DIExpression())
!1745 = distinct !DIGlobalVariable(name: "debug_info_allocator", linkageName: "debug.debug_info_allocator", scope: !256, file: !256, line: 2505, type: !1746, isLocal: true, isDefinition: true)
!1746 = !DICompositeType(tag: DW_TAG_structure_type, name: "?mem.Allocator", scope: !2, size: 192, align: 64, elements: !1747)
!1747 = !{!1748, !1749}
!1748 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !1746, baseType: !1585, size: 128, align: 64)
!1749 = !DIDerivedType(tag: DW_TAG_member, name: "some", scope: !1746, baseType: !34, size: 8, align: 8, offset: 128)
!1750 = !DIGlobalVariableExpression(var: !1751, expr: !DIExpression())
!1751 = distinct !DIGlobalVariable(name: "debug_info_arena_allocator", linkageName: "debug.debug_info_arena_allocator", scope: !256, file: !256, line: 2506, type: !1752, isLocal: true, isDefinition: true)
!1752 = !DICompositeType(tag: DW_TAG_structure_type, name: "heap.arena_allocator.ArenaAllocator", scope: !2, size: 256, align: 64, elements: !1753)
!1753 = !{!1754, !1755}
!1754 = !DIDerivedType(tag: DW_TAG_member, name: "child_allocator", scope: !1752, baseType: !1585, size: 128, align: 64)
!1755 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !1752, baseType: !1756, size: 128, align: 64, offset: 128)
!1756 = !DICompositeType(tag: DW_TAG_structure_type, name: "heap.arena_allocator.ArenaAllocator.State", scope: !2, size: 128, align: 64, elements: !1757)
!1757 = !{!1758, !1767}
!1758 = !DIDerivedType(tag: DW_TAG_member, name: "buffer_list", scope: !1756, baseType: !1759, size: 64, align: 64)
!1759 = !DICompositeType(tag: DW_TAG_structure_type, name: "linked_list.SinglyLinkedList(usize)", scope: !2, size: 64, align: 64, elements: !1760)
!1760 = !{!1761}
!1761 = !DIDerivedType(tag: DW_TAG_member, name: "first", scope: !1759, baseType: !1762, size: 64, align: 64)
!1762 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*linked_list.SinglyLinkedList(usize).Node", baseType: !1763, size: 64, align: 64)
!1763 = !DICompositeType(tag: DW_TAG_structure_type, name: "linked_list.SinglyLinkedList(usize).Node", scope: !2, size: 128, align: 64, elements: !1764)
!1764 = !{!1765, !1766}
!1765 = !DIDerivedType(tag: DW_TAG_member, name: "next", scope: !1763, baseType: !1762, size: 64, align: 64)
!1766 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !1763, baseType: !36, size: 64, align: 64, offset: 64)
!1767 = !DIDerivedType(tag: DW_TAG_member, name: "end_index", scope: !1756, baseType: !36, size: 64, align: 64, offset: 64)
!1768 = !DIGlobalVariableExpression(var: !1769, expr: !DIExpression())
!1769 = distinct !DIGlobalVariable(name: "vtable", linkageName: "heap.PageAllocator.vtable", scope: !1770, file: !1770, line: 11, type: !1590, isLocal: true, isDefinition: true)
!1770 = !DIFile(filename: "PageAllocator.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/heap")
!1771 = !DIGlobalVariableExpression(var: !1772, expr: !DIExpression())
!1772 = distinct !DIGlobalVariable(name: "page_allocator", linkageName: "heap.page_allocator", scope: !1773, file: !1773, line: 225, type: !1585, isLocal: true, isDefinition: true)
!1773 = !DIFile(filename: "heap.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!1774 = !DIGlobalVariableExpression(var: !1775, expr: !DIExpression())
!1775 = distinct !DIGlobalVariable(name: "backend_can_use_eql_bytes", linkageName: "mem.backend_can_use_eql_bytes", scope: !1637, file: !1637, line: 638, type: !292, isLocal: true, isDefinition: true)
!1776 = !DIGlobalVariableExpression(var: !1777, expr: !DIExpression())
!1777 = distinct !DIGlobalVariable(name: "native_os", linkageName: "fs.Dir.native_os", scope: !1778, file: !1778, line: 2702, type: !156, isLocal: true, isDefinition: true)
!1778 = !DIFile(filename: "Dir.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/fs")
!1779 = !DIGlobalVariableExpression(var: !1780, expr: !DIExpression())
!1780 = distinct !DIGlobalVariable(name: "lfs64_abi", linkageName: "posix.lfs64_abi", scope: !1506, file: !1506, line: 7294, type: !292, isLocal: true, isDefinition: true)
!1781 = !DIGlobalVariableExpression(var: !1782, expr: !DIExpression())
!1782 = distinct !DIGlobalVariable(name: "backend_supports_vectors", linkageName: "mem.backend_supports_vectors", scope: !1637, file: !1637, line: 1034, type: !292, isLocal: true, isDefinition: true)
!1783 = !DIGlobalVariableExpression(var: !1784, expr: !DIExpression())
!1784 = distinct !DIGlobalVariable(name: "valgrind_support", linkageName: "builtin.valgrind_support", scope: !1431, file: !1431, line: 129, type: !292, isLocal: true, isDefinition: true)
!1785 = !DIGlobalVariableExpression(var: !1786, expr: !DIExpression())
!1786 = distinct !DIGlobalVariable(name: "native_os", linkageName: "dwarf.abi.native_os", scope: !1787, file: !1787, line: 4, type: !156, isLocal: true, isDefinition: true)
!1787 = !DIFile(filename: "abi.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/dwarf")
!1788 = !DIGlobalVariableExpression(var: !1789, expr: !DIExpression())
!1789 = distinct !DIGlobalVariable(name: "contended", linkageName: "Thread.Mutex.FutexImpl.contended", scope: !1490, file: !1490, line: 160, type: !206, isLocal: true, isDefinition: true)
!1790 = !DIGlobalVariableExpression(var: !1791, expr: !DIExpression())
!1791 = distinct !DIGlobalVariable(name: "locked", linkageName: "Thread.Mutex.FutexImpl.locked", scope: !1490, file: !1490, line: 159, type: !206, isLocal: true, isDefinition: true)
!1792 = !DIGlobalVariableExpression(var: !1793, expr: !DIExpression())
!1793 = distinct !DIGlobalVariable(name: "ANY", linkageName: "fmt.ANY", scope: !687, file: !687, line: 443, type: !1794, isLocal: true, isDefinition: true)
!1794 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[3:0]u8", baseType: !1795, size: 64, align: 8)
!1795 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 32, align: 8, elements: !1796)
!1796 = !{!1797}
!1797 = !DISubrange(count: 3, lowerBound: -2384)
!1798 = !DIGlobalVariableExpression(var: !1799, expr: !DIExpression())
!1799 = distinct !DIGlobalVariable(name: "unexpected_error_tracing", linkageName: "posix.unexpected_error_tracing", scope: !1506, file: !1506, line: 7301, type: !292, isLocal: true, isDefinition: true)
!1800 = !DIGlobalVariableExpression(var: !1801, expr: !DIExpression())
!1801 = distinct !DIGlobalVariable(name: "native_os", linkageName: "heap.PageAllocator.native_os", scope: !1770, file: !1770, line: 7, type: !156, isLocal: true, isDefinition: true)
!1802 = !DIGlobalVariableExpression(var: !1803, expr: !DIExpression())
!1803 = distinct !DIGlobalVariable(name: "next_mmap_addr_hint", linkageName: "heap.next_mmap_addr_hint", scope: !1773, file: !1773, line: 33, type: !1804, isLocal: true, isDefinition: true)
!1804 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*align(4096) u8", baseType: !34, size: 64, align: 32768)
!1805 = !DIGlobalVariableExpression(var: !1806, expr: !DIExpression())
!1806 = distinct !DIGlobalVariable(name: "native_os", linkageName: "process.native_os", scope: !1807, file: !1807, line: 9, type: !156, isLocal: true, isDefinition: true)
!1807 = !DIFile(filename: "process.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!1808 = !DIGlobalVariableExpression(var: !1809, expr: !DIExpression())
!1809 = distinct !DIGlobalVariable(name: "lookup_table", linkageName: "hash.crc.impl.Crc(u32,.{ .polynomial = 79764919, .initial = 4294967295, .reflect_input = true, .reflect_output = true, .xor_output = 4294967295 }).lookup_table", scope: !1810, file: !1810, line: 24, type: !1811, isLocal: true, isDefinition: true)
!1810 = !DIFile(filename: "impl.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/hash/crc")
!1811 = !DICompositeType(tag: DW_TAG_array_type, baseType: !206, size: 8192, align: 32, elements: !1812)
!1812 = !{!1813}
!1813 = !DISubrange(count: 256, lowerBound: -2384)
!1814 = !DIGlobalVariableExpression(var: !1815, expr: !DIExpression())
!1815 = distinct !DIGlobalVariable(name: "native_endian", linkageName: "unicode.native_endian", scope: !1816, file: !1816, line: 6, type: !264, isLocal: true, isDefinition: true)
!1816 = !DIFile(filename: "unicode.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!1817 = !DIGlobalVariableExpression(var: !1818, expr: !DIExpression())
!1818 = distinct !DIGlobalVariable(name: "replacement_character", linkageName: "unicode.replacement_character", scope: !1816, file: !1816, line: 11, type: !1819, isLocal: true, isDefinition: true)
!1819 = !DIBasicType(name: "u21", size: 32, encoding: DW_ATE_unsigned)
!1820 = !DIGlobalVariableExpression(var: !1821, expr: !DIExpression())
!1821 = distinct !DIGlobalVariable(name: "environ", linkageName: "os.environ", scope: !1822, file: !1822, line: 46, type: !1823, isLocal: true, isDefinition: true)
!1822 = !DIFile(filename: "os.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!1823 = !DICompositeType(tag: DW_TAG_structure_type, name: "[][*:0]u8", scope: !2, size: 128, align: 64, elements: !1824)
!1824 = !{!1825, !1827}
!1825 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !1823, baseType: !1826, size: 64, align: 64)
!1826 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[*:0]u8", baseType: !33, size: 64, align: 64)
!1827 = !DIDerivedType(tag: DW_TAG_member, name: "len", scope: !1823, baseType: !36, size: 64, align: 64, offset: 64)
!1828 = !DIGlobalVariableExpression(var: !1829, expr: !DIExpression())
!1829 = distinct !DIGlobalVariable(name: "_DYNAMIC", linkageName: "_DYNAMIC", scope: !1830, file: !1830, line: 85, type: !1831, isLocal: true, isDefinition: true)
!1830 = !DIFile(filename: "dynamic_library.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!1831 = !DICompositeType(tag: DW_TAG_structure_type, name: "elf.Elf64_Dyn", scope: !2, size: 128, align: 64, elements: !1832)
!1832 = !{!1833, !1834}
!1833 = !DIDerivedType(tag: DW_TAG_member, name: "d_tag", scope: !1831, baseType: !289, size: 64, align: 64)
!1834 = !DIDerivedType(tag: DW_TAG_member, name: "d_val", scope: !1831, baseType: !7, size: 64, align: 64, offset: 64)
!1835 = !DIGlobalVariableExpression(var: !1836, expr: !DIExpression())
!1836 = distinct !DIGlobalVariable(name: "peek", linkageName: "compress.flate.bit_reader.BitReader(u32,io.GenericReader(*io.fixed_buffer_stream.FixedBufferStream([]const u8),error{},(function 'read'))).flag.peek", scope: !1837, file: !1837, line: 97, type: !228, isLocal: true, isDefinition: true)
!1837 = !DIFile(filename: "bit_reader.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/compress/flate")
!1838 = !DIGlobalVariableExpression(var: !1839, expr: !DIExpression())
!1839 = distinct !DIGlobalVariable(name: "buffered", linkageName: "compress.flate.bit_reader.BitReader(u32,io.GenericReader(*io.fixed_buffer_stream.FixedBufferStream([]const u8),error{},(function 'read'))).flag.buffered", scope: !1837, file: !1837, line: 98, type: !228, isLocal: true, isDefinition: true)
!1840 = !DIGlobalVariableExpression(var: !1841, expr: !DIExpression())
!1841 = distinct !DIGlobalVariable(name: "reverse", linkageName: "compress.flate.bit_reader.BitReader(u32,io.GenericReader(*io.fixed_buffer_stream.FixedBufferStream([]const u8),error{},(function 'read'))).flag.reverse", scope: !1837, file: !1837, line: 99, type: !228, isLocal: true, isDefinition: true)
!1842 = !DIGlobalVariableExpression(var: !1843, expr: !DIExpression())
!1843 = distinct !DIGlobalVariable(name: "codegen_order", linkageName: "compress.flate.consts.huffman.codegen_order", scope: !1844, file: !1844, line: 30, type: !1845, isLocal: true, isDefinition: true)
!1844 = !DIFile(filename: "consts.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/compress/flate")
!1845 = !DICompositeType(tag: DW_TAG_array_type, baseType: !206, size: 608, align: 32, elements: !1448)
!1846 = !DIGlobalVariableExpression(var: !1847, expr: !DIExpression())
!1847 = distinct !DIGlobalVariable(name: "codegen_order", linkageName: "compress.flate.inflate.codegen_order", scope: !538, file: !538, line: 10, type: !1845, isLocal: true, isDefinition: true)
!1848 = !DIGlobalVariableExpression(var: !1849, expr: !DIExpression())
!1849 = distinct !DIGlobalVariable(name: "empty_sentinel", linkageName: "array_hash_map.Index(u8).empty_sentinel", scope: !1330, file: !1330, line: 1966, type: !34, isLocal: true, isDefinition: true)
!1850 = !DIGlobalVariableExpression(var: !1851, expr: !DIExpression())
!1851 = distinct !DIGlobalVariable(name: "empty_sentinel", linkageName: "array_hash_map.Index(u16).empty_sentinel", scope: !1330, file: !1330, line: 1966, type: !341, isLocal: true, isDefinition: true)
!1852 = !DIGlobalVariableExpression(var: !1853, expr: !DIExpression())
!1853 = distinct !DIGlobalVariable(name: "empty_sentinel", linkageName: "array_hash_map.Index(u32).empty_sentinel", scope: !1330, file: !1330, line: 1966, type: !206, isLocal: true, isDefinition: true)
!1854 = !DIGlobalVariableExpression(var: !1855, expr: !DIExpression())
!1855 = distinct !DIGlobalVariable(name: "inactive_union_field", linkageName: "builtin.panic_messages.inactive_union_field", scope: !6, file: !6, line: 906, type: !1629, isLocal: true, isDefinition: true)
!1856 = !DIGlobalVariableExpression(var: !1857, expr: !DIExpression())
!1857 = distinct !DIGlobalVariable(name: "lo_inline", linkageName: "dwarf.call_frame.Opcode.lo_inline", scope: !640, file: !640, line: 42, type: !34, isLocal: true, isDefinition: true)
!1858 = !DIGlobalVariableExpression(var: !1859, expr: !DIExpression())
!1859 = distinct !DIGlobalVariable(name: "hi_inline", linkageName: "dwarf.call_frame.Opcode.hi_inline", scope: !640, file: !640, line: 43, type: !34, isLocal: true, isDefinition: true)
!1860 = !DIGlobalVariableExpression(var: !1861, expr: !DIExpression())
!1861 = distinct !DIGlobalVariable(name: "lo_reserved", linkageName: "dwarf.call_frame.Opcode.lo_reserved", scope: !640, file: !640, line: 46, type: !34, isLocal: true, isDefinition: true)
!1862 = !DIGlobalVariableExpression(var: !1863, expr: !DIExpression())
!1863 = distinct !DIGlobalVariable(name: "hi_reserved", linkageName: "dwarf.call_frame.Opcode.hi_reserved", scope: !640, file: !640, line: 47, type: !34, isLocal: true, isDefinition: true)
!1864 = !DIGlobalVariableExpression(var: !1865, expr: !DIExpression())
!1865 = distinct !DIGlobalVariable(name: "invalid_enum_value", linkageName: "builtin.panic_messages.invalid_enum_value", scope: !6, file: !6, line: 910, type: !1514, isLocal: true, isDefinition: true)
!1866 = !DIGlobalVariableExpression(var: !1867, expr: !DIExpression())
!1867 = distinct !DIGlobalVariable(name: "native_endian", linkageName: "dwarf.call_frame.native_endian", scope: !640, file: !640, line: 10, type: !264, isLocal: true, isDefinition: true)
!1868 = !DIGlobalVariableExpression(var: !1869, expr: !DIExpression())
!1869 = distinct !DIGlobalVariable(name: "shift_rhs_too_big", linkageName: "builtin.panic_messages.shift_rhs_too_big", scope: !6, file: !6, line: 909, type: !1870, isLocal: true, isDefinition: true)
!1870 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[42:0]u8", baseType: !1871, size: 64, align: 8)
!1871 = !DICompositeType(tag: DW_TAG_array_type, baseType: !34, size: 344, align: 8, elements: !1872)
!1872 = !{!1873}
!1873 = !DISubrange(count: 42, lowerBound: -2384)
!1874 = !DIGlobalVariableExpression(var: !1875, expr: !DIExpression())
!1875 = distinct !DIGlobalVariable(name: "free", linkageName: "hash_map.HashMapUnmanaged(usize,*debug.ModuleDebugInfo__struct_3356,hash_map.AutoContext(usize),80).Metadata.free", scope: !1876, file: !1876, line: 790, type: !1877, isLocal: true, isDefinition: true)
!1876 = !DIFile(filename: "hash_map.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std")
!1877 = !DIBasicType(name: "u7", size: 8, encoding: DW_ATE_unsigned)
!1878 = !DIGlobalVariableExpression(var: !1879, expr: !DIExpression())
!1879 = distinct !DIGlobalVariable(name: "slot_free", linkageName: "hash_map.HashMapUnmanaged(usize,*debug.ModuleDebugInfo__struct_3356,hash_map.AutoContext(usize),80).Metadata.slot_free", scope: !1876, file: !1876, line: 796, type: !34, isLocal: true, isDefinition: true)
!1880 = !DIGlobalVariableExpression(var: !1881, expr: !DIExpression())
!1881 = distinct !DIGlobalVariable(name: "match_lengths", linkageName: "compress.flate.Token.match_lengths", scope: !1882, file: !1882, line: 169, type: !1883, isLocal: true, isDefinition: true)
!1882 = !DIFile(filename: "Token.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/compress/flate")
!1883 = !DICompositeType(tag: DW_TAG_array_type, baseType: !1884, size: 1856, align: 16, elements: !1891)
!1884 = !DICompositeType(tag: DW_TAG_structure_type, name: "compress.flate.Token.MatchLength", scope: !2, size: 64, align: 16, elements: !1885)
!1885 = !{!1886, !1887, !1888, !1889, !1890}
!1886 = !DIDerivedType(tag: DW_TAG_member, name: "code", scope: !1884, baseType: !341, size: 16, align: 16)
!1887 = !DIDerivedType(tag: DW_TAG_member, name: "base", scope: !1884, baseType: !341, size: 16, align: 16, offset: 16)
!1888 = !DIDerivedType(tag: DW_TAG_member, name: "base_scaled", scope: !1884, baseType: !34, size: 8, align: 8, offset: 32)
!1889 = !DIDerivedType(tag: DW_TAG_member, name: "extra_length", scope: !1884, baseType: !34, size: 8, align: 8, offset: 40)
!1890 = !DIDerivedType(tag: DW_TAG_member, name: "extra_bits", scope: !1884, baseType: !323, size: 8, align: 8, offset: 48)
!1891 = !{!1892}
!1892 = !DISubrange(count: 29, lowerBound: -2384)
!1893 = !DIGlobalVariableExpression(var: !1894, expr: !DIExpression())
!1894 = distinct !DIGlobalVariable(name: "match_distances", linkageName: "compress.flate.Token.match_distances", scope: !1882, file: !1882, line: 245, type: !1895, isLocal: true, isDefinition: true)
!1895 = !DICompositeType(tag: DW_TAG_array_type, baseType: !1896, size: 1920, align: 16, elements: !589)
!1896 = !DICompositeType(tag: DW_TAG_structure_type, name: "compress.flate.Token.MatchDistance", scope: !2, size: 64, align: 16, elements: !1897)
!1897 = !{!1898, !1899, !1900, !1901, !1902}
!1898 = !DIDerivedType(tag: DW_TAG_member, name: "base_scaled", scope: !1896, baseType: !341, size: 16, align: 16)
!1899 = !DIDerivedType(tag: DW_TAG_member, name: "base", scope: !1896, baseType: !341, size: 16, align: 16, offset: 16)
!1900 = !DIDerivedType(tag: DW_TAG_member, name: "extra_distance", scope: !1896, baseType: !341, size: 16, align: 16, offset: 32)
!1901 = !DIDerivedType(tag: DW_TAG_member, name: "code", scope: !1896, baseType: !34, size: 8, align: 8, offset: 48)
!1902 = !DIDerivedType(tag: DW_TAG_member, name: "extra_bits", scope: !1896, baseType: !323, size: 8, align: 8, offset: 56)
!1903 = !DIGlobalVariableExpression(var: !1904, expr: !DIExpression())
!1904 = distinct !DIGlobalVariable(name: "is_ppc64", linkageName: "os.linux.is_ppc64", scope: !705, file: !705, line: 19, type: !292, isLocal: true, isDefinition: true)
!1905 = !DIGlobalVariableExpression(var: !1906, expr: !DIExpression())
!1906 = distinct !DIGlobalVariable(name: "secret", linkageName: "hash.wyhash.Wyhash.secret", scope: !1907, file: !1907, line: 4, type: !1908, isLocal: true, isDefinition: true)
!1907 = !DIFile(filename: "wyhash.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/hash")
!1908 = !DICompositeType(tag: DW_TAG_array_type, baseType: !7, size: 256, align: 64, elements: !1660)
!1909 = !DIGlobalVariableExpression(var: !1910, expr: !DIExpression())
!1910 = distinct !DIGlobalVariable(name: "native_endian", linkageName: "dwarf.expressions.native_endian", scope: !663, file: !663, line: 9, type: !264, isLocal: true, isDefinition: true)
!1911 = distinct !DISubprogram(name: "baseline", linkageName: "probe.baseline", scope: !1912, file: !1912, line: 2, type: !1913, scopeLine: 2, flags: DIFlagStaticMember, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1912 = !DIFile(filename: "probe.zig", directory: "<workspace>/site-tmp/edge-hoist")
!1913 = !DISubroutineType(types: !1914)
!1914 = !{!1915, !1916, !1916, !1919, !1923, !36}
!1915 = !DIBasicType(name: "void", encoding: DW_ATE_signed)
!1916 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[3]f32", baseType: !1917, size: 64, align: 32)
!1917 = !DICompositeType(tag: DW_TAG_array_type, baseType: !1918, size: 96, align: 32, elements: !1796)
!1918 = !DIBasicType(name: "f32", size: 32, encoding: DW_ATE_float)
!1919 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[6]u32", baseType: !1920, size: 64, align: 32)
!1920 = !DICompositeType(tag: DW_TAG_array_type, baseType: !206, size: 192, align: 32, elements: !1921)
!1921 = !{!1922}
!1922 = !DISubrange(count: 6, lowerBound: -2384)
!1923 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[6]f64", baseType: !1924, size: 64, align: 64)
!1924 = !DICompositeType(tag: DW_TAG_array_type, baseType: !1925, size: 384, align: 64, elements: !1921)
!1925 = !DIBasicType(name: "f64", size: 64, encoding: DW_ATE_float)
!1926 = !DILocalVariable(name: "points", arg: 1, scope: !1911, file: !1912, line: 2, type: !1916)
!1927 = !DILocation(line: 2, column: 121, scope: !1911)
!1928 = !DILocalVariable(name: "winds", arg: 2, scope: !1911, file: !1912, line: 2, type: !1916)
!1929 = !DILocalVariable(name: "neighbors", arg: 3, scope: !1911, file: !1912, line: 2, type: !1919)
!1930 = !DILocalVariable(name: "out", arg: 4, scope: !1911, file: !1912, line: 2, type: !1923)
!1931 = !DILocalVariable(name: "count", arg: 5, scope: !1911, file: !1912, line: 2, type: !36)
!1932 = !DILocation(line: 3, column: 6, scope: !1933)
!1933 = !DILexicalBlockFile(scope: !1934, file: !1912, discriminator: 4)
!1934 = !DILexicalBlock(scope: !1935, file: !1912, line: 3, column: 6)
!1935 = !DILexicalBlock(scope: !1936, file: !1912, line: 3, column: 6)
!1936 = !DILexicalBlock(scope: !1911, file: !1912, line: 3, column: 6)
!1937 = !DILocalVariable(name: "i", scope: !1938, file: !1912, line: 3, type: !36)
!1938 = !DILexicalBlock(scope: !1934, file: !1912, line: 3, column: 6)
!1939 = !DILocation(line: 3, column: 6, scope: !1938)
!1940 = !DILocation(line: 3, column: 32, scope: !1941)
!1941 = !DILexicalBlockFile(scope: !1938, file: !1912, discriminator: 8)
!1942 = !DILocation(line: 3, column: 36, scope: !1943)
!1943 = !DILexicalBlockFile(scope: !1944, file: !1912, discriminator: 14)
!1944 = !DILexicalBlock(scope: !1945, file: !1912, line: 3, column: 36)
!1945 = !DILexicalBlock(scope: !1946, file: !1912, line: 3, column: 36)
!1946 = !DILexicalBlock(scope: !1938, file: !1912, line: 3, column: 36)
!1947 = !DILocation(line: 3, column: 119, scope: !1948)
!1948 = !DILexicalBlockFile(scope: !1911, file: !1912, discriminator: 2)
!1949 = !DILocation(line: 3, column: 36, scope: !1950)
!1950 = !DILexicalBlockFile(scope: !1951, file: !1912, discriminator: 18)
!1951 = !DILexicalBlock(scope: !1944, file: !1912, line: 3, column: 36)
!1952 = !DILocalVariable(name: "n", scope: !1951, file: !1912, line: 3, type: !206)
!1953 = !DILocation(line: 3, column: 36, scope: !1951)
!1954 = !DILocalVariable(name: "j", scope: !1951, file: !1912, line: 3, type: !36)
!1955 = !DILocation(line: 3, column: 60, scope: !1950)
!1956 = !DILocalVariable(name: "a", scope: !1951, file: !1912, line: 3, type: !1917)
!1957 = !DILocation(line: 0, scope: !1951)
!1958 = !DILocation(line: 3, column: 78, scope: !1950)
!1959 = !DILocalVariable(name: "b", scope: !1951, file: !1912, line: 3, type: !1917)
!1960 = !DILocation(line: 3, column: 95, scope: !1950)
!1961 = !DILocalVariable(name: "w", scope: !1951, file: !1912, line: 3, type: !1917)
!1962 = !DILocation(line: 3, column: 105, scope: !1963)
!1963 = !DILexicalBlockFile(scope: !1951, file: !1912, discriminator: 22)
!1964 = !DILocation(line: 3, column: 133, scope: !1963)
!1965 = !DILocalVariable(name: "from", arg: 1, scope: !1966, file: !1967, line: 30, type: !1971)
!1966 = distinct !DISubprogram(name: "edgeRate", linkageName: "atmosphere_water.edgeRate", scope: !1967, file: !1967, line: 30, type: !1968, scopeLine: 30, flags: DIFlagStaticMember, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1967 = !DIFile(filename: "atmosphere_water.zig", directory: "<workspace>/site-tmp/edge-hoist")
!1968 = !DISubroutineType(types: !1969)
!1969 = !{!1925, !1970, !1970, !1970}
!1970 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*[3]f64", baseType: !1971, size: 64, align: 64)
!1971 = !DICompositeType(tag: DW_TAG_array_type, baseType: !1925, size: 192, align: 64, elements: !1796)
!1972 = !DILocation(line: 0, scope: !1966, inlinedAt: !1973)
!1973 = distinct !DILocation(line: 3, column: 119, scope: !1963)
!1974 = !DILocation(line: 3, column: 151, scope: !1963)
!1975 = !DILocalVariable(name: "to", arg: 2, scope: !1966, file: !1967, line: 30, type: !1971)
!1976 = !DILocation(line: 3, column: 169, scope: !1963)
!1977 = !DILocalVariable(name: "wind", arg: 3, scope: !1966, file: !1967, line: 30, type: !1971)
!1978 = !DILocalVariable(name: "length2", scope: !1966, file: !1967, line: 31, type: !1925)
!1979 = !DILocalVariable(name: "dot", scope: !1966, file: !1967, line: 31, type: !1925)
!1980 = !DILocalVariable(name: "i", scope: !1981, file: !1967, line: 32, type: !36)
!1981 = !DILexicalBlock(scope: !1982, file: !1967, line: 32, column: 6)
!1982 = !DILexicalBlock(scope: !1983, file: !1967, line: 32, column: 6)
!1983 = !DILexicalBlock(scope: !1984, file: !1967, line: 32, column: 6)
!1984 = !DILexicalBlock(scope: !1966, file: !1967, line: 32, column: 6)
!1985 = !DILocation(line: 32, column: 6, scope: !1981, inlinedAt: !1973)
!1986 = !DILocalVariable(name: "x", arg: 1, scope: !1987, file: !1988, line: 6, type: !1925)
!1987 = distinct !DISubprogram(name: "isFinite__anon_947", linkageName: "math.isfinite.isFinite__anon_947", scope: !1988, file: !1988, line: 6, type: !1989, scopeLine: 6, flags: DIFlagStaticMember, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1988 = !DIFile(filename: "isfinite.zig", directory: "<workspace>/stella-review-tools/zig-linux-x86_64-0.13.0/lib/std/math")
!1989 = !DISubroutineType(types: !1990)
!1990 = !{!292, !1925}
!1991 = !DILocation(line: 6, column: 34, scope: !1987, inlinedAt: !1992)
!1992 = distinct !DILocation(line: 32, column: 36, scope: !1993, inlinedAt: !1973)
!1993 = !DILexicalBlockFile(scope: !1994, file: !1967, discriminator: 12)
!1994 = !DILexicalBlock(scope: !1981, file: !1967, line: 32, column: 18)
!1995 = !DILocalVariable(name: "remove_sign", scope: !1987, file: !1988, line: 9, type: !7)
!1996 = !DILocation(line: 9, column: 40, scope: !1987, inlinedAt: !1992)
!1997 = !DILocation(line: 10, column: 5, scope: !1987, inlinedAt: !1992)
!1998 = !DILocation(line: 10, column: 80, scope: !1999, inlinedAt: !1992)
!1999 = !DILexicalBlockFile(scope: !1987, file: !1988, discriminator: 2)
!2000 = !DILocation(line: 32, column: 36, scope: !2001, inlinedAt: !1973)
!2001 = !DILexicalBlockFile(scope: !2002, file: !1967, discriminator: 12)
!2002 = !DILexicalBlock(scope: !1994, file: !1967, line: 32, column: 36)
!2003 = !DILocation(line: 6, column: 34, scope: !1987, inlinedAt: !2004)
!2004 = distinct !DILocation(line: 32, column: 67, scope: !2005, inlinedAt: !1973)
!2005 = !DILexicalBlockFile(scope: !2006, file: !1967, discriminator: 24)
!2006 = !DILexicalBlock(scope: !2002, file: !1967, line: 32, column: 36)
!2007 = !DILocation(line: 9, column: 40, scope: !1987, inlinedAt: !2004)
!2008 = !DILocation(line: 10, column: 5, scope: !1987, inlinedAt: !2004)
!2009 = !DILocation(line: 10, column: 80, scope: !1999, inlinedAt: !2004)
!2010 = !DILocation(line: 32, column: 67, scope: !2011, inlinedAt: !1973)
!2011 = !DILexicalBlockFile(scope: !2012, file: !1967, discriminator: 18)
!2012 = !DILexicalBlock(scope: !1994, file: !1967, line: 32, column: 67)
!2013 = !DILocation(line: 6, column: 34, scope: !1987, inlinedAt: !2014)
!2014 = distinct !DILocation(line: 32, column: 96, scope: !2015, inlinedAt: !1973)
!2015 = !DILexicalBlockFile(scope: !2016, file: !1967, discriminator: 36)
!2016 = !DILexicalBlock(scope: !2012, file: !1967, line: 32, column: 67)
!2017 = !DILocation(line: 9, column: 40, scope: !1987, inlinedAt: !2014)
!2018 = !DILocation(line: 10, column: 5, scope: !1987, inlinedAt: !2014)
!2019 = !DILocation(line: 10, column: 80, scope: !1999, inlinedAt: !2014)
!2020 = !DILocation(line: 32, column: 96, scope: !2021, inlinedAt: !1973)
!2021 = !DILexicalBlockFile(scope: !1994, file: !1967, discriminator: 30)
!2022 = !DILocation(line: 32, column: 125, scope: !2023, inlinedAt: !1973)
!2023 = !DILexicalBlockFile(scope: !1981, file: !1967, discriminator: 58)
!2024 = !DILocalVariable(name: "d", scope: !1966, file: !1967, line: 31, type: !1971)
!2025 = !DILocation(line: 32, column: 147, scope: !2026, inlinedAt: !1973)
!2026 = !DILexicalBlockFile(scope: !1981, file: !1967, discriminator: 198)
!2027 = !DILocation(line: 32, column: 165, scope: !2028, inlinedAt: !1973)
!2028 = !DILexicalBlockFile(scope: !1981, file: !1967, discriminator: 210)
!2029 = !DILocation(line: 32, column: 156, scope: !2028, inlinedAt: !1973)
!2030 = !DILocation(line: 32, column: 141, scope: !2026, inlinedAt: !1973)
!2031 = !DILocation(line: 33, column: 5, scope: !2032, inlinedAt: !1973)
!2032 = !DILexicalBlock(scope: !1966, file: !1967, line: 33, column: 5)
!2033 = !DILocation(line: 33, column: 5, scope: !2034, inlinedAt: !1973)
!2034 = !DILexicalBlock(scope: !2032, file: !1967, line: 33, column: 5)
!2035 = !DILocation(line: 6, column: 34, scope: !1987, inlinedAt: !2036)
!2036 = distinct !DILocation(line: 33, column: 37, scope: !2037, inlinedAt: !1973)
!2037 = !DILexicalBlockFile(scope: !2038, file: !1967, discriminator: 6)
!2038 = !DILexicalBlock(scope: !2034, file: !1967, line: 33, column: 5)
!2039 = !DILocation(line: 9, column: 40, scope: !1987, inlinedAt: !2036)
!2040 = !DILocation(line: 10, column: 5, scope: !1987, inlinedAt: !2036)
!2041 = !DILocation(line: 10, column: 80, scope: !1999, inlinedAt: !2036)
!2042 = !DILocation(line: 33, column: 37, scope: !2043, inlinedAt: !1973)
!2043 = !DILexicalBlockFile(scope: !2044, file: !1967, discriminator: 2)
!2044 = !DILexicalBlock(scope: !2032, file: !1967, line: 33, column: 37)
!2045 = !DILocation(line: 6, column: 34, scope: !1987, inlinedAt: !2046)
!2046 = distinct !DILocation(line: 33, column: 68, scope: !2047, inlinedAt: !1973)
!2047 = !DILexicalBlockFile(scope: !2048, file: !1967, discriminator: 12)
!2048 = !DILexicalBlock(scope: !2044, file: !1967, line: 33, column: 37)
!2049 = !DILocation(line: 9, column: 40, scope: !1987, inlinedAt: !2046)
!2050 = !DILocation(line: 10, column: 5, scope: !1987, inlinedAt: !2046)
!2051 = !DILocation(line: 10, column: 80, scope: !1999, inlinedAt: !2046)
!2052 = !DILocation(line: 33, column: 68, scope: !2053, inlinedAt: !1973)
!2053 = !DILexicalBlockFile(scope: !2032, file: !1967, discriminator: 8)
!2054 = !DILocation(line: 35, column: 19, scope: !1966, inlinedAt: !1973)
!2055 = !DILocation(line: 3, column: 119, scope: !1963)
!2056 = !DILocation(line: 3, column: 119, scope: !2057)
!2057 = !DILexicalBlockFile(scope: !1945, file: !1912, discriminator: 16)
!2058 = !DILocation(line: 3, column: 119, scope: !2059)
!2059 = !DILexicalBlockFile(scope: !1935, file: !1912, discriminator: 6)
!2060 = distinct !DISubprogram(name: "candidate", linkageName: "probe.candidate", scope: !1912, file: !1912, line: 5, type: !1913, scopeLine: 5, flags: DIFlagStaticMember, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!2061 = !DILocalVariable(name: "points", arg: 1, scope: !2060, file: !1912, line: 5, type: !1916)
!2062 = !DILocation(line: 5, column: 122, scope: !2060)
!2063 = !DILocalVariable(name: "winds", arg: 2, scope: !2060, file: !1912, line: 5, type: !1916)
!2064 = !DILocalVariable(name: "neighbors", arg: 3, scope: !2060, file: !1912, line: 5, type: !1919)
!2065 = !DILocalVariable(name: "out", arg: 4, scope: !2060, file: !1912, line: 5, type: !1923)
!2066 = !DILocalVariable(name: "count", arg: 5, scope: !2060, file: !1912, line: 5, type: !36)
!2067 = !DILocation(line: 6, column: 6, scope: !2068)
!2068 = !DILexicalBlockFile(scope: !2069, file: !1912, discriminator: 2)
!2069 = !DILexicalBlock(scope: !2070, file: !1912, line: 6, column: 6)
!2070 = !DILexicalBlock(scope: !2071, file: !1912, line: 6, column: 6)
!2071 = !DILexicalBlock(scope: !2060, file: !1912, line: 6, column: 6)
!2072 = !DILocalVariable(name: "i", scope: !2073, file: !1912, line: 6, type: !36)
!2073 = !DILexicalBlock(scope: !2069, file: !1912, line: 6, column: 6)
!2074 = !DILocation(line: 6, column: 6, scope: !2073)
!2075 = !DILocation(line: 6, column: 33, scope: !2076)
!2076 = !DILexicalBlockFile(scope: !2073, file: !1912, discriminator: 4)
!2077 = !DILocalVariable(name: "a", scope: !2073, file: !1912, line: 6, type: !1917)
!2078 = !DILocation(line: 0, scope: !2073)
!2079 = !DILocation(line: 6, column: 50, scope: !2076)
!2080 = !DILocalVariable(name: "w", scope: !2073, file: !1912, line: 6, type: !1917)
!2081 = !DILocalVariable(name: "valid", scope: !2073, file: !1912, line: 6, type: !292)
!2082 = !DILocalVariable(name: "k", scope: !2083, file: !1912, line: 6, type: !36)
!2083 = !DILexicalBlock(scope: !2084, file: !1912, line: 6, column: 73)
!2084 = !DILexicalBlock(scope: !2085, file: !1912, line: 6, column: 73)
!2085 = !DILexicalBlock(scope: !2086, file: !1912, line: 6, column: 73)
!2086 = !DILexicalBlock(scope: !2073, file: !1912, line: 6, column: 73)
!2087 = !DILocation(line: 6, column: 73, scope: !2083)
!2088 = !DILocalVariable(name: "x", arg: 1, scope: !2089, file: !1988, line: 6, type: !1918)
!2089 = distinct !DISubprogram(name: "isFinite__anon_946", linkageName: "math.isfinite.isFinite__anon_946", scope: !1988, file: !1988, line: 6, type: !2090, scopeLine: 6, flags: DIFlagStaticMember, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!2090 = !DISubroutineType(types: !2091)
!2091 = !{!292, !1918}
!2092 = !DILocation(line: 6, column: 34, scope: !2089, inlinedAt: !2093)
!2093 = distinct !DILocation(line: 6, column: 103, scope: !2094)
!2094 = !DILexicalBlockFile(scope: !2095, file: !1912, discriminator: 18)
!2095 = !DILexicalBlock(scope: !2083, file: !1912, line: 6, column: 85)
!2096 = !DILocalVariable(name: "remove_sign", scope: !2089, file: !1988, line: 9, type: !206)
!2097 = !DILocation(line: 9, column: 40, scope: !2089, inlinedAt: !2093)
!2098 = !DILocation(line: 10, column: 5, scope: !2089, inlinedAt: !2093)
!2099 = !DILocation(line: 10, column: 80, scope: !2100, inlinedAt: !2093)
!2100 = !DILexicalBlockFile(scope: !2089, file: !1988, discriminator: 2)
!2101 = !DILocation(line: 6, column: 103, scope: !2102)
!2102 = !DILexicalBlockFile(scope: !2103, file: !1912, discriminator: 18)
!2103 = !DILexicalBlock(scope: !2095, file: !1912, line: 6, column: 103)
!2104 = !DILocation(line: 9, column: 116, scope: !2060)
!2105 = !DILocation(line: 7, column: 46, scope: !2106)
!2106 = !DILexicalBlockFile(scope: !2107, file: !1912, discriminator: 12)
!2107 = !DILexicalBlock(scope: !2108, file: !1912, line: 7, column: 32)
!2108 = !DILexicalBlock(scope: !2109, file: !1912, line: 7, column: 32)
!2109 = !DILexicalBlock(scope: !2110, file: !1912, line: 7, column: 19)
!2110 = !DILexicalBlock(scope: !2111, file: !1912, line: 7, column: 19)
!2111 = !DILexicalBlock(scope: !2112, file: !1912, line: 7, column: 19)
!2112 = !DILexicalBlock(scope: !2073, file: !1912, line: 7, column: 19)
!2113 = !DILocalVariable(name: "n", scope: !2109, file: !1912, line: 7, type: !206)
!2114 = !DILocation(line: 7, column: 19, scope: !2109)
!2115 = !DILocalVariable(name: "j", scope: !2109, file: !1912, line: 7, type: !36)
!2116 = !DILocation(line: 9, column: 116, scope: !2117)
!2117 = !DILexicalBlockFile(scope: !2070, file: !1912, discriminator: 2)
!2118 = !DILocation(line: 7, column: 76, scope: !2119)
!2119 = !DILexicalBlockFile(scope: !2109, file: !1912, discriminator: 6)
!2120 = !DILocalVariable(name: "b", scope: !2109, file: !1912, line: 7, type: !1917)
!2121 = !DILocation(line: 0, scope: !2109)
!2122 = !DILocalVariable(name: "dest_valid", scope: !2109, file: !1912, line: 7, type: !292)
!2123 = !DILocalVariable(name: "length2", scope: !2109, file: !1912, line: 7, type: !1925)
!2124 = !DILocalVariable(name: "dot", scope: !2109, file: !1912, line: 7, type: !1925)
!2125 = !DILocalVariable(name: "k", scope: !2126, file: !1912, line: 8, type: !36)
!2126 = !DILexicalBlock(scope: !2127, file: !1912, line: 8, column: 6)
!2127 = !DILexicalBlock(scope: !2128, file: !1912, line: 8, column: 6)
!2128 = !DILexicalBlock(scope: !2129, file: !1912, line: 8, column: 6)
!2129 = !DILexicalBlock(scope: !2109, file: !1912, line: 8, column: 6)
!2130 = !DILocation(line: 8, column: 6, scope: !2126)
!2131 = !DILocation(line: 6, column: 34, scope: !2089, inlinedAt: !2132)
!2132 = distinct !DILocation(line: 8, column: 36, scope: !2133)
!2133 = !DILexicalBlockFile(scope: !2134, file: !1912, discriminator: 12)
!2134 = !DILexicalBlock(scope: !2126, file: !1912, line: 8, column: 18)
!2135 = !DILocation(line: 9, column: 40, scope: !2089, inlinedAt: !2132)
!2136 = !DILocation(line: 10, column: 5, scope: !2089, inlinedAt: !2132)
!2137 = !DILocation(line: 10, column: 80, scope: !2100, inlinedAt: !2132)
!2138 = !DILocation(line: 8, column: 36, scope: !2133)
!2139 = !DILocation(line: 8, column: 85, scope: !2140)
!2140 = !DILexicalBlockFile(scope: !2126, file: !1912, discriminator: 22)
!2141 = !DILocalVariable(name: "d", scope: !2126, file: !1912, line: 8, type: !1925)
!2142 = !DILocation(line: 8, column: 89, scope: !2126)
!2143 = !DILocation(line: 8, column: 89, scope: !2144)
!2144 = !DILexicalBlockFile(scope: !2126, file: !1912, discriminator: 28)
!2145 = !DILocation(line: 8, column: 126, scope: !2146)
!2146 = !DILexicalBlockFile(scope: !2126, file: !1912, discriminator: 34)
!2147 = !DILocation(line: 8, column: 111, scope: !2146)
!2148 = !DILocation(line: 8, column: 105, scope: !2144)
!2149 = !DILocation(line: 8, column: 102, scope: !2144)
!2150 = !DILocation(line: 9, column: 15, scope: !2151)
!2151 = !DILexicalBlockFile(scope: !2152, file: !1912, discriminator: 14)
!2152 = !DILexicalBlock(scope: !2153, file: !1912, line: 9, column: 15)
!2153 = !DILexicalBlock(scope: !2109, file: !1912, line: 9, column: 8)
!2154 = !DILocation(line: 6, column: 34, scope: !1987, inlinedAt: !2155)
!2155 = distinct !DILocation(line: 9, column: 62, scope: !2156)
!2156 = !DILexicalBlockFile(scope: !2157, file: !1912, discriminator: 32)
!2157 = !DILexicalBlock(scope: !2152, file: !1912, line: 9, column: 15)
!2158 = !DILocation(line: 9, column: 40, scope: !1987, inlinedAt: !2155)
!2159 = !DILocation(line: 10, column: 5, scope: !1987, inlinedAt: !2155)
!2160 = !DILocation(line: 10, column: 80, scope: !1999, inlinedAt: !2155)
!2161 = !DILocation(line: 9, column: 62, scope: !2162)
!2162 = !DILexicalBlockFile(scope: !2163, file: !1912, discriminator: 28)
!2163 = !DILexicalBlock(scope: !2153, file: !1912, line: 9, column: 62)
!2164 = !DILocation(line: 6, column: 34, scope: !1987, inlinedAt: !2165)
!2165 = distinct !DILocation(line: 9, column: 93, scope: !2166)
!2166 = !DILexicalBlockFile(scope: !2167, file: !1912, discriminator: 38)
!2167 = !DILexicalBlock(scope: !2163, file: !1912, line: 9, column: 62)
!2168 = !DILocation(line: 9, column: 40, scope: !1987, inlinedAt: !2165)
!2169 = !DILocation(line: 10, column: 5, scope: !1987, inlinedAt: !2165)
!2170 = !DILocation(line: 10, column: 80, scope: !1999, inlinedAt: !2165)
!2171 = !DILocation(line: 9, column: 93, scope: !2172)
!2172 = !DILexicalBlockFile(scope: !2153, file: !1912, discriminator: 34)
!2173 = !DILocation(line: 9, column: 116, scope: !2174)
!2174 = !DILexicalBlockFile(scope: !2175, file: !1912, discriminator: 42)
!2175 = !DILexicalBlock(scope: !2153, file: !1912, line: 9, column: 93)
!2176 = !DILocation(line: 9, column: 116, scope: !2175)
!2177 = !DILocation(line: 9, column: 116, scope: !2178)
!2178 = !DILexicalBlockFile(scope: !2109, file: !1912, discriminator: 20)
!2179 = !DILocation(line: 9, column: 8, scope: !2180)
!2180 = !DILexicalBlockFile(scope: !2109, file: !1912, discriminator: 14)
!2181 = !DILocation(line: 6, column: 34, scope: !2089, inlinedAt: !2182)
!2182 = distinct !DILocation(line: 6, column: 131, scope: !2183)
!2183 = !DILexicalBlockFile(scope: !2184, file: !1912, discriminator: 30)
!2184 = !DILexicalBlock(scope: !2103, file: !1912, line: 6, column: 103)
!2185 = !DILocation(line: 9, column: 40, scope: !2089, inlinedAt: !2182)
!2186 = !DILocation(line: 10, column: 5, scope: !2089, inlinedAt: !2182)
!2187 = !DILocation(line: 10, column: 80, scope: !2100, inlinedAt: !2182)
!2188 = !DILocation(line: 6, column: 131, scope: !2189)
!2189 = !DILexicalBlockFile(scope: !2095, file: !1912, discriminator: 24)
!2190 = !DILocation(line: 6, column: 138, scope: !2191)
!2191 = !DILexicalBlockFile(scope: !2192, file: !1912, discriminator: 36)
!2192 = !DILexicalBlock(scope: !2095, file: !1912, line: 6, column: 131)
!2193 = !DILocation(line: 7, column: 15, scope: !2073)
!2194 = !DILocation(line: 7, column: 32, scope: !2195)
!2195 = !DILexicalBlockFile(scope: !2108, file: !1912, discriminator: 4)
!2196 = distinct !DISubprogram(name: "getauxvalImpl", linkageName: "os.linux.getauxvalImpl", scope: !705, file: !705, line: 405, type: !2197, scopeLine: 405, flags: DIFlagStaticMember, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!2197 = !DISubroutineType(types: !2198)
!2198 = !{!36, !36}
!2199 = !DILocalVariable(name: "index", arg: 1, scope: !2196, file: !705, line: 405, type: !36)
!2200 = !DILocation(line: 405, column: 51, scope: !2196)
!2201 = !DILocation(line: 0, scope: !2196)
