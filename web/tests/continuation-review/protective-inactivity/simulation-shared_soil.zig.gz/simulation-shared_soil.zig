//! Shared finite-soil exchange at the abiotic phase; transient root credits consumed later. No escrow.
const std=@import("std");
const M=@import("microbes.zig");
const P=@import("physical_water_f64.zig");

pub const Result=struct{soil:f64,vapor:f64,h:[4]f32=.{0,0,0,0},demand:[4]f64=.{0,0,0,0},credits:[4]f64=.{0,0,0,0},paid:f64=0,bare_credit:f64=0,vapor_rounding_density:f64=0};
pub fn step(cell:M.Cell,soil:f64,vapor:f64,area:f64,env:M.Environment,dt:f32,conductance:u8,bare:f64)?Result{return stepBorrowed(&cell,soil,vapor,area,env,dt,conductance,bare);}
pub fn stepBorrowed(cell:*const M.Cell,soil:f64,vapor:f64,area:f64,env:M.Environment,dt:f32,conductance:u8,bare:f64)?Result{
 @setFloatMode(.strict);
 if(!std.math.isFinite(soil) or soil<0 or soil>1 or !std.math.isFinite(vapor) or vapor<0 or !std.math.isFinite(area) or area<=0 or !std.math.isFinite(dt) or dt<=0 or (conductance!=1 and conductance!=10))return null;
 if(!std.math.isFinite(env.temperature) or !std.math.isFinite(env.depth_km) or env.depth_km<0 or !std.math.isFinite(env.light) or env.light<0 or env.light>2)return null;
 for(cell.cohorts)|c|if(!std.math.isFinite(c.root_fraction) or c.root_fraction<0 or c.root_fraction>1 or !std.math.isFinite(c.biomass) or c.biomass<0 or !std.math.isFinite(c.support_mass) or c.support_mass<0 or c.support_mass>c.biomass)return null;
 if(!std.math.isFinite(bare) or bare<0)return null;var out=Result{.soil=soil,.vapor=vapor};
 const root_eligible=env.temperature>273.15 and env.temperature<355 and env.depth_km<0.0002;
 const depth=@as(f64,env.depth_km)*1000;var wants=[_]f64{0,0,0,0};
 for(cell.cohorts,0..)|c,i|{
  if(c.inactive or !root_eligible or c.biomass<=0 or c.root_fraction==0 or c.support_mass<=0)continue;
  const height=@as(f64,M.producerHeightMeters(c));const exposure=if(env.immersion_physiology) 1-(@import("basal_geometry.zig").immersion(c.biomass,height,depth,100) orelse return null) else if(height>0)std.math.clamp((height-depth)/height,0,1)else if(depth==0)@as(f64,1)else 0;
  out.demand[i]=0.1*@as(f64,M.frondMass(c))*@as(f64,dt)/86400*(0.5+0.5*@as(f64,env.light))*exposure;
  const root=P.downProduct(c.support_mass,c.root_fraction);
  const flow=P.downProduct(P.downProduct(P.downProduct(root,@as(f64,@floatFromInt(conductance))/86400),soil),dt);
  if(!std.math.isFinite(flow) or !std.math.isFinite(out.demand[i]) or out.demand[i]<0)return null;
  wants[i]=@min(out.demand[i],flow);
 }
 var all=[_]f64{wants[0],wants[1],wants[2],wants[3],bare};std.mem.sort(f64,&all,{},std.sort.asc(f64));var request:f64=0;var denominator:f64=0;for(all)|x|if(x>0){request=std.math.nextAfter(f64,request+x,0);denominator=std.math.nextAfter(f64,denominator+x,std.math.inf(f64));};if(!std.math.isFinite(denominator))return null;
 const receipt=@import("vapor_bridge.zig").step(soil,vapor,area,request) orelse return null;

 out.soil=receipt.soil;out.vapor=receipt.vapor;out.paid=receipt.paid;out.vapor_rounding_density=receipt.residual_density;
 if(denominator>0)for(0..4)|i|{out.credits[i]=@min(wants[i],P.downProduct(receipt.funded,P.downRatio(wants[i],denominator)));out.h[i]=P.signal32(out.credits[i],out.demand[i]);};
 if(denominator>0)out.bare_credit=@min(bare,P.downProduct(receipt.funded,P.downRatio(bare,denominator)));
 return out;
}
